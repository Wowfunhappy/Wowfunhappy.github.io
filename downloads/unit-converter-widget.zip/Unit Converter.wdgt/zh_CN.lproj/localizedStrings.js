var localizedStrings = new Array();

localizedStrings['Area'] = '面积';
localizedStrings['Square Inch'] = '平方英寸';
localizedStrings['Square Kilometer'] = '平方千米';
localizedStrings['Square Foot'] = '平方英尺';
localizedStrings['Square Centimeter'] = '平方厘米';
localizedStrings['Square Yard'] = '平方码';
localizedStrings['Square Millimeter'] = '平方毫米';
localizedStrings['Square Meter'] = '平方米';
localizedStrings['Square Mile'] = '平方英里';
localizedStrings['Acre'] = '英亩';
localizedStrings['Hectare'] = '公顷';

localizedStrings['Energy'] = '能量';
localizedStrings['Kilogram-Meters'] = '千克-米';
localizedStrings['Foot-Pounds'] = '英尺-磅';
localizedStrings['Kilogram-Calories'] = '千克-卡路里';
localizedStrings['Ergs'] = '尔格';
localizedStrings['Kilowatt-Hours'] = '千瓦-小时';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = '牛顿-米';
localizedStrings['Joules'] = '焦耳';
localizedStrings['Calories'] = '卡路里';
localizedStrings['Watt-Hours'] = '瓦特-小时';

localizedStrings['Temperature'] = '温度';
localizedStrings['Fahrenheit'] = '华氏度';
localizedStrings['Kelvin'] = '开氏度';
localizedStrings['Celsius'] = '摄氏度';

localizedStrings['Length'] = '长度';
localizedStrings['Inch'] = '英寸';
localizedStrings['Yard'] = '码';
localizedStrings['Mile (nautical)'] = '英里（海里）';
localizedStrings['Centimeter'] = '厘米';
localizedStrings['Meter'] = '米';
localizedStrings['Mile'] = '英里';
localizedStrings['Foot'] = '英尺';
localizedStrings['Kilometer'] = '千米';
localizedStrings['Millimeter'] = '毫米';

localizedStrings['Weight'] = '重量';
localizedStrings['Pound (US)'] = '磅（美制）';
localizedStrings['Stone'] = '英石';
localizedStrings['Short Ton (US)'] = '短吨（美制）';
localizedStrings['Metric Ton'] = '公吨';
localizedStrings['Ounce (US)'] = '盎司（美制）';
localizedStrings['Gram'] = '克';
localizedStrings['Long Ton (UK)'] = '长吨（英制）';
localizedStrings['Kilogram'] = '千克';

localizedStrings['Speed'] = '速度';
localizedStrings['Feet/Minute'] = '英尺/分';
localizedStrings['Kilometers/Hour'] = '千米/小时';
localizedStrings['Miles/Minute'] = '英里/分';
localizedStrings['Kilometers/Minute'] = '千米/分';
localizedStrings['Feet/Second'] = '英尺/秒';
localizedStrings['Meters/Second'] = '米/秒';
localizedStrings['Knots'] = '节';
localizedStrings['Miles/Hour'] = '英里/小时';

localizedStrings['Pressure'] = '压力';
localizedStrings['Bars'] = '汞柱';
localizedStrings['Kilograms/Square Meter'] = '千克/平方米';
localizedStrings['Atmospheres'] = '大气压';
localizedStrings['Pounds/Square Foot'] = '磅/平方英尺';
localizedStrings['Inches of Mercury'] = '英寸汞柱';
localizedStrings['Centimeters of Mercury'] = '厘米汞柱';
localizedStrings['Pascals'] = '帕斯卡';
localizedStrings['Pounds/Square Inch'] = '磅/平方英寸';

localizedStrings['Power'] = '功率';
localizedStrings['Horsepower'] = '马力';
localizedStrings['Btus/Minute'] = 'BTU/分';
localizedStrings['Foot-Pounds/Minute'] = '英尺-磅/分';
localizedStrings['Watts'] = '瓦';
localizedStrings['Foot-Pounds/Second'] = '英尺-磅/秒';
localizedStrings['Kilowatts'] = '千瓦';

localizedStrings['Volume'] = '容积';
localizedStrings['Pint (US)'] = '品脱（美制）';
localizedStrings['Cup'] = '杯';
localizedStrings['Tablespoon'] = '汤匙';
localizedStrings['Teaspoon'] = '茶匙';
localizedStrings['Gallon (US)'] = '加仑（美制）';
localizedStrings['Cubic Feet'] = '立方英尺';
localizedStrings['Cubic Meter'] = '立方米';
localizedStrings['Quart (US)'] = '夸脱（美制）';
localizedStrings['Liter'] = '公升';
localizedStrings['Gallon (Imperial)'] = '加仑（英制）';
localizedStrings['Dram (US)'] = '打兰（美制）';
localizedStrings['Fluid Ounce (US)'] = '液量盎司（美制）';

localizedStrings['Time'] = '时间';
localizedStrings['Hours'] = '小时';
localizedStrings['Minutes'] = '分钟';
localizedStrings['Seconds'] = '秒';
localizedStrings['Milliseconds'] = '毫秒';
localizedStrings['Microseconds'] = '微秒';
localizedStrings['Nanoseconds'] = '纳秒';
localizedStrings['Weeks'] = '周';
localizedStrings['Days'] = '天';
localizedStrings['Years'] = '年';

localizedStrings['Convert'] = '转换';
localizedStrings['Currency'] = '货币';
localizedStrings['CurrencyLastUpdated'] = '上次更新';
localizedStrings['CurrencyNotAvailable'] = '汇率当前不可用。';
localizedStrings['Attribution'] = '货币兑换提供者';
localizedStrings['Done'] = '完成';
localizedStrings['Network unavailable.'] = '网络不可用。';
localizedStrings['Invalid Date'] = '无效的日期。';
localizedStrings['Data unavailable.'] = '数据不可用。';
localizedStrings['Retrieving data.'] = '正在取回数据。';
localizedStrings['Terms of Service'] = '服务条款';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

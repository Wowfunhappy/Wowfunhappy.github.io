var localizedStrings = new Array();

localizedStrings['Area'] = '面積';
localizedStrings['Square Inch'] = '平方インチ';
localizedStrings['Square Kilometer'] = '平方キロメートル';
localizedStrings['Square Foot'] = '平方フィート';
localizedStrings['Square Centimeter'] = '平方センチメートル';
localizedStrings['Square Yard'] = '平方ヤード';
localizedStrings['Square Millimeter'] = '平方ミリメートル';
localizedStrings['Square Meter'] = '平方メートル';
localizedStrings['Square Mile'] = '平方マイル';
localizedStrings['Acre'] = 'エーカー';
localizedStrings['Hectare'] = 'ヘクタール';

localizedStrings['Energy'] = 'エネルギー';
localizedStrings['Kilogram-Meters'] = 'キログラムメートル';
localizedStrings['Foot-Pounds'] = 'フィートポンド';
localizedStrings['Kilogram-Calories'] = 'キログラムカロリー';
localizedStrings['Ergs'] = 'エルグ';
localizedStrings['Kilowatt-Hours'] = 'キロワット時';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'ニュートンメートル';
localizedStrings['Joules'] = 'ジュール';
localizedStrings['Calories'] = 'カロリー';
localizedStrings['Watt-Hours'] = 'ワット時';

localizedStrings['Temperature'] = '温度';
localizedStrings['Fahrenheit'] = '華氏';
localizedStrings['Kelvin'] = 'ケルビン';
localizedStrings['Celsius'] = '摂氏';

localizedStrings['Length'] = '長さ';
localizedStrings['Inch'] = 'インチ';
localizedStrings['Yard'] = 'ヤード';
localizedStrings['Mile (nautical)'] = '海里';
localizedStrings['Centimeter'] = 'センチメートル';
localizedStrings['Meter'] = 'メートル';
localizedStrings['Mile'] = 'マイル';
localizedStrings['Foot'] = 'フィート';
localizedStrings['Kilometer'] = 'キロメートル';
localizedStrings['Millimeter'] = 'ミリメートル';

localizedStrings['Weight'] = '重さ';
localizedStrings['Pound (US)'] = '米ポンド';
localizedStrings['Stone'] = 'ストーン';
localizedStrings['Short Ton (US)'] = '米トン';
localizedStrings['Metric Ton'] = 'メートルトン';
localizedStrings['Ounce (US)'] = '米オンス';
localizedStrings['Gram'] = 'グラム';
localizedStrings['Long Ton (UK)'] = '英トン';
localizedStrings['Kilogram'] = 'キログラム';

localizedStrings['Speed'] = '速さ';
localizedStrings['Feet/Minute'] = 'フィート／分';
localizedStrings['Kilometers/Hour'] = 'キロメートル／時';
localizedStrings['Miles/Minute'] = 'マイル／分';
localizedStrings['Kilometers/Minute'] = 'キロメートル／分';
localizedStrings['Feet/Second'] = 'フィート／秒';
localizedStrings['Meters/Second'] = 'メートル／秒';
localizedStrings['Knots'] = 'ノット';
localizedStrings['Miles/Hour'] = 'マイル／時';

localizedStrings['Pressure'] = '圧力';
localizedStrings['Bars'] = 'バール';
localizedStrings['Kilograms/Square Meter'] = 'キログラム／平方メートル';
localizedStrings['Atmospheres'] = '気圧';
localizedStrings['Pounds/Square Foot'] = 'ポンド／平方フィート';
localizedStrings['Inches of Mercury'] = '水銀柱インチ';
localizedStrings['Centimeters of Mercury'] = '水銀柱センチメートル';
localizedStrings['Pascals'] = 'パスカル';
localizedStrings['Pounds/Square Inch'] = 'ポンド／平方インチ';

localizedStrings['Power'] = '仕事率';
localizedStrings['Horsepower'] = '馬力';
localizedStrings['Btus/Minute'] = 'BTU／分';
localizedStrings['Foot-Pounds/Minute'] = 'フィートポンド／分';
localizedStrings['Watts'] = 'ワット';
localizedStrings['Foot-Pounds/Second'] = 'フィートポンド／秒';
localizedStrings['Kilowatts'] = 'キロワット';

localizedStrings['Volume'] = '体積';
localizedStrings['Pint (US)'] = '米パイント';
localizedStrings['Cup'] = 'カップ';
localizedStrings['Tablespoon'] = 'テーブルスプーン';
localizedStrings['Teaspoon'] = 'ティースプーン';
localizedStrings['Gallon (US)'] = '米ガロン';
localizedStrings['Cubic Feet'] = '立方フィート';
localizedStrings['Cubic Meter'] = '立方メートル';
localizedStrings['Quart (US)'] = '米クォート';
localizedStrings['Liter'] = 'リットル';
localizedStrings['Gallon (Imperial)'] = '英ガロン';
localizedStrings['Dram (US)'] = '米ドラム';
localizedStrings['Fluid Ounce (US)'] = '米液用オンス';

localizedStrings['Time'] = '時間';
localizedStrings['Hours'] = '時間';
localizedStrings['Minutes'] = '分';
localizedStrings['Seconds'] = '秒';
localizedStrings['Milliseconds'] = 'ミリ秒';
localizedStrings['Microseconds'] = 'マイクロ秒';
localizedStrings['Nanoseconds'] = 'ナノ秒';
localizedStrings['Weeks'] = '週';
localizedStrings['Days'] = '日';
localizedStrings['Years'] = '年';

localizedStrings['Convert'] = '換算対象';
localizedStrings['Currency'] = '通貨';
localizedStrings['CurrencyLastUpdated'] = '最終更新';
localizedStrings['CurrencyNotAvailable'] = '為替レートは現在使用できません。';
localizedStrings['Attribution'] = '通貨換算情報の提供元：';
localizedStrings['Done'] = '完了';
localizedStrings['Network unavailable.'] = 'ネットワークが利用できません。';
localizedStrings['Invalid Date'] = '日付が無効です。';
localizedStrings['Data unavailable.'] = 'データが利用できません。';
localizedStrings['Retrieving data.'] = 'データを取得中。';
localizedStrings['Terms of Service'] = '利用条件';
localizedStrings['Yahoo Finance'] = 'Yahoo ファイナンス';

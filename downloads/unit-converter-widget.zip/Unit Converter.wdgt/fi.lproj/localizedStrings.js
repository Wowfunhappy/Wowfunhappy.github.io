var localizedStrings = new Array();

localizedStrings['Area'] = 'Pinta-ala';
localizedStrings['Square Inch'] = 'Neliötuuma';
localizedStrings['Square Kilometer'] = 'Neliökilometri';
localizedStrings['Square Foot'] = 'Neliöjalka';
localizedStrings['Square Centimeter'] = 'Neliösenttimetri';
localizedStrings['Square Yard'] = 'Neliöjaardi';
localizedStrings['Square Millimeter'] = 'Neliömillimetri';
localizedStrings['Square Meter'] = 'Neliömetri';
localizedStrings['Square Mile'] = 'Neliömaili';
localizedStrings['Acre'] = 'Eekkeri';
localizedStrings['Hectare'] = 'Hehtaari';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Kilogrammametri';
localizedStrings['Foot-Pounds'] = 'Jalkapauna';
localizedStrings['Kilogram-Calories'] = 'Kilogrammakalori';
localizedStrings['Ergs'] = 'Ergi';
localizedStrings['Kilowatt-Hours'] = 'Kilowattitunti';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newtonmetri';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalori';
localizedStrings['Watt-Hours'] = 'Wattitunti';

localizedStrings['Temperature'] = 'Lämpötila';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Pituus';
localizedStrings['Inch'] = 'Tuuma';
localizedStrings['Yard'] = 'Jaardi';
localizedStrings['Mile (nautical)'] = 'Merimaili';
localizedStrings['Centimeter'] = 'Senttimetri';
localizedStrings['Meter'] = 'Metri';
localizedStrings['Mile'] = 'Maili';
localizedStrings['Foot'] = 'Jalka';
localizedStrings['Kilometer'] = 'Kilometri';
localizedStrings['Millimeter'] = 'Millimetri';

localizedStrings['Weight'] = 'Paino';
localizedStrings['Pound (US)'] = 'Naula (US)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Lyhyt tonni (US)';
localizedStrings['Metric Ton'] = 'Tonni';
localizedStrings['Ounce (US)'] = 'Unssi (US)';
localizedStrings['Gram'] = 'Gramma';
localizedStrings['Long Ton (UK)'] = 'Pitkä tonni (UK)';
localizedStrings['Kilogram'] = 'Kilogramma';

localizedStrings['Speed'] = 'Nopeus';
localizedStrings['Feet/Minute'] = 'Jalkaa/minuutti';
localizedStrings['Kilometers/Hour'] = 'Kilometriä/tunti';
localizedStrings['Miles/Minute'] = 'Mailia/minuutti';
localizedStrings['Kilometers/Minute'] = 'Kilometriä/minuutti';
localizedStrings['Feet/Second'] = 'Jalkaa/sekunti';
localizedStrings['Meters/Second'] = 'Metriä/sekunti';
localizedStrings['Knots'] = 'Solmu';
localizedStrings['Miles/Hour'] = 'Mailia/tunti';

localizedStrings['Pressure'] = 'Paine';
localizedStrings['Bars'] = 'Baari';
localizedStrings['Kilograms/Square Meter'] = 'Kilogrammaa/neliömetri';
localizedStrings['Atmospheres'] = 'Ilmakehä';
localizedStrings['Pounds/Square Foot'] = 'Paunaa/neliöjalka';
localizedStrings['Inches of Mercury'] = 'Tuumaa elohopeaa';
localizedStrings['Centimeters of Mercury'] = 'Senttiä elohopeaa';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Naulaa/neliötuuma';

localizedStrings['Power'] = 'Teho';
localizedStrings['Horsepower'] = 'Hevosvoima';
localizedStrings['Btus/Minute'] = 'BTU:ta/minuutti';
localizedStrings['Foot-Pounds/Minute'] = 'Jalkapaunaa/minuutti';
localizedStrings['Watts'] = 'Watti';
localizedStrings['Foot-Pounds/Second'] = 'Jalkapaunaa/sekunti';
localizedStrings['Kilowatts'] = 'Kilowatti';

localizedStrings['Volume'] = 'Tilavuus';
localizedStrings['Pint (US)'] = 'Pint (US)';
localizedStrings['Cup'] = 'Kuppi';
localizedStrings['Tablespoon'] = 'Ruokalusikka';
localizedStrings['Teaspoon'] = 'Teelusikka';
localizedStrings['Gallon (US)'] = 'Gallona (US)';
localizedStrings['Cubic Feet'] = 'Kuutiojalka';
localizedStrings['Cubic Meter'] = 'Kuutiometri';
localizedStrings['Quart (US)'] = 'Neljännesgallona (US)';
localizedStrings['Liter'] = 'Litra';
localizedStrings['Gallon (Imperial)'] = 'Gallona (UK)';
localizedStrings['Dram (US)'] = 'Dram (US)';
localizedStrings['Fluid Ounce (US)'] = 'Nesteunssi (US)';

localizedStrings['Time'] = 'Aika';
localizedStrings['Hours'] = 'Tunti';
localizedStrings['Minutes'] = 'Minuutti';
localizedStrings['Seconds'] = 'Sekunti';
localizedStrings['Milliseconds'] = 'Millisekunti';
localizedStrings['Microseconds'] = 'Mikrosekunti';
localizedStrings['Nanoseconds'] = 'Nanosekunti';
localizedStrings['Weeks'] = 'Viikko';
localizedStrings['Days'] = 'Päivä';
localizedStrings['Years'] = 'Vuosi';

localizedStrings['Convert'] = 'Muunnos';
localizedStrings['Currency'] = 'Valuutta';
localizedStrings['CurrencyLastUpdated'] = 'Viimeksi päivitetty';
localizedStrings['CurrencyNotAvailable'] = 'Valuuttakurssit eivät ole tällä hetkellä saatavilla.';
localizedStrings['Attribution'] = 'Valuuttamuunnoksen tarjosi';
localizedStrings['Done'] = 'Valmis';
localizedStrings['Network unavailable.'] = 'Verkko ei ole käytettävissä.';
localizedStrings['Invalid Date'] = 'Virheellinen päivämäärä.';
localizedStrings['Data unavailable.'] = 'Tietoa ei ole saatavilla.';
localizedStrings['Retrieving data.'] = 'Haetaan tietoa.';
localizedStrings['Terms of Service'] = 'Palveluehdot';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Εμβαδόν';
localizedStrings['Square Inch'] = 'Τετραγωνική ίντσα';
localizedStrings['Square Kilometer'] = 'Τετραγωνικό χιλιόμετρο';
localizedStrings['Square Foot'] = 'Τετραγωνικό πόδι';
localizedStrings['Square Centimeter'] = 'Τετραγωνικό εκατοστό';
localizedStrings['Square Yard'] = 'Τετραγωνική γιάρδα';
localizedStrings['Square Millimeter'] = 'Τετραγωνικό χιλιοστό';
localizedStrings['Square Meter'] = 'Τετραγωνικό μέτρο';
localizedStrings['Square Mile'] = 'Τετραγωνικό μίλι';
localizedStrings['Acre'] = 'Ακρ';
localizedStrings['Hectare'] = 'Εκτάρι';

localizedStrings['Energy'] = 'Ενέργεια';
localizedStrings['Kilogram-Meters'] = 'Χιλιογραμμόμετρο';
localizedStrings['Foot-Pounds'] = 'Ποδόλιβρα';
localizedStrings['Kilogram-Calories'] = 'Χιλιοθερμίδα';
localizedStrings['Ergs'] = 'Έργια';
localizedStrings['Kilowatt-Hours'] = 'Κιλοβατώρες';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Νιουτόμετρα';
localizedStrings['Joules'] = 'Τζάουλ';
localizedStrings['Calories'] = 'Θερμίδες';
localizedStrings['Watt-Hours'] = 'Βατώρες';

localizedStrings['Temperature'] = 'Θερμοκρασία';
localizedStrings['Fahrenheit'] = 'Φαρενάιτ';
localizedStrings['Kelvin'] = 'Κέλβιν';
localizedStrings['Celsius'] = 'Κελσίου';

localizedStrings['Length'] = 'Μήκος';
localizedStrings['Inch'] = 'Ίντσα';
localizedStrings['Yard'] = 'Γιάρδα';
localizedStrings['Mile (nautical)'] = 'Μίλι (ναυτικό)';
localizedStrings['Centimeter'] = 'Εκατοστό';
localizedStrings['Meter'] = 'Μέτρο';
localizedStrings['Mile'] = 'Μίλι';
localizedStrings['Foot'] = 'Πόδι';
localizedStrings['Kilometer'] = 'Χιλιόμετρο';
localizedStrings['Millimeter'] = 'Χιλιοστόμετρο';

localizedStrings['Weight'] = 'Βάρος';
localizedStrings['Pound (US)'] = 'Λίβρα (Η.Π.Α.)';
localizedStrings['Stone'] = 'Πέτρα';
localizedStrings['Short Ton (US)'] = 'Μικρός τόνος (Η.Π.Α.)';
localizedStrings['Metric Ton'] = 'Μετρικός τόνος';
localizedStrings['Ounce (US)'] = 'Ουγκιά (Η.Π.Α.)';
localizedStrings['Gram'] = 'Γραμμάριο';
localizedStrings['Long Ton (UK)'] = 'Μεγάλος τόνος (Ηνωμ. Βασίλειο)';
localizedStrings['Kilogram'] = 'Χιλιογραμμάριο';

localizedStrings['Speed'] = 'Ταχύτητα';
localizedStrings['Feet/Minute'] = 'Πόδια/Λεπτό';
localizedStrings['Kilometers/Hour'] = 'Χιλιόμετρα/Ώρα';
localizedStrings['Miles/Minute'] = 'Μίλια/Λεπτό';
localizedStrings['Kilometers/Minute'] = 'Χιλιόμετρα/Λεπτό';
localizedStrings['Feet/Second'] = 'Πόδια/Δευτερόλεπτο';
localizedStrings['Meters/Second'] = 'Μέτρα/Δευτερόλεπτο';
localizedStrings['Knots'] = 'Κόμβοι';
localizedStrings['Miles/Hour'] = 'Μίλια/Ώρα';

localizedStrings['Pressure'] = 'Πίεση';
localizedStrings['Bars'] = 'Μπαρ';
localizedStrings['Kilograms/Square Meter'] = 'Χιλιογραμμάρια/Τετραγωνικό μέτρο';
localizedStrings['Atmospheres'] = 'Ατμόσφαιρες';
localizedStrings['Pounds/Square Foot'] = 'Λίβρες/Τετραγωνικό πόδι';
localizedStrings['Inches of Mercury'] = 'Ίντσες στήλης υδραργύρου';
localizedStrings['Centimeters of Mercury'] = 'Εκατοστά στήλης υδραργύρου';
localizedStrings['Pascals'] = 'Πασκάλ';
localizedStrings['Pounds/Square Inch'] = 'Λίβρες/Τετραγωνική ίντσα';

localizedStrings['Power'] = 'Δύναμη';
localizedStrings['Horsepower'] = 'Ιπποδύναμη';
localizedStrings['Btus/Minute'] = 'BTU/Λεπτό';
localizedStrings['Foot-Pounds/Minute'] = 'Ποδόλιβρα/Λεπτό';
localizedStrings['Watts'] = 'Βατ';
localizedStrings['Foot-Pounds/Second'] = 'Ποδόλιβρα/Δευτερόλεπτο';
localizedStrings['Kilowatts'] = 'Κιλοβάτ';

localizedStrings['Volume'] = 'Όγκος';
localizedStrings['Pint (US)'] = 'Πίντα (Η.Π.Α.)';
localizedStrings['Cup'] = 'Φλιτζάνι';
localizedStrings['Tablespoon'] = 'Κουτάλι της σούπας';
localizedStrings['Teaspoon'] = 'Κουταλάκι του γλυκού';
localizedStrings['Gallon (US)'] = 'Γαλόνι (Η.Π.Α.)';
localizedStrings['Cubic Feet'] = 'Κυβικά πόδια';
localizedStrings['Cubic Meter'] = 'Κυβικά μέτρα';
localizedStrings['Quart (US)'] = 'Κουόρτι (Η.Π.Α.)';
localizedStrings['Liter'] = 'Λίτρο';
localizedStrings['Gallon (Imperial)'] = 'Γαλόνι (Βρετανικό)';
localizedStrings['Dram (US)'] = 'Δράμι (Η.Π.Α.)';
localizedStrings['Fluid Ounce (US)'] = 'Ουγκιές υγρού (Η.Π.Α.)';

localizedStrings['Time'] = 'Χρόνος';
localizedStrings['Hours'] = 'Ώρες';
localizedStrings['Minutes'] = 'Λεπτά';
localizedStrings['Seconds'] = 'Δευτερόλεπτα';
localizedStrings['Milliseconds'] = 'Χιλιοστά δευτερολέπτου';
localizedStrings['Microseconds'] = 'Εκατομμυριοστό του δευτερολέπτου ';
localizedStrings['Nanoseconds'] = 'Δισεκατομμυριοστό δευτερολέπτου';
localizedStrings['Weeks'] = 'Εβδομάδες';
localizedStrings['Days'] = 'Ημέρες';
localizedStrings['Years'] = 'Έτη';

localizedStrings['Convert'] = 'Μετατροπή';
localizedStrings['Currency'] = 'Νόμισμα';
localizedStrings['CurrencyLastUpdated'] = 'Τελευταία ενημέρωση';
localizedStrings['CurrencyNotAvailable'] = 'Αυτήν τη στιγμή, οι συναλλαγματικές ισοτιμίες δεν διατίθενται.';
localizedStrings['Attribution'] = 'Η μετατροπή νομισμάτων παρέχεται από';
localizedStrings['Done'] = 'Τέλος';
localizedStrings['Network unavailable.'] = 'Το δίκτυο δεν είναι διαθέσιμο.';
localizedStrings['Invalid Date'] = 'Μη έγκυρη ημερομηνία.';
localizedStrings['Data unavailable.'] = 'Δεν διατίθενται δεδομένα.';
localizedStrings['Retrieving data.'] = 'Γίνεται ανάκτηση δεδομένων.';
localizedStrings['Terms of Service'] = 'Όροι υπηρεσίας';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

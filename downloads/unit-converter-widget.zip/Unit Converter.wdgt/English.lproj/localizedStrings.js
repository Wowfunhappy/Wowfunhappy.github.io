var localizedStrings = new Array();

localizedStrings['Area'] = 'Area';
localizedStrings['Square Inch'] = 'Square Inch';
localizedStrings['Square Kilometer'] = 'Square Kilometer';
localizedStrings['Square Foot'] = 'Square Foot';
localizedStrings['Square Centimeter'] = 'Square Centimeter';
localizedStrings['Square Yard'] = 'Square Yard';
localizedStrings['Square Millimeter'] = 'Square Millimeter';
localizedStrings['Square Meter'] = 'Square Meter';
localizedStrings['Square Mile'] = 'Square Mile';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectare';

localizedStrings['Energy'] = 'Energy';
localizedStrings['Kilogram-Meters'] = 'Kilogram-Meters';
localizedStrings['Foot-Pounds'] = 'Foot-Pounds';
localizedStrings['Kilogram-Calories'] = 'Kilogram-Calories';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-Hours';
localizedStrings['Btus'] = 'Btus';
localizedStrings['Newton-Meters'] = 'Newton-Meters';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Calories';
localizedStrings['Watt-Hours'] = 'Watt-Hours';

localizedStrings['Temperature'] = 'Temperature';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Length';
localizedStrings['Inch'] = 'Inch';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Mile (nautical)';
localizedStrings['Centimeter'] = 'Centimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mile';
localizedStrings['Foot'] = 'Foot';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Weight';
localizedStrings['Pound (US)'] = 'Pound (US)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Short Ton (US)';
localizedStrings['Metric Ton'] = 'Metric Ton';
localizedStrings['Ounce (US)'] = 'Ounce (US)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Long Ton (UK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Speed';
localizedStrings['Feet/Minute'] = 'Feet/Minute';
localizedStrings['Kilometers/Hour'] = 'Kilometers/Hour';
localizedStrings['Miles/Minute'] = 'Miles/Minute';
localizedStrings['Kilometers/Minute'] = 'Kilometers/Minute';
localizedStrings['Feet/Second'] = 'Feet/Second';
localizedStrings['Meters/Second'] = 'Meters/Second';
localizedStrings['Knots'] = 'Knots';
localizedStrings['Miles/Hour'] = 'Miles/Hour';

localizedStrings['Pressure'] = 'Pressure';
localizedStrings['Bars'] = 'Bars';
localizedStrings['Kilograms/Square Meter'] = 'Kilograms/Square Meter';
localizedStrings['Atmospheres'] = 'Atmospheres';
localizedStrings['Pounds/Square Foot'] = 'Pounds/Square Foot';
localizedStrings['Inches of Mercury'] = 'Inches of Mercury';
localizedStrings['Centimeters of Mercury'] = 'Centimeters of Mercury';
localizedStrings['Pascals'] = 'Pascals';
localizedStrings['Pounds/Square Inch'] = 'Pounds/Square Inch';

localizedStrings['Power'] = 'Power';
localizedStrings['Horsepower'] = 'Horsepower';
localizedStrings['Btus/Minute'] = 'Btus/Minute';
localizedStrings['Foot-Pounds/Minute'] = 'Foot-Pounds/Minute';
localizedStrings['Watts'] = 'Watts';
localizedStrings['Foot-Pounds/Second'] = 'Foot-Pounds/Second';
localizedStrings['Kilowatts'] = 'Kilowatts';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Pint (US)';
localizedStrings['Cup'] = 'Cup';
localizedStrings['Tablespoon'] = 'Tablespoon';
localizedStrings['Teaspoon'] = 'Teaspoon';
localizedStrings['Gallon (US)'] = 'Gallon (US)';
localizedStrings['Cubic Feet'] = 'Cubic Feet';
localizedStrings['Cubic Meter'] = 'Cubic Meter';
localizedStrings['Quart (US)'] = 'Quart (US)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallon (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (US)';
localizedStrings['Fluid Ounce (US)'] = 'Fluid Ounce (US)';

localizedStrings['Time'] = 'Time';
localizedStrings['Hours'] = 'Hours';
localizedStrings['Minutes'] = 'Minutes';
localizedStrings['Seconds'] = 'Seconds';
localizedStrings['Milliseconds'] = 'Milliseconds';
localizedStrings['Microseconds'] = 'Microseconds';
localizedStrings['Nanoseconds'] = 'Nanoseconds';
localizedStrings['Weeks'] = 'Weeks';
localizedStrings['Days'] = 'Days';
localizedStrings['Years'] = 'Years';

localizedStrings['Convert'] = 'Convert';
localizedStrings['Currency'] = 'Currency';
localizedStrings['CurrencyLastUpdated'] = 'Last Updated';
localizedStrings['CurrencyNotAvailable'] = 'Exchange rates are currently unavailable.';
localizedStrings['Attribution'] = 'Currency exchange provided by';
localizedStrings['Done'] = 'Done';
localizedStrings['Network unavailable.'] = 'Network unavailable.';
localizedStrings['Invalid Date'] = 'Invalid Date.';
localizedStrings['Data unavailable.'] = 'Data unavailable.';
localizedStrings['Retrieving data.'] = 'Retrieving data.';
localizedStrings['Terms of Service'] = 'Terms of Service';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

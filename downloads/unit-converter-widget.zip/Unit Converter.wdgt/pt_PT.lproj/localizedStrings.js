var localizedStrings = new Array();

localizedStrings['Area'] = 'Área';
localizedStrings['Square Inch'] = 'Polegada quadrada';
localizedStrings['Square Kilometer'] = 'Quilómetro quadrado';
localizedStrings['Square Foot'] = 'Pé quadrado';
localizedStrings['Square Centimeter'] = 'Centímetro quadrado';
localizedStrings['Square Yard'] = 'Jarda quadrada';
localizedStrings['Square Millimeter'] = 'Milímetro quadrado';
localizedStrings['Square Meter'] = 'Metro quadrado';
localizedStrings['Square Mile'] = 'Milha quadrada';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectare';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Quilograma-metros';
localizedStrings['Foot-Pounds'] = 'Pé-libras';
localizedStrings['Kilogram-Calories'] = 'Quilocalorias';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Quilowatt-hora';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newton-metros';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Calorias';
localizedStrings['Watt-Hours'] = 'Watt-hora';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Comprimento';
localizedStrings['Inch'] = 'Polegada';
localizedStrings['Yard'] = 'Jarda';
localizedStrings['Mile (nautical)'] = 'Milha náutica';
localizedStrings['Centimeter'] = 'Centímetro';
localizedStrings['Meter'] = 'Metro';
localizedStrings['Mile'] = 'Milha';
localizedStrings['Foot'] = 'Pé';
localizedStrings['Kilometer'] = 'Quilómetro';
localizedStrings['Millimeter'] = 'Milímetro';

localizedStrings['Weight'] = 'Peso';
localizedStrings['Pound (US)'] = 'Libra (EUA)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tonelada curta (EUA)';
localizedStrings['Metric Ton'] = 'Tonelada métrica';
localizedStrings['Ounce (US)'] = 'Onça (EUA)';
localizedStrings['Gram'] = 'Grama';
localizedStrings['Long Ton (UK)'] = 'Tonelada longa (Reino Unido)';
localizedStrings['Kilogram'] = 'Quilograma';

localizedStrings['Speed'] = 'Velocidade';
localizedStrings['Feet/Minute'] = 'Pés/minuto';
localizedStrings['Kilometers/Hour'] = 'Quilómetros/hora';
localizedStrings['Miles/Minute'] = 'Milhas/minuto';
localizedStrings['Kilometers/Minute'] = 'Quilómetros/minuto';
localizedStrings['Feet/Second'] = 'Pés/segundo';
localizedStrings['Meters/Second'] = 'Metros/segundo';
localizedStrings['Knots'] = 'Nós';
localizedStrings['Miles/Hour'] = 'Milhas/hora';

localizedStrings['Pressure'] = 'Pressão';
localizedStrings['Bars'] = 'Bares';
localizedStrings['Kilograms/Square Meter'] = 'Quilogramas/metro quadrado';
localizedStrings['Atmospheres'] = 'Atmosferas';
localizedStrings['Pounds/Square Foot'] = 'Libras/pé quadrado';
localizedStrings['Inches of Mercury'] = 'Polegadas de mercúrio';
localizedStrings['Centimeters of Mercury'] = 'Centímetros de mercúrio';
localizedStrings['Pascals'] = 'Pascais';
localizedStrings['Pounds/Square Inch'] = 'Libras/polegada quadrada';

localizedStrings['Power'] = 'Potência';
localizedStrings['Horsepower'] = 'Cavalo-vapor';
localizedStrings['Btus/Minute'] = 'BTU/minuto';
localizedStrings['Foot-Pounds/Minute'] = 'Pé-libras/minuto';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Pé-libras/segundo';
localizedStrings['Kilowatts'] = 'Quilowatt';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Quartilho (EUA)';
localizedStrings['Cup'] = 'Chávena';
localizedStrings['Tablespoon'] = 'Colher de sopa';
localizedStrings['Teaspoon'] = 'Colher de chá';
localizedStrings['Gallon (US)'] = 'Galão (EUA)';
localizedStrings['Cubic Feet'] = 'Pés cúbicos';
localizedStrings['Cubic Meter'] = 'Metro cúbico';
localizedStrings['Quart (US)'] = 'Quarto de galão (EUA)';
localizedStrings['Liter'] = 'Litro';
localizedStrings['Gallon (Imperial)'] = 'Galão (imperial)';
localizedStrings['Dram (US)'] = 'Dracma (EUA)';
localizedStrings['Fluid Ounce (US)'] = 'Onça fluida (EUA)';

localizedStrings['Time'] = 'Duração';
localizedStrings['Hours'] = 'Horas';
localizedStrings['Minutes'] = 'Minutos';
localizedStrings['Seconds'] = 'Segundos';
localizedStrings['Milliseconds'] = 'Milisegundos';
localizedStrings['Microseconds'] = 'Microssegundos';
localizedStrings['Nanoseconds'] = 'Nanossegundos';
localizedStrings['Weeks'] = 'Semanas';
localizedStrings['Days'] = 'Dias';
localizedStrings['Years'] = 'Anos';

localizedStrings['Convert'] = 'Conversão';
localizedStrings['Currency'] = 'Moeda';
localizedStrings['CurrencyLastUpdated'] = 'Última actualização';
localizedStrings['CurrencyNotAvailable'] = 'As taxas de câmbio não estão disponíveis neste momento.';
localizedStrings['Attribution'] = 'Taxas cambiais fornecidas por';
localizedStrings['Done'] = 'Terminado';
localizedStrings['Network unavailable.'] = 'Rede indisponível.';
localizedStrings['Invalid Date'] = 'Data inválida.';
localizedStrings['Data unavailable.'] = 'Dados indisponíveis.';
localizedStrings['Retrieving data.'] = 'A obter dados.';
localizedStrings['Terms of Service'] = 'Termos de serviço';
localizedStrings['Yahoo Finance'] = 'Página financeira do Yahoo';

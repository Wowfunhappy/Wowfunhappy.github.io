var localizedStrings = new Array();

localizedStrings['Area'] = 'พื้นที่';
localizedStrings['Square Inch'] = 'ตารางนิ้ว';
localizedStrings['Square Kilometer'] = 'ตารางกิโลเมตร';
localizedStrings['Square Foot'] = 'ตารางฟุต';
localizedStrings['Square Centimeter'] = 'ตารางเซ็นติเมตร';
localizedStrings['Square Yard'] = 'ตารางหลา';
localizedStrings['Square Millimeter'] = 'ตารางมิลลิเมตร';
localizedStrings['Square Meter'] = 'ตารางเมตร';
localizedStrings['Square Mile'] = 'ตารางไมล์';
localizedStrings['Acre'] = 'เอเคอร์';
localizedStrings['Hectare'] = 'เฮกตาร์';

localizedStrings['Energy'] = 'พลังงาน';
localizedStrings['Kilogram-Meters'] = 'กิโลกรัม-เมตร';
localizedStrings['Foot-Pounds'] = 'ฟุต-ปอนด์';
localizedStrings['Kilogram-Calories'] = 'กิโลกรัม-แคลอรี่';
localizedStrings['Ergs'] = 'เอิร์ก';
localizedStrings['Kilowatt-Hours'] = 'กิโลวัตต์-ชั่วโมง';
localizedStrings['Btus'] = 'บีทียู';
localizedStrings['Newton-Meters'] = 'นิวตัน-เมตร';
localizedStrings['Joules'] = 'จูล';
localizedStrings['Calories'] = 'แคลอรี่';
localizedStrings['Watt-Hours'] = 'วัตต์-ชั่วโมง';

localizedStrings['Temperature'] = 'อุณหภูมิ';
localizedStrings['Fahrenheit'] = 'ฟาเรนไฮต์';
localizedStrings['Kelvin'] = 'เคลวิน';
localizedStrings['Celsius'] = 'เซลเซียส';

localizedStrings['Length'] = 'ความยาว';
localizedStrings['Inch'] = 'นิ้ว';
localizedStrings['Yard'] = 'หลา';
localizedStrings['Mile (nautical)'] = 'ไมล์ (ทะเล)';
localizedStrings['Centimeter'] = 'เซนติเมตร';
localizedStrings['Meter'] = 'เมตร';
localizedStrings['Mile'] = 'ไมล์';
localizedStrings['Foot'] = 'ฟุต';
localizedStrings['Kilometer'] = 'กิโลเมตร';
localizedStrings['Millimeter'] = 'มิลลิเมตร';

localizedStrings['Weight'] = 'น้ำหนัก';
localizedStrings['Pound (US)'] = 'ปอนด์ (US)';
localizedStrings['Stone'] = 'หิน';
localizedStrings['Short Ton (US)'] = 'ชอร์ตตัน (US)';
localizedStrings['Metric Ton'] = 'เมตริกตัน';
localizedStrings['Ounce (US)'] = 'ออนซ์ (US)';
localizedStrings['Gram'] = 'กรัม';
localizedStrings['Long Ton (UK)'] = 'ลองตัน (UK)';
localizedStrings['Kilogram'] = 'กิโลกรัม';

localizedStrings['Speed'] = 'ความเร็ว';
localizedStrings['Feet/Minute'] = 'ฟุต/นาที';
localizedStrings['Kilometers/Hour'] = 'กิโลเมตร/ชั่วโมง';
localizedStrings['Miles/Minute'] = 'ไมล์/นาที';
localizedStrings['Kilometers/Minute'] = 'กิโลเมตร/นาที';
localizedStrings['Feet/Second'] = 'ฟุต/วินาที';
localizedStrings['Meters/Second'] = 'เมตร/วินาที';
localizedStrings['Knots'] = 'นอต';
localizedStrings['Miles/Hour'] = 'ไมล์/ชั่วโมง';

localizedStrings['Pressure'] = 'แรงดัน';
localizedStrings['Bars'] = 'แถบ';
localizedStrings['Kilograms/Square Meter'] = 'กิโลกรัม/ตารางเมตร';
localizedStrings['Atmospheres'] = 'บรรยากาศ';
localizedStrings['Pounds/Square Foot'] = 'ปอนด์/ตารางฟุต';
localizedStrings['Inches of Mercury'] = 'ระดับนิ้วบนปรอท';
localizedStrings['Centimeters of Mercury'] = 'ระดับเซนติเมตรบนปรอท';
localizedStrings['Pascals'] = 'ปาสคาล';
localizedStrings['Pounds/Square Inch'] = 'ปอนด์/ตารางนิ้ว';

localizedStrings['Power'] = 'กำลัง';
localizedStrings['Horsepower'] = 'แรงม้า';
localizedStrings['Btus/Minute'] = 'บีทียู/นาที';
localizedStrings['Foot-Pounds/Minute'] = 'ฟุต-ปอนด์/นาที';
localizedStrings['Watts'] = 'วัตต์';
localizedStrings['Foot-Pounds/Second'] = 'ฟุต-ปอนด์/วินาที';
localizedStrings['Kilowatts'] = 'กิโลวัตต์';

localizedStrings['Volume'] = 'ปริมาตร';
localizedStrings['Pint (US)'] = 'ไพนท์ (US)';
localizedStrings['Cup'] = 'ถ้วย';
localizedStrings['Tablespoon'] = 'เคลวิน';
localizedStrings['Teaspoon'] = 'ช้อนชา';
localizedStrings['Gallon (US)'] = 'แกลลอน (US)';
localizedStrings['Cubic Feet'] = 'ลูกบาศก์ฟุต';
localizedStrings['Cubic Meter'] = 'ลูกบาศก์เมตร';
localizedStrings['Quart (US)'] = 'ควอท (US)';
localizedStrings['Liter'] = 'ลิตร';
localizedStrings['Gallon (Imperial)'] = 'แกลลอน (Imperial)';
localizedStrings['Dram (US)'] = 'แดรม (US)';
localizedStrings['Fluid Ounce (US)'] = 'ฟลูอิดออนซ์ (US)';

localizedStrings['Time'] = 'เวลา';
localizedStrings['Hours'] = 'ชั่วโมง';
localizedStrings['Minutes'] = 'นาที';
localizedStrings['Seconds'] = 'วินาที';
localizedStrings['Milliseconds'] = 'มิลลิวินาที';
localizedStrings['Microseconds'] = 'ไมโครวินาที';
localizedStrings['Nanoseconds'] = 'นาโนวินาที';
localizedStrings['Weeks'] = 'สัปดาห์';
localizedStrings['Days'] = 'วัน';
localizedStrings['Years'] = 'ปี';

localizedStrings['Convert'] = 'แปลง';
localizedStrings['Currency'] = 'สกุลเงิน';
localizedStrings['CurrencyLastUpdated'] = 'ข้อมูลปรับปรุงล่าสุด';
localizedStrings['CurrencyNotAvailable'] = 'ไม่สามารถเรียกดูอัตราการแลกเปลี่ยนได้ในขณะนี้';
localizedStrings['Attribution'] = 'อัตราแลกเปลี่ยนสกุลเงินแสดงโดย';
localizedStrings['Done'] = 'เสร็จสิ้น';
localizedStrings['Network unavailable.'] = 'ไม่มีระบบเครือข่ายที่ใช้งานได้';
localizedStrings['Invalid Date'] = 'วันที่ไม่ถูกต้อง';
localizedStrings['Data unavailable.'] = 'ไม่พบข้อมูล';
localizedStrings['Retrieving data.'] = 'เรียกใช้ข้อมูล';
localizedStrings['Terms of Service'] = 'เงื่อนไขการบริการ';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import "ZKSwizzle.h"




// Global

void launchAsyncApplescript(NSString *command) {
    NSTask *task = [[NSTask alloc] init];
    task.environment = @{};
    [task setLaunchPath:@"/usr/bin/osascript"];
    [task setArguments:@[@"-e", command]];
    
    NSPipe *pipe = [[NSPipe alloc] init];
    [pipe fileHandleForReading];
    [task setStandardOutput:pipe];
    [task launch];
}

// End Global




// Prevent display of currupted graphics during window resize.

@interface myNSView : NSView
@end

@implementation myNSView

- (void) displayIfNeeded {
    if ([ [self className] isEqualToString:@"NativeWidgetMacNSWindowTitledFrame" ] || [ [self className] isEqualToString:@"BrowserWindowFrame" ]) {
        [self setWantsLayer:true];
    }
    ZKOrig(void);
}

@end




@interface myNSWindow : NSWindow
@end

@implementation myNSWindow

- (void)setTitle:(id)arg1 {
    return ZKOrig(void, [arg1 stringByReplacingOccurrencesOfString:@"🔊" withString:@""]);
}

@end




// Don't push the UI down when the menu bar unhides in fullscreen mode, because the animation doesn't work.

@interface myFullscreenToolbarController : NSObject
@end

@implementation myFullscreenToolbarController

- (BOOL)isInAnyFullscreenMode {
    return false;
}

@end




// Remove Profile from menu bar.

@interface myProfileMenuController : NSObject
@end

@implementation myProfileMenuController

- (void)initializeMenu {}

@end




// Prevent Chromium from disabling our menu item.

@interface myNSMenuItem : NSMenuItem
@end

@implementation myNSMenuItem

-(void)setEnabled:(BOOL)enabled {
    if (!enabled && [[self title] isEqual: @"Update Chromium Legacy..."]) {
        return;
    } else {
        ZKOrig(void, enabled);
    }
}

@end




@implementation NSObject (main)

+ (void)load {
    ZKSwizzle(myNSView, NSView);
    ZKSwizzle(myNSWindow, NSWindow);
    ZKSwizzle(myFullscreenToolbarController, FullscreenToolbarController);
    ZKSwizzle(myProfileMenuController, ProfileMenuController);
    ZKSwizzle(myNSMenuItem, NSMenuItem);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addUpdaterToMainMenu) name:NSApplicationDidFinishLaunchingNotification object:nil];
}

- (void)addUpdaterToMainMenu {
    NSMenu *updateMenu = [[NSMenu alloc] initWithTitle:@"Update"];
    
    NSMenuItem *updateItem = [[NSMenuItem alloc] initWithTitle:@"Update Chromium Legacy..." action:@selector(launchUpdater) keyEquivalent:@""];
    [updateMenu addItem:updateItem];
    
    NSMenuItem *updateMenuParentItem = [[NSMenuItem alloc] init];
    [updateMenuParentItem setSubmenu:updateMenu];
    [[NSApp mainMenu] insertItem:updateMenuParentItem atIndex:6];
}

- (void)launchUpdater {
    NSString* pathToUpdaterScriptInUserLibrary = [@"~/Library/PreferencePanes/Chromium Legacy Downloader.prefPane/Contents/Resources/downloader.scpt" stringByExpandingTildeInPath];
    NSString* pathToUpdaterScriptInLocalLibrary = @"/Library/PreferencePanes/Chromium Legacy Downloader.prefPane/Contents/Resources/downloader.scpt";
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath: pathToUpdaterScriptInUserLibrary]) {
        launchAsyncApplescript([NSMutableString stringWithFormat:@"run script \"%@\"", pathToUpdaterScriptInUserLibrary]);
    } else if ([fileManager fileExistsAtPath: pathToUpdaterScriptInLocalLibrary]) {
        launchAsyncApplescript([NSMutableString stringWithFormat:@"run script \"%@\"", pathToUpdaterScriptInLocalLibrary]);
    } else {
        launchAsyncApplescript([NSMutableString stringWithString:@"tell application \"System Events\" to display alert \"Could not launch updater. Please install the Chromium Legacy Downloader Preference Pane.\" as critical"]);
    }
}

@end
var localizedStrings = new Array();

localizedStrings['Area'] = 'Obszar';
localizedStrings['Square Inch'] = 'cal kwadratowy';
localizedStrings['Square Kilometer'] = 'km kwadratowy';
localizedStrings['Square Foot'] = 'stopa kwadratowa';
localizedStrings['Square Centimeter'] = 'cm kwadratowy';
localizedStrings['Square Yard'] = 'jard kwadratowy';
localizedStrings['Square Millimeter'] = 'mm kwadratowy';
localizedStrings['Square Meter'] = 'metr kwadratowy';
localizedStrings['Square Mile'] = 'mila kwadratowa';
localizedStrings['Acre'] = 'akr';
localizedStrings['Hectare'] = 'hektar';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'kilogramometr';
localizedStrings['Foot-Pounds'] = 'stopofunt';
localizedStrings['Kilogram-Calories'] = 'kilokaloria';
localizedStrings['Ergs'] = 'erg';
localizedStrings['Kilowatt-Hours'] = 'kilowatogodzina';
localizedStrings['Btus'] = 'brytyjska jednostka cieplna';
localizedStrings['Newton-Meters'] = 'niutonometr';
localizedStrings['Joules'] = 'dżul';
localizedStrings['Calories'] = 'kaloria';
localizedStrings['Watt-Hours'] = 'watogodzina';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsjusz';

localizedStrings['Length'] = 'Długość';
localizedStrings['Inch'] = 'cal';
localizedStrings['Yard'] = 'jard';
localizedStrings['Mile (nautical)'] = 'mila morska';
localizedStrings['Centimeter'] = 'centymetr';
localizedStrings['Meter'] = 'metr';
localizedStrings['Mile'] = 'mila';
localizedStrings['Foot'] = 'stopa';
localizedStrings['Kilometer'] = 'kilometr';
localizedStrings['Millimeter'] = 'milimetr';

localizedStrings['Weight'] = 'Waga';
localizedStrings['Pound (US)'] = 'funt amerykański';
localizedStrings['Stone'] = 'kamień';
localizedStrings['Short Ton (US)'] = 'tona krótka amerykańska';
localizedStrings['Metric Ton'] = 'tona metryczna';
localizedStrings['Ounce (US)'] = 'uncja amerykańska';
localizedStrings['Gram'] = 'gram';
localizedStrings['Long Ton (UK)'] = 'tona długa brytyjska';
localizedStrings['Kilogram'] = 'kilogram';

localizedStrings['Speed'] = 'Szybkość';
localizedStrings['Feet/Minute'] = 'stopa/minutę';
localizedStrings['Kilometers/Hour'] = 'kilometry/godzinę';
localizedStrings['Miles/Minute'] = 'mila/minutę';
localizedStrings['Kilometers/Minute'] = 'kilometry/minutę';
localizedStrings['Feet/Second'] = 'stopa/sekundę';
localizedStrings['Meters/Second'] = 'metr/sekundę';
localizedStrings['Knots'] = 'węzły';
localizedStrings['Miles/Hour'] = 'mila/godzinę';

localizedStrings['Pressure'] = 'Ciśnienie';
localizedStrings['Bars'] = 'bar';
localizedStrings['Kilograms/Square Meter'] = 'kilogram-siła/metr kwadratowy';
localizedStrings['Atmospheres'] = 'atmosfera';
localizedStrings['Pounds/Square Foot'] = 'funt/stopę kwadratową';
localizedStrings['Inches of Mercury'] = 'cal słupa rtęci';
localizedStrings['Centimeters of Mercury'] = 'centymetr słupa rtęci';
localizedStrings['Pascals'] = 'paskal';
localizedStrings['Pounds/Square Inch'] = 'funt/cal kwadratowy';

localizedStrings['Power'] = 'Moc';
localizedStrings['Horsepower'] = 'koń mechaniczny';
localizedStrings['Btus/Minute'] = 'brytyjska jednostka cieplna/minutę';
localizedStrings['Foot-Pounds/Minute'] = 'stopofunt/minutę';
localizedStrings['Watts'] = 'wat';
localizedStrings['Foot-Pounds/Second'] = 'stopofunt/sekundę';
localizedStrings['Kilowatts'] = 'kilowat';

localizedStrings['Volume'] = 'Objętość';
localizedStrings['Pint (US)'] = 'pinta amerykańska';
localizedStrings['Cup'] = 'filiżanka';
localizedStrings['Tablespoon'] = 'łyżka';
localizedStrings['Teaspoon'] = 'łyżeczka';
localizedStrings['Gallon (US)'] = 'galon amerykański';
localizedStrings['Cubic Feet'] = 'stopa sześcienna';
localizedStrings['Cubic Meter'] = 'metr sześcienny';
localizedStrings['Quart (US)'] = 'kwarta amerykańska';
localizedStrings['Liter'] = 'litr';
localizedStrings['Gallon (Imperial)'] = 'galon angielski';
localizedStrings['Dram (US)'] = 'dram amerykański';
localizedStrings['Fluid Ounce (US)'] = 'uncja amerykańska';

localizedStrings['Time'] = 'Czas';
localizedStrings['Hours'] = 'godzina';
localizedStrings['Minutes'] = 'minuta';
localizedStrings['Seconds'] = 'sekunda';
localizedStrings['Milliseconds'] = 'milisekunda';
localizedStrings['Microseconds'] = 'mikrosekunda';
localizedStrings['Nanoseconds'] = 'nanosekunda';
localizedStrings['Weeks'] = 'tydzień';
localizedStrings['Days'] = 'dni';
localizedStrings['Years'] = 'rok';

localizedStrings['Convert'] = 'Zamień';
localizedStrings['Currency'] = 'Waluta';
localizedStrings['CurrencyLastUpdated'] = 'Ostatnio uaktualnione';
localizedStrings['CurrencyNotAvailable'] = 'Kursy walut są teraz niedostępne.';
localizedStrings['Attribution'] = 'Kursy walut dostarczone przez';
localizedStrings['Done'] = 'Gotowe';
localizedStrings['Network unavailable.'] = 'Sieć niedostępna.';
localizedStrings['Invalid Date'] = 'Nieprawidłowa data.';
localizedStrings['Data unavailable.'] = 'Dane niedostępne.';
localizedStrings['Retrieving data.'] = 'Pobieram dane.';
localizedStrings['Terms of Service'] = 'Warunki korzystania z serwisu';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

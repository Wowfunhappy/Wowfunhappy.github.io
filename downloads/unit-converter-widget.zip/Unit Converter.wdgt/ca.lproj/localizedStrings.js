var localizedStrings = new Array();

localizedStrings['Area'] = 'Àrea';
localizedStrings['Square Inch'] = 'Polzada quadrada';
localizedStrings['Square Kilometer'] = 'Quilòmetre quadrat';
localizedStrings['Square Foot'] = 'Peu quadrat';
localizedStrings['Square Centimeter'] = 'Centímetre quadrat';
localizedStrings['Square Yard'] = 'Iarda quadrada';
localizedStrings['Square Millimeter'] = 'Mil·límetre quadrat';
localizedStrings['Square Meter'] = 'Metre quadrat';
localizedStrings['Square Mile'] = 'Milla quadrada';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectàrea';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Quilogram-metres';
localizedStrings['Foot-Pounds'] = 'Lliures peu';
localizedStrings['Kilogram-Calories'] = 'Quilogram-calories';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Quilowatts-hora';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtons-metre';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Calories';
localizedStrings['Watt-Hours'] = 'Watts-hora';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Centígrads';

localizedStrings['Length'] = 'Longitud';
localizedStrings['Inch'] = 'Polzada';
localizedStrings['Yard'] = 'Iarda';
localizedStrings['Mile (nautical)'] = 'Milla (nàutica)';
localizedStrings['Centimeter'] = 'Centímetre';
localizedStrings['Meter'] = 'Metre';
localizedStrings['Mile'] = 'Milla';
localizedStrings['Foot'] = 'Peu';
localizedStrings['Kilometer'] = 'Quilòmetre';
localizedStrings['Millimeter'] = 'Mil·límetre';

localizedStrings['Weight'] = 'Pes';
localizedStrings['Pound (US)'] = 'Lliura (EUA)';
localizedStrings['Stone'] = 'Pedra';
localizedStrings['Short Ton (US)'] = 'Tona americana';
localizedStrings['Metric Ton'] = 'Tona mètrica';
localizedStrings['Ounce (US)'] = 'Unça (EUA)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Tona anglesa';
localizedStrings['Kilogram'] = 'Quilogram';

localizedStrings['Speed'] = 'Velocitat';
localizedStrings['Feet/Minute'] = 'Peus/minut';
localizedStrings['Kilometers/Hour'] = 'Quilòmetres/hora';
localizedStrings['Miles/Minute'] = 'Milles/minut';
localizedStrings['Kilometers/Minute'] = 'Quilòmetres/minut';
localizedStrings['Feet/Second'] = 'Peus/segon';
localizedStrings['Meters/Second'] = 'Metres/segon';
localizedStrings['Knots'] = 'Nusos';
localizedStrings['Miles/Hour'] = 'Milles/hora';

localizedStrings['Pressure'] = 'Pressió';
localizedStrings['Bars'] = 'Bars';
localizedStrings['Kilograms/Square Meter'] = 'Quilograms/metre quadrat';
localizedStrings['Atmospheres'] = 'Atmosferes';
localizedStrings['Pounds/Square Foot'] = 'Lliures/peu quadrat';
localizedStrings['Inches of Mercury'] = 'Polzades de mercuri';
localizedStrings['Centimeters of Mercury'] = 'Centímetres de mercuri';
localizedStrings['Pascals'] = 'Pascals';
localizedStrings['Pounds/Square Inch'] = 'Lliures/polzada quadrada';

localizedStrings['Power'] = 'Energia';
localizedStrings['Horsepower'] = 'Cavalls de vapor';
localizedStrings['Btus/Minute'] = 'BTU/minut';
localizedStrings['Foot-Pounds/Minute'] = 'Lliures peu/minut';
localizedStrings['Watts'] = 'Watts';
localizedStrings['Foot-Pounds/Second'] = 'Lliures peu/segon';
localizedStrings['Kilowatts'] = 'Quilowatts';

localizedStrings['Volume'] = 'Volum';
localizedStrings['Pint (US)'] = 'Pinta (EUA)';
localizedStrings['Cup'] = 'Tassa';
localizedStrings['Tablespoon'] = 'Cullerada sopera';
localizedStrings['Teaspoon'] = 'Cullerada petita';
localizedStrings['Gallon (US)'] = 'Galó (EUA)';
localizedStrings['Cubic Feet'] = 'Peus cúbics';
localizedStrings['Cubic Meter'] = 'Metres cúbics';
localizedStrings['Quart (US)'] = 'Quart de galó (EUA)';
localizedStrings['Liter'] = 'Litre';
localizedStrings['Gallon (Imperial)'] = 'Galó (imperial)';
localizedStrings['Dram (US)'] = 'Dracma (EUA)';
localizedStrings['Fluid Ounce (US)'] = 'Unça líquida (EUA)';

localizedStrings['Time'] = 'Hora';
localizedStrings['Hours'] = 'Hores';
localizedStrings['Minutes'] = 'Minuts';
localizedStrings['Seconds'] = 'Segons';
localizedStrings['Milliseconds'] = 'Mil·lisegons';
localizedStrings['Microseconds'] = 'Microsegons';
localizedStrings['Nanoseconds'] = 'Nanosegons';
localizedStrings['Weeks'] = 'Setmanes';
localizedStrings['Days'] = 'Dies';
localizedStrings['Years'] = 'Anys';

localizedStrings['Convert'] = 'Convertir';
localizedStrings['Currency'] = 'Moneda';
localizedStrings['CurrencyLastUpdated'] = 'Darrera actualització';
localizedStrings['CurrencyNotAvailable'] = 'Els tipus de canvi no estan disponibles en aquest moment.';
localizedStrings['Attribution'] = 'Tipus de canvi de moneda ofert per';
localizedStrings['Done'] = 'Acceptar';
localizedStrings['Network unavailable.'] = 'Xarxa no disponible.';
localizedStrings['Invalid Date'] = 'Data no vàlida.';
localizedStrings['Data unavailable.'] = 'Dades no disponibles';
localizedStrings['Retrieving data.'] = 'Obtenint dades.';
localizedStrings['Terms of Service'] = 'Condicions del servei';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Plochu';
localizedStrings['Square Inch'] = 'Štvorcové palce';
localizedStrings['Square Kilometer'] = 'Štvorcové kilometre';
localizedStrings['Square Foot'] = 'Štvorcové stopy';
localizedStrings['Square Centimeter'] = 'Štvorcové centimetre';
localizedStrings['Square Yard'] = 'Štvorcové yardy';
localizedStrings['Square Millimeter'] = 'Štvorcové milimetre';
localizedStrings['Square Meter'] = 'Štvorcové metre';
localizedStrings['Square Mile'] = 'Štvorcové míle';
localizedStrings['Acre'] = 'Akre';
localizedStrings['Hectare'] = 'Hektáre';

localizedStrings['Energy'] = 'Energiu';
localizedStrings['Kilogram-Meters'] = 'Kilogram-Metre';
localizedStrings['Foot-Pounds'] = 'Libry na stopu';
localizedStrings['Kilogram-Calories'] = 'Kilogram-Kalórie';
localizedStrings['Ergs'] = 'Ergy';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-Hodiny';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newton-Metre';
localizedStrings['Joules'] = 'Jouly';
localizedStrings['Calories'] = 'Kalórie';
localizedStrings['Watt-Hours'] = 'Watt-Hodiny';

localizedStrings['Temperature'] = 'Teplotu';
localizedStrings['Fahrenheit'] = 'Stupne Fahrenheita';
localizedStrings['Kelvin'] = 'Stupne Kelvina';
localizedStrings['Celsius'] = 'Stupne Celzia';

localizedStrings['Length'] = 'Dĺžku';
localizedStrings['Inch'] = 'Palce';
localizedStrings['Yard'] = 'Yardy';
localizedStrings['Mile (nautical)'] = 'Míle (námorné)';
localizedStrings['Centimeter'] = 'Centimetre';
localizedStrings['Meter'] = 'Metre';
localizedStrings['Mile'] = 'Míle';
localizedStrings['Foot'] = 'Stopy';
localizedStrings['Kilometer'] = 'Kilometre';
localizedStrings['Millimeter'] = 'Milimetre';

localizedStrings['Weight'] = 'Hmotnosť';
localizedStrings['Pound (US)'] = 'Libry (USA)';
localizedStrings['Stone'] = 'Kameň';
localizedStrings['Short Ton (US)'] = 'Americké tony';
localizedStrings['Metric Ton'] = 'Metrické tony';
localizedStrings['Ounce (US)'] = 'Unce (USA)';
localizedStrings['Gram'] = 'Gramy';
localizedStrings['Long Ton (UK)'] = 'Imperiálne tony';
localizedStrings['Kilogram'] = 'Kilogramy';

localizedStrings['Speed'] = 'Rýchlosť';
localizedStrings['Feet/Minute'] = 'Stopy za minútu';
localizedStrings['Kilometers/Hour'] = 'Kilometre za hodinu';
localizedStrings['Miles/Minute'] = 'Míle za minútu';
localizedStrings['Kilometers/Minute'] = 'Kilometre za minútu';
localizedStrings['Feet/Second'] = 'Stopy za sekundu';
localizedStrings['Meters/Second'] = 'Metre za sekundu';
localizedStrings['Knots'] = 'Uzly';
localizedStrings['Miles/Hour'] = 'Míle za hodinu';

localizedStrings['Pressure'] = 'Tlak';
localizedStrings['Bars'] = 'Bary';
localizedStrings['Kilograms/Square Meter'] = 'Kilogramy/Štvorcové metre';
localizedStrings['Atmospheres'] = 'Atmosféry';
localizedStrings['Pounds/Square Foot'] = 'Libry na štvorcovú stopu';
localizedStrings['Inches of Mercury'] = 'Palce ortuti';
localizedStrings['Centimeters of Mercury'] = 'Centimetre ortuti';
localizedStrings['Pascals'] = 'Pascaly';
localizedStrings['Pounds/Square Inch'] = 'Libry na štvorcový palec';

localizedStrings['Power'] = 'Silu';
localizedStrings['Horsepower'] = 'Konská sila';
localizedStrings['Btus/Minute'] = 'BTU za minútu';
localizedStrings['Foot-Pounds/Minute'] = 'Libry na stopu za min';
localizedStrings['Watts'] = 'Watty';
localizedStrings['Foot-Pounds/Second'] = 'Libry na stopu za sekundu';
localizedStrings['Kilowatts'] = 'Kilowatty';

localizedStrings['Volume'] = 'Objem';
localizedStrings['Pint (US)'] = 'Pinty (USA)';
localizedStrings['Cup'] = 'Šálky';
localizedStrings['Tablespoon'] = 'Polievkové lyžice';
localizedStrings['Teaspoon'] = 'Čajové lyžičky';
localizedStrings['Gallon (US)'] = 'Galóny (USA)';
localizedStrings['Cubic Feet'] = 'Kubické stopy';
localizedStrings['Cubic Meter'] = 'Kubické metre';
localizedStrings['Quart (US)'] = 'Kvarty (USA)';
localizedStrings['Liter'] = 'Litre';
localizedStrings['Gallon (Imperial)'] = 'Galóny (Imperiálne)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Unce (USA)';

localizedStrings['Time'] = 'Čas';
localizedStrings['Hours'] = 'Hodiny';
localizedStrings['Minutes'] = 'Minúty';
localizedStrings['Seconds'] = 'Sekundy';
localizedStrings['Milliseconds'] = 'Milisekundy';
localizedStrings['Microseconds'] = 'Mikrosekundy';
localizedStrings['Nanoseconds'] = 'Nanosekundy';
localizedStrings['Weeks'] = 'Týždne';
localizedStrings['Days'] = 'Dni';
localizedStrings['Years'] = 'Roky';

localizedStrings['Convert'] = 'Konvertovať';
localizedStrings['Currency'] = 'Menu';
localizedStrings['CurrencyLastUpdated'] = 'Posledná aktualizácia';
localizedStrings['CurrencyNotAvailable'] = 'Kurzové lístky sú momentálne nedostupné.';
localizedStrings['Attribution'] = 'Menový kurz poskytuje';
localizedStrings['Done'] = 'Hotovo';
localizedStrings['Network unavailable.'] = 'Sieť nedostupná.';
localizedStrings['Invalid Date'] = 'Neplatný dátum.';
localizedStrings['Data unavailable.'] = 'Dáta nedostupné.';
localizedStrings['Retrieving data.'] = 'Získavajú sa dáta.';
localizedStrings['Terms of Service'] = 'Podmienky služby';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

var localizedStrings = new Array();

localizedStrings['Area'] = '면적';
localizedStrings['Square Inch'] = '제곱 인치';
localizedStrings['Square Kilometer'] = '제곱 킬로미터';
localizedStrings['Square Foot'] = '제곱 피트';
localizedStrings['Square Centimeter'] = '제곱 센티미터';
localizedStrings['Square Yard'] = '제곱 야드';
localizedStrings['Square Millimeter'] = '제곱 밀리미터';
localizedStrings['Square Meter'] = '제곱 미터';
localizedStrings['Square Mile'] = '제곱 마일';
localizedStrings['Acre'] = '에이커';
localizedStrings['Hectare'] = '헥타르';

localizedStrings['Energy'] = '에너지';
localizedStrings['Kilogram-Meters'] = '킬로그램-미터';
localizedStrings['Foot-Pounds'] = '피트-파운드';
localizedStrings['Kilogram-Calories'] = '킬로그램-열량';
localizedStrings['Ergs'] = '에르그';
localizedStrings['Kilowatt-Hours'] = '킬로와트시(KWh)';
localizedStrings['Btus'] = 'Btus';
localizedStrings['Newton-Meters'] = '뉴턴-미터';
localizedStrings['Joules'] = '줄';
localizedStrings['Calories'] = '열량';
localizedStrings['Watt-Hours'] = '와트시(Wh)';

localizedStrings['Temperature'] = '온도';
localizedStrings['Fahrenheit'] = '화씨';
localizedStrings['Kelvin'] = '켈빈';
localizedStrings['Celsius'] = '섭씨';

localizedStrings['Length'] = '길이';
localizedStrings['Inch'] = '인치';
localizedStrings['Yard'] = '야드';
localizedStrings['Mile (nautical)'] = '해상 마일';
localizedStrings['Centimeter'] = '센티미터';
localizedStrings['Meter'] = '미터';
localizedStrings['Mile'] = '마일';
localizedStrings['Foot'] = '피트';
localizedStrings['Kilometer'] = '킬로미터';
localizedStrings['Millimeter'] = '밀리미터';

localizedStrings['Weight'] = '무게';
localizedStrings['Pound (US)'] = '파운드(미국식)';
localizedStrings['Stone'] = '스톤';
localizedStrings['Short Ton (US)'] = '미톤(미국식)';
localizedStrings['Metric Ton'] = '메트릭 톤';
localizedStrings['Ounce (US)'] = '온스(미국식)';
localizedStrings['Gram'] = '그램';
localizedStrings['Long Ton (UK)'] = '영국톤';
localizedStrings['Kilogram'] = '킬로그램';

localizedStrings['Speed'] = '속도';
localizedStrings['Feet/Minute'] = '피트/분';
localizedStrings['Kilometers/Hour'] = '킬로미터/시';
localizedStrings['Miles/Minute'] = '마일/분';
localizedStrings['Kilometers/Minute'] = '킬로미터/분';
localizedStrings['Feet/Second'] = '피트/초';
localizedStrings['Meters/Second'] = '미터/초';
localizedStrings['Knots'] = '노트';
localizedStrings['Miles/Hour'] = '마일/시';

localizedStrings['Pressure'] = '압력';
localizedStrings['Bars'] = '바';
localizedStrings['Kilograms/Square Meter'] = '킬로그램/제곱 미터';
localizedStrings['Atmospheres'] = '기압';
localizedStrings['Pounds/Square Foot'] = '파운드/제곱 피트';
localizedStrings['Inches of Mercury'] = 'inHg';
localizedStrings['Centimeters of Mercury'] = 'cmHg';
localizedStrings['Pascals'] = '파스칼';
localizedStrings['Pounds/Square Inch'] = '파운드/제곱 인치';

localizedStrings['Power'] = '일률';
localizedStrings['Horsepower'] = '마력';
localizedStrings['Btus/Minute'] = 'Btus/분';
localizedStrings['Foot-Pounds/Minute'] = '피트-파운드/분';
localizedStrings['Watts'] = '와트';
localizedStrings['Foot-Pounds/Second'] = '피트-파운드/초';
localizedStrings['Kilowatts'] = '킬로와트';

localizedStrings['Volume'] = '체적';
localizedStrings['Pint (US)'] = '핀트(미국식)';
localizedStrings['Cup'] = '컵';
localizedStrings['Tablespoon'] = '테이블스푼';
localizedStrings['Teaspoon'] = '티스푼';
localizedStrings['Gallon (US)'] = '갤런 (미국식)';
localizedStrings['Cubic Feet'] = '입방 피트';
localizedStrings['Cubic Meter'] = '입방 미터';
localizedStrings['Quart (US)'] = '쿼트(미국식)';
localizedStrings['Liter'] = '리터';
localizedStrings['Gallon (Imperial)'] = '갤런 (영국식)';
localizedStrings['Dram (US)'] = '드램(미국식)';
localizedStrings['Fluid Ounce (US)'] = '액량 온스(미국식)';

localizedStrings['Time'] = '시간';
localizedStrings['Hours'] = '시';
localizedStrings['Minutes'] = '분';
localizedStrings['Seconds'] = '초';
localizedStrings['Milliseconds'] = '밀리초';
localizedStrings['Microseconds'] = '마이크로초(μs)';
localizedStrings['Nanoseconds'] = '나노초';
localizedStrings['Weeks'] = '주';
localizedStrings['Days'] = '일';
localizedStrings['Years'] = '년';

localizedStrings['Convert'] = '변환';
localizedStrings['Currency'] = '환율';
localizedStrings['CurrencyLastUpdated'] = '최근 업데이트 날짜';
localizedStrings['CurrencyNotAvailable'] = '현재 환율이 사용 불가능합니다.';
localizedStrings['Attribution'] = '환전 제공:';
localizedStrings['Done'] = '완료';
localizedStrings['Network unavailable.'] = '네트워크를 사용할 수 없습니다.';
localizedStrings['Invalid Date'] = '유효하지 않은 날짜.';
localizedStrings['Data unavailable.'] = '데이터를 사용할 수 없습니다.';
localizedStrings['Retrieving data.'] = '데이터 검색 중입니다.';
localizedStrings['Terms of Service'] = '서비스 약관';
localizedStrings['Yahoo Finance'] = 'Yahoo 금융';

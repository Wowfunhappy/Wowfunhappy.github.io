var localizedStrings = new Array();

localizedStrings['Area'] = 'Alan';
localizedStrings['Square Inch'] = 'İnç Kare';
localizedStrings['Square Kilometer'] = 'Kilometrekare';
localizedStrings['Square Foot'] = 'Fit Kare';
localizedStrings['Square Centimeter'] = 'Santimetrekare';
localizedStrings['Square Yard'] = 'Yarda Kare';
localizedStrings['Square Millimeter'] = 'Milimetrekare';
localizedStrings['Square Meter'] = 'Metrekare';
localizedStrings['Square Mile'] = 'Mil Kare';
localizedStrings['Acre'] = 'Akre';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Enerji';
localizedStrings['Kilogram-Meters'] = 'Kilogram Metre';
localizedStrings['Foot-Pounds'] = 'Fit Libre';
localizedStrings['Kilogram-Calories'] = 'Kilogram Kalori';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilovatsaat';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton Metre';
localizedStrings['Joules'] = 'Jul';
localizedStrings['Calories'] = 'Kalori';
localizedStrings['Watt-Hours'] = 'Vatsaat';

localizedStrings['Temperature'] = 'Sıcaklık';
localizedStrings['Fahrenheit'] = 'Fahrenhayt';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Santigrat';

localizedStrings['Length'] = 'Uzunluk';
localizedStrings['Inch'] = 'İnç';
localizedStrings['Yard'] = 'Yarda';
localizedStrings['Mile (nautical)'] = 'Deniz Mili';
localizedStrings['Centimeter'] = 'Santimetre';
localizedStrings['Meter'] = 'Metre';
localizedStrings['Mile'] = 'Mil';
localizedStrings['Foot'] = 'Fit';
localizedStrings['Kilometer'] = 'Kilometre';
localizedStrings['Millimeter'] = 'Milimetre';

localizedStrings['Weight'] = 'Ağırlık';
localizedStrings['Pound (US)'] = 'Libre (Amerikan)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Amerikan Tonu';
localizedStrings['Metric Ton'] = 'Ton';
localizedStrings['Ounce (US)'] = 'Ons (Amerikan)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'İngiliz Tonu';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Hız';
localizedStrings['Feet/Minute'] = 'Fit/Dakika';
localizedStrings['Kilometers/Hour'] = 'Kilometre/Saat';
localizedStrings['Miles/Minute'] = 'Mil/Dakika';
localizedStrings['Kilometers/Minute'] = 'Kilometre/Dakika';
localizedStrings['Feet/Second'] = 'Fit/Saniye';
localizedStrings['Meters/Second'] = 'Metre/Saniye';
localizedStrings['Knots'] = 'Deniz Mili/Saat';
localizedStrings['Miles/Hour'] = 'Mil/Saat';

localizedStrings['Pressure'] = 'Basınç';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/Metrekare';
localizedStrings['Atmospheres'] = 'Atmosfer';
localizedStrings['Pounds/Square Foot'] = 'Libre/Fit Kare';
localizedStrings['Inches of Mercury'] = 'İnç Cıva';
localizedStrings['Centimeters of Mercury'] = 'Santimetre Cıva';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Libre/İnç Kare';

localizedStrings['Power'] = 'Güç';
localizedStrings['Horsepower'] = 'Beygir Gücü';
localizedStrings['Btus/Minute'] = 'Btu/Dakika';
localizedStrings['Foot-Pounds/Minute'] = 'Fit Libre/Dakika';
localizedStrings['Watts'] = 'Vat';
localizedStrings['Foot-Pounds/Second'] = 'Fit Libre/Saniye';
localizedStrings['Kilowatts'] = 'Kilovat';

localizedStrings['Volume'] = 'Hacim';
localizedStrings['Pint (US)'] = 'Pint (Amerikan)';
localizedStrings['Cup'] = 'Fincan';
localizedStrings['Tablespoon'] = 'Çorba Kaşığı';
localizedStrings['Teaspoon'] = 'Çay Kaşığı';
localizedStrings['Gallon (US)'] = 'Galon (Amerikan)';
localizedStrings['Cubic Feet'] = 'Fit Küp';
localizedStrings['Cubic Meter'] = 'Metreküp';
localizedStrings['Quart (US)'] = 'Quart (Amerikan)';
localizedStrings['Liter'] = 'Litre';
localizedStrings['Gallon (Imperial)'] = 'Galon (İngiliz)';
localizedStrings['Dram (US)'] = 'Dram (Amerikan)';
localizedStrings['Fluid Ounce (US)'] = 'Sıvı Ons (Amerikan)';

localizedStrings['Time'] = 'Zaman';
localizedStrings['Hours'] = 'Saat';
localizedStrings['Minutes'] = 'Dakika';
localizedStrings['Seconds'] = 'Saniye';
localizedStrings['Milliseconds'] = 'Milisaniye';
localizedStrings['Microseconds'] = 'Mikrosaniye';
localizedStrings['Nanoseconds'] = 'Nanosaniye';
localizedStrings['Weeks'] = 'Hafta';
localizedStrings['Days'] = 'Gün';
localizedStrings['Years'] = 'Yıl';

localizedStrings['Convert'] = 'Dönüştür';
localizedStrings['Currency'] = 'Para Birimi';
localizedStrings['CurrencyLastUpdated'] = 'En Son Güncelleme';
localizedStrings['CurrencyNotAvailable'] = 'Döviz kurları şu anda kullanılabilir değil.';
localizedStrings['Attribution'] = 'Döviz kurlarını sağlayan:';
localizedStrings['Done'] = 'Bitti';
localizedStrings['Network unavailable.'] = 'Ağ kullanılabilir değil.';
localizedStrings['Invalid Date'] = 'Geçersiz Tarih.';
localizedStrings['Data unavailable.'] = 'Veri yok.';
localizedStrings['Retrieving data.'] = 'Veri getiriliyor.';
localizedStrings['Terms of Service'] = 'Hizmet Kullanım Şartları';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

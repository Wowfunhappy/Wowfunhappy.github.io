var localizedStrings = new Array();

localizedStrings['Area'] = 'Area';
localizedStrings['Square Inch'] = 'Pollici quadrati';
localizedStrings['Square Kilometer'] = 'Chilometri quadrati';
localizedStrings['Square Foot'] = 'Piedi quadrati';
localizedStrings['Square Centimeter'] = 'Centimetri quadrati';
localizedStrings['Square Yard'] = 'Iarde quadrate';
localizedStrings['Square Millimeter'] = 'Millimetri quadrati';
localizedStrings['Square Meter'] = 'Metri quadrati';
localizedStrings['Square Mile'] = 'Miglia quadrate';
localizedStrings['Acre'] = 'Acri';
localizedStrings['Hectare'] = 'Ettari';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Chilogrammo-Metro';
localizedStrings['Foot-Pounds'] = 'Libbre-Piedi';
localizedStrings['Kilogram-Calories'] = 'Chilocalorie';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Chilowattora';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton-Metro';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Calorie';
localizedStrings['Watt-Hours'] = 'Wattora';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Gradi Celsius';

localizedStrings['Length'] = 'Lunghezza';
localizedStrings['Inch'] = 'Pollici';
localizedStrings['Yard'] = 'Iarde';
localizedStrings['Mile (nautical)'] = 'Miglia (nautiche)';
localizedStrings['Centimeter'] = 'Centimetri';
localizedStrings['Meter'] = 'Metri';
localizedStrings['Mile'] = 'Miglia';
localizedStrings['Foot'] = 'Piedi';
localizedStrings['Kilometer'] = 'Chilometri';
localizedStrings['Millimeter'] = 'Millimetri';

localizedStrings['Weight'] = 'Peso';
localizedStrings['Pound (US)'] = 'Libbre (US)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tonnellata corta (US)';
localizedStrings['Metric Ton'] = 'Tonnellata metrica';
localizedStrings['Ounce (US)'] = 'Once (US)';
localizedStrings['Gram'] = 'Grammi';
localizedStrings['Long Ton (UK)'] = 'Tonnellata lunga (UK)';
localizedStrings['Kilogram'] = 'Chilogrammi';

localizedStrings['Speed'] = 'Velocità';
localizedStrings['Feet/Minute'] = 'Piedi/Minuto';
localizedStrings['Kilometers/Hour'] = 'Chilometri/Ora';
localizedStrings['Miles/Minute'] = 'Miglia/Minuto';
localizedStrings['Kilometers/Minute'] = 'Chilometri/Minuto';
localizedStrings['Feet/Second'] = 'Piedi/Secondo';
localizedStrings['Meters/Second'] = 'Metri/Secondo';
localizedStrings['Knots'] = 'Nodi';
localizedStrings['Miles/Hour'] = 'Miglia/Ora';

localizedStrings['Pressure'] = 'Pressione';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Chilogrammi/Metro quadrato';
localizedStrings['Atmospheres'] = 'Atmosfere';
localizedStrings['Pounds/Square Foot'] = 'Libbre/Piede quadrato';
localizedStrings['Inches of Mercury'] = 'Pollici di mercurio';
localizedStrings['Centimeters of Mercury'] = 'Centimetri di mercurio';
localizedStrings['Pascals'] = 'Pascal ';
localizedStrings['Pounds/Square Inch'] = 'Libbre/Pollice quadrato';

localizedStrings['Power'] = 'Potenza';
localizedStrings['Horsepower'] = 'Cavalli vapore';
localizedStrings['Btus/Minute'] = 'Btu/Minuto';
localizedStrings['Foot-Pounds/Minute'] = 'Libbre-Piedi/Minuto';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Libbre-Piedi/Secondo';
localizedStrings['Kilowatts'] = 'Chilowatt';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Pinte (US)';
localizedStrings['Cup'] = 'Coppa';
localizedStrings['Tablespoon'] = 'Cucchiaio';
localizedStrings['Teaspoon'] = 'Cucchiaino';
localizedStrings['Gallon (US)'] = 'Galloni (US)';
localizedStrings['Cubic Feet'] = 'Piedi cubi';
localizedStrings['Cubic Meter'] = 'Metri cubi';
localizedStrings['Quart (US)'] = 'Quarti (US)';
localizedStrings['Liter'] = 'Litri';
localizedStrings['Gallon (Imperial)'] = 'Galloni (imperiale)';
localizedStrings['Dram (US)'] = 'Dramme (US)';
localizedStrings['Fluid Ounce (US)'] = 'Once fluide (US)';

localizedStrings['Time'] = 'Tempo';
localizedStrings['Hours'] = 'Ore';
localizedStrings['Minutes'] = 'Minuti';
localizedStrings['Seconds'] = 'Secondi';
localizedStrings['Milliseconds'] = 'Millisecondi';
localizedStrings['Microseconds'] = 'Microsecondi';
localizedStrings['Nanoseconds'] = 'Nanosecondi';
localizedStrings['Weeks'] = 'Settimane';
localizedStrings['Days'] = 'Giorni';
localizedStrings['Years'] = 'Anni';

localizedStrings['Convert'] = 'Converti';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Ultimo aggiornamento';
localizedStrings['CurrencyNotAvailable'] = 'I tassi di cambio non sono attualmente disponibili.';
localizedStrings['Attribution'] = 'Cambio valuta fornito da';
localizedStrings['Done'] = 'Fine';
localizedStrings['Network unavailable.'] = 'Network non disponibile.';
localizedStrings['Invalid Date'] = 'Data non valida.';
localizedStrings['Data unavailable.'] = 'Dati non disponibili.';
localizedStrings['Retrieving data.'] = 'Recupero dati.';
localizedStrings['Terms of Service'] = 'Condizioni del servizio';
localizedStrings['Yahoo Finance'] = 'Yahoo Finanza';

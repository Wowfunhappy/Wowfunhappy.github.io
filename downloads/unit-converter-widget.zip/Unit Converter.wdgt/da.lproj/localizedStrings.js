var localizedStrings = new Array();

localizedStrings['Area'] = 'Areal';
localizedStrings['Square Inch'] = 'Kvadrattomme';
localizedStrings['Square Kilometer'] = 'Kvadratkilometer';
localizedStrings['Square Foot'] = 'Kvadratfod';
localizedStrings['Square Centimeter'] = 'Kvadratcentimeter';
localizedStrings['Square Yard'] = 'Kvadrat-yard';
localizedStrings['Square Millimeter'] = 'Kvadratmillimeter';
localizedStrings['Square Meter'] = 'Kvadratmeter';
localizedStrings['Square Mile'] = 'Kvadratmil';
localizedStrings['Acre'] = 'Acre (0,4 hektar)';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energi';
localizedStrings['Kilogram-Meters'] = 'Kilogram-meter';
localizedStrings['Foot-Pounds'] = 'Fod-pund';
localizedStrings['Kilogram-Calories'] = 'Kilogram-kalorier';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-timer';
localizedStrings['Btus'] = 'Btus';
localizedStrings['Newton-Meters'] = 'Newton-meter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalorier';
localizedStrings['Watt-Hours'] = 'Watt-timer';

localizedStrings['Temperature'] = 'Temperatur';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Længde';
localizedStrings['Inch'] = 'Tomme';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Sømil';
localizedStrings['Centimeter'] = 'Centimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mil';
localizedStrings['Foot'] = 'Fod';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Vægt';
localizedStrings['Pound (US)'] = 'Pund (US)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Short Ton (US)';
localizedStrings['Metric Ton'] = 'Meterton';
localizedStrings['Ounce (US)'] = 'Ounce (US)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Long Ton (UK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Hastighed';
localizedStrings['Feet/Minute'] = 'Fod/minut';
localizedStrings['Kilometers/Hour'] = 'Kilometer/time';
localizedStrings['Miles/Minute'] = 'Mil/minut';
localizedStrings['Kilometers/Minute'] = 'Kilometer/minut';
localizedStrings['Feet/Second'] = 'Fod/sekund';
localizedStrings['Meters/Second'] = 'Meter/sekund';
localizedStrings['Knots'] = 'Knob';
localizedStrings['Miles/Hour'] = 'Mil/time';

localizedStrings['Pressure'] = 'Tryk';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/kvadratmeter';
localizedStrings['Atmospheres'] = 'Atmosfærer';
localizedStrings['Pounds/Square Foot'] = 'Pund/kvadratfod';
localizedStrings['Inches of Mercury'] = 'Tommer kviksølv';
localizedStrings['Centimeters of Mercury'] = 'Centimeter kviksølv';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pund/kvadrattomme';

localizedStrings['Power'] = 'Strøm';
localizedStrings['Horsepower'] = 'Hestekræfter';
localizedStrings['Btus/Minute'] = 'Btus/minut';
localizedStrings['Foot-Pounds/Minute'] = 'Fod-pund/minut';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Fod-pund/sekund';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Rumfang';
localizedStrings['Pint (US)'] = 'Pint (US)';
localizedStrings['Cup'] = 'Kop';
localizedStrings['Tablespoon'] = 'Ske';
localizedStrings['Teaspoon'] = 'Teske';
localizedStrings['Gallon (US)'] = 'Gallon (US)';
localizedStrings['Cubic Feet'] = 'Kubikfod';
localizedStrings['Cubic Meter'] = 'Kubikmeter';
localizedStrings['Quart (US)'] = 'Quart (US)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallon (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (US)';
localizedStrings['Fluid Ounce (US)'] = 'Fluid Ounce (US)';

localizedStrings['Time'] = 'Tid';
localizedStrings['Hours'] = 'Timer';
localizedStrings['Minutes'] = 'Minutter';
localizedStrings['Seconds'] = 'Sekunder';
localizedStrings['Milliseconds'] = 'Millisekunder';
localizedStrings['Microseconds'] = 'Mikrosekunder';
localizedStrings['Nanoseconds'] = 'Nanosekunder';
localizedStrings['Weeks'] = 'Uger';
localizedStrings['Days'] = 'Dage';
localizedStrings['Years'] = 'År';

localizedStrings['Convert'] = 'Konverter';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Sidst opdateret';
localizedStrings['CurrencyNotAvailable'] = 'Valutakurser er utilgængelige.';
localizedStrings['Attribution'] = 'Valutakurser leveres af';
localizedStrings['Done'] = 'OK';
localizedStrings['Network unavailable.'] = 'Netværk utilgængeligt.';
localizedStrings['Invalid Date'] = 'Ugyldig dato.';
localizedStrings['Data unavailable.'] = 'Data utilgængelige.';
localizedStrings['Retrieving data.'] = 'Henter data.';
localizedStrings['Terms of Service'] = 'Betingelser for tjenesten';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

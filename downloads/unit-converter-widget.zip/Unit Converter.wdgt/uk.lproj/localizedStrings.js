var localizedStrings = new Array();

localizedStrings['Area'] = 'Площі';
localizedStrings['Square Inch'] = 'Кв. дюйми';
localizedStrings['Square Kilometer'] = 'Кв. кілометри';
localizedStrings['Square Foot'] = 'Кв. фути';
localizedStrings['Square Centimeter'] = 'Кв. сантиметри';
localizedStrings['Square Yard'] = 'Кв. ярди';
localizedStrings['Square Millimeter'] = 'Кв. міліметри';
localizedStrings['Square Meter'] = 'Кв. метри';
localizedStrings['Square Mile'] = 'Кв. милі';
localizedStrings['Acre'] = 'Акри';
localizedStrings['Hectare'] = 'Гектари';

localizedStrings['Energy'] = 'Енергії';
localizedStrings['Kilogram-Meters'] = 'Кілограм-метри';
localizedStrings['Foot-Pounds'] = 'Фути-фунти';
localizedStrings['Kilogram-Calories'] = 'Кілограм-калорії';
localizedStrings['Ergs'] = 'Ерги';
localizedStrings['Kilowatt-Hours'] = 'Кіловат-години';
localizedStrings['Btus'] = 'БТО';
localizedStrings['Newton-Meters'] = 'Ньютон-метри';
localizedStrings['Joules'] = 'Джоулі';
localizedStrings['Calories'] = 'Калорії';
localizedStrings['Watt-Hours'] = 'Ват-години';

localizedStrings['Temperature'] = 'Температури';
localizedStrings['Fahrenheit'] = 'Фаренгейти';
localizedStrings['Kelvin'] = 'Кельвіни';
localizedStrings['Celsius'] = 'Цельсії';

localizedStrings['Length'] = 'Довжини';
localizedStrings['Inch'] = 'Дюйми';
localizedStrings['Yard'] = 'Ярди';
localizedStrings['Mile (nautical)'] = 'Милі (морські)';
localizedStrings['Centimeter'] = 'Сантиметри';
localizedStrings['Meter'] = 'Метри';
localizedStrings['Mile'] = 'Милі';
localizedStrings['Foot'] = 'Фути';
localizedStrings['Kilometer'] = 'Кілометри';
localizedStrings['Millimeter'] = 'Міліметри';

localizedStrings['Weight'] = 'Маси';
localizedStrings['Pound (US)'] = 'Фунти (США)';
localizedStrings['Stone'] = 'Стоуни';
localizedStrings['Short Ton (US)'] = 'Малі тони (США)';
localizedStrings['Metric Ton'] = 'Метричні тони';
localizedStrings['Ounce (US)'] = 'Унції (США)';
localizedStrings['Gram'] = 'Грами';
localizedStrings['Long Ton (UK)'] = 'Великі тони';
localizedStrings['Kilogram'] = 'Кілограми';

localizedStrings['Speed'] = 'Швидкості';
localizedStrings['Feet/Minute'] = 'Фути/хв.';
localizedStrings['Kilometers/Hour'] = 'Кілометри/год';
localizedStrings['Miles/Minute'] = 'Милі/хв.';
localizedStrings['Kilometers/Minute'] = 'Кілометри/хв.';
localizedStrings['Feet/Second'] = 'Фути/с';
localizedStrings['Meters/Second'] = 'Метри/с';
localizedStrings['Knots'] = 'Вузли';
localizedStrings['Miles/Hour'] = 'Милі/год';

localizedStrings['Pressure'] = 'Тиску';
localizedStrings['Bars'] = 'Бари';
localizedStrings['Kilograms/Square Meter'] = 'Кілограми/м²';
localizedStrings['Atmospheres'] = 'Атмосфери';
localizedStrings['Pounds/Square Foot'] = 'Фунти/кв.фут';
localizedStrings['Inches of Mercury'] = 'Дюйми ртутного стовпчика';
localizedStrings['Centimeters of Mercury'] = 'См ртутного стовпчика';
localizedStrings['Pascals'] = 'Паскалі';
localizedStrings['Pounds/Square Inch'] = 'Фунти/кв.дюйм';

localizedStrings['Power'] = 'Потужності';
localizedStrings['Horsepower'] = 'Кінські сили';
localizedStrings['Btus/Minute'] = 'БТО/хв.';
localizedStrings['Foot-Pounds/Minute'] = 'Фути-фунти/хв.';
localizedStrings['Watts'] = 'Вати';
localizedStrings['Foot-Pounds/Second'] = 'Фути-фунти/с';
localizedStrings['Kilowatts'] = 'Кіловати';

localizedStrings['Volume'] = 'Об’єму';
localizedStrings['Pint (US)'] = 'Пінти (США)';
localizedStrings['Cup'] = 'Чашки';
localizedStrings['Tablespoon'] = 'Столові ложки';
localizedStrings['Teaspoon'] = 'Чайні ложки';
localizedStrings['Gallon (US)'] = 'Галони (США)';
localizedStrings['Cubic Feet'] = 'Кубічні фути';
localizedStrings['Cubic Meter'] = 'Кубічні метри';
localizedStrings['Quart (US)'] = 'Кварти (США)';
localizedStrings['Liter'] = 'Літри';
localizedStrings['Gallon (Imperial)'] = 'Галони (імперські)';
localizedStrings['Dram (US)'] = 'Драхми (США)';
localizedStrings['Fluid Ounce (US)'] = 'Рідкі унції (США)';

localizedStrings['Time'] = 'Часу';
localizedStrings['Hours'] = 'Години';
localizedStrings['Minutes'] = 'Хвилини';
localizedStrings['Seconds'] = 'Секунди';
localizedStrings['Milliseconds'] = 'Мілісекунди';
localizedStrings['Microseconds'] = 'Мікросекунди';
localizedStrings['Nanoseconds'] = 'Наносекунди';
localizedStrings['Weeks'] = 'Тижні';
localizedStrings['Days'] = 'Дні';
localizedStrings['Years'] = 'Роки';

localizedStrings['Convert'] = 'Перетв.';
localizedStrings['Currency'] = 'Валюти';
localizedStrings['CurrencyLastUpdated'] = 'Останнє оновлення';
localizedStrings['CurrencyNotAvailable'] = 'Курси валют зараз недоступні.';
localizedStrings['Attribution'] = 'Курси обміну надає';
localizedStrings['Done'] = 'Добре';
localizedStrings['Network unavailable.'] = 'Мережа недоступна.';
localizedStrings['Invalid Date'] = 'Неправильна дата.';
localizedStrings['Data unavailable.'] = 'Немає даних.';
localizedStrings['Retrieving data.'] = 'Отримую дані.';
localizedStrings['Terms of Service'] = 'Умови надання послуг';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Yta';
localizedStrings['Square Inch'] = 'Kvadrattum';
localizedStrings['Square Kilometer'] = 'Kvadratkilometer';
localizedStrings['Square Foot'] = 'Kvadratfot';
localizedStrings['Square Centimeter'] = 'Kvadratcentimeter';
localizedStrings['Square Yard'] = 'Kvadrat-yard';
localizedStrings['Square Millimeter'] = 'Kvadratmillimeter';
localizedStrings['Square Meter'] = 'Kvadratmeter';
localizedStrings['Square Mile'] = 'Kvadrat-mile';
localizedStrings['Acre'] = 'Tunnland (acre)';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energi';
localizedStrings['Kilogram-Meters'] = 'Kilogrammeter';
localizedStrings['Foot-Pounds'] = 'Pundfot';
localizedStrings['Kilogram-Calories'] = 'Kilogramkalorier';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowattimmar';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newtonmeter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalorier';
localizedStrings['Watt-Hours'] = 'Wattimmar';

localizedStrings['Temperature'] = 'Temperatur';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Längd';
localizedStrings['Inch'] = 'Tum';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Sjömil';
localizedStrings['Centimeter'] = 'Centimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mile';
localizedStrings['Foot'] = 'Fot';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Vikt';
localizedStrings['Pound (US)'] = 'Pund (USA)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Kort ton (USA)';
localizedStrings['Metric Ton'] = 'Metriskt ton';
localizedStrings['Ounce (US)'] = 'Uns (USA)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Långt ton (UK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Hastighet';
localizedStrings['Feet/Minute'] = 'Fot/minut';
localizedStrings['Kilometers/Hour'] = 'Kilometer/timme';
localizedStrings['Miles/Minute'] = 'Mile/minut';
localizedStrings['Kilometers/Minute'] = 'Kilometer/minut';
localizedStrings['Feet/Second'] = 'Fot/sekund';
localizedStrings['Meters/Second'] = 'Meter/sekund';
localizedStrings['Knots'] = 'Knop';
localizedStrings['Miles/Hour'] = 'Mile/timme';

localizedStrings['Pressure'] = 'Tryck';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/kvadratmeter';
localizedStrings['Atmospheres'] = 'Atmosfärstryck';
localizedStrings['Pounds/Square Foot'] = 'Pund/kvadratfot';
localizedStrings['Inches of Mercury'] = 'Tum kvicksilver';
localizedStrings['Centimeters of Mercury'] = 'Centimeter kvicksilver';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pund/kvadrattum';

localizedStrings['Power'] = 'Effekt';
localizedStrings['Horsepower'] = 'Hästkrafter';
localizedStrings['Btus/Minute'] = 'Btu/minut';
localizedStrings['Foot-Pounds/Minute'] = 'Pundfot/minut';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Pundfot/sekund';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Volym';
localizedStrings['Pint (US)'] = 'Pint (USA)';
localizedStrings['Cup'] = 'Kopp';
localizedStrings['Tablespoon'] = 'Matsked';
localizedStrings['Teaspoon'] = 'Tesked';
localizedStrings['Gallon (US)'] = 'Gallon (USA)';
localizedStrings['Cubic Feet'] = 'Kubikfot';
localizedStrings['Cubic Meter'] = 'Kubikmeter';
localizedStrings['Quart (US)'] = 'Quart (USA)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallon (UK)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Vätskeuns (USA)';

localizedStrings['Time'] = 'Tid';
localizedStrings['Hours'] = 'Timmar';
localizedStrings['Minutes'] = 'Minuter';
localizedStrings['Seconds'] = 'Sekunder';
localizedStrings['Milliseconds'] = 'Millisekunder';
localizedStrings['Microseconds'] = 'Mikrosekunder';
localizedStrings['Nanoseconds'] = 'Nanosekunder';
localizedStrings['Weeks'] = 'Veckor';
localizedStrings['Days'] = 'Dagar';
localizedStrings['Years'] = 'År';

localizedStrings['Convert'] = 'Konvertera';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Senast uppdaterad';
localizedStrings['CurrencyNotAvailable'] = 'Växlingskurser är för närvarande ej tillgängliga.';
localizedStrings['Attribution'] = 'Växelkurserna kommer från';
localizedStrings['Done'] = 'Klart';
localizedStrings['Network unavailable.'] = 'Nätverk ej tillgängligt.';
localizedStrings['Invalid Date'] = 'Ogiltigt datum.';
localizedStrings['Data unavailable.'] = 'Data ej tillgängliga.';
localizedStrings['Retrieving data.'] = 'Hämtar data.';
localizedStrings['Terms of Service'] = 'Villkor för tjänsten';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

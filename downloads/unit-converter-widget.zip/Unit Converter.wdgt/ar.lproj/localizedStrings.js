var localizedStrings = new Array();

localizedStrings['Area'] = 'مساحة';
localizedStrings['Square Inch'] = 'بوصة مربعة';
localizedStrings['Square Kilometer'] = 'كيلومتر مربع';
localizedStrings['Square Foot'] = 'قدم مربع';
localizedStrings['Square Centimeter'] = 'سنتيمتر مربع';
localizedStrings['Square Yard'] = 'يارد مربع';
localizedStrings['Square Millimeter'] = 'ملليمتر مربع';
localizedStrings['Square Meter'] = 'متر مربع';
localizedStrings['Square Mile'] = 'ميل مربع';
localizedStrings['Acre'] = 'فدان';
localizedStrings['Hectare'] = 'هكتار';

localizedStrings['Energy'] = 'الطاقة';
localizedStrings['Kilogram-Meters'] = 'كيلوغرام-متر';
localizedStrings['Foot-Pounds'] = 'قدم-رطل';
localizedStrings['Kilogram-Calories'] = 'كيلوغرام-سعرة حرارية';
localizedStrings['Ergs'] = 'إيرغ';
localizedStrings['Kilowatt-Hours'] = 'كيلوواط-الساعة';
localizedStrings['Btus'] = 'Btus';
localizedStrings['Newton-Meters'] = 'نيوتن-متر';
localizedStrings['Joules'] = 'جول';
localizedStrings['Calories'] = 'سعرات حرارية';
localizedStrings['Watt-Hours'] = 'واط-الساعة';

localizedStrings['Temperature'] = 'درجة الحرارة';
localizedStrings['Fahrenheit'] = 'فهرنهايت';
localizedStrings['Kelvin'] = 'كيلفن';
localizedStrings['Celsius'] = 'درجة مئوية';

localizedStrings['Length'] = 'الطول';
localizedStrings['Inch'] = 'بوصة';
localizedStrings['Yard'] = 'يارد';
localizedStrings['Mile (nautical)'] = '‫ميل (بحري)‬';
localizedStrings['Centimeter'] = 'سنتيمتر';
localizedStrings['Meter'] = 'متر';
localizedStrings['Mile'] = 'ميل';
localizedStrings['Foot'] = 'قدم';
localizedStrings['Kilometer'] = 'كيلومتر';
localizedStrings['Millimeter'] = 'ملليمتر';

localizedStrings['Weight'] = 'الوزن';
localizedStrings['Pound (US)'] = '‫رطل (الولايات المتحدة)‬';
localizedStrings['Stone'] = 'حجر';
localizedStrings['Short Ton (US)'] = '‫طن أمريكي (الولايات المتحدة)‬';
localizedStrings['Metric Ton'] = 'طن متري';
localizedStrings['Ounce (US)'] = '‫أونصة (الولايات المتحدة)‬';
localizedStrings['Gram'] = 'غرام';
localizedStrings['Long Ton (UK)'] = '‫طن إنجليزي (المملكة المتحدة)‬';
localizedStrings['Kilogram'] = 'كيلوغرام';

localizedStrings['Speed'] = 'السرعة';
localizedStrings['Feet/Minute'] = 'قدم/الدقيقة';
localizedStrings['Kilometers/Hour'] = 'كيلومتر/الساعة';
localizedStrings['Miles/Minute'] = 'ميل/الدقيقة';
localizedStrings['Kilometers/Minute'] = 'كيلومتر/الدقيقة';
localizedStrings['Feet/Second'] = 'قدم/الثانية';
localizedStrings['Meters/Second'] = 'متر/الثانية';
localizedStrings['Knots'] = 'عقدة';
localizedStrings['Miles/Hour'] = 'ميل/الساعة';

localizedStrings['Pressure'] = 'الضغط';
localizedStrings['Bars'] = 'Bars';
localizedStrings['Kilograms/Square Meter'] = 'كيلوغرام/متر مربع';
localizedStrings['Atmospheres'] = 'أتموسفير';
localizedStrings['Pounds/Square Foot'] = 'رطل/قدم مربع';
localizedStrings['Inches of Mercury'] = 'بوصة زئبق';
localizedStrings['Centimeters of Mercury'] = 'سنتيمتر زئبق';
localizedStrings['Pascals'] = 'باسكال';
localizedStrings['Pounds/Square Inch'] = 'رطل/بوصة مربعة';

localizedStrings['Power'] = 'القدرة';
localizedStrings['Horsepower'] = 'حصان';
localizedStrings['Btus/Minute'] = '‏Btus/الدقيقة';
localizedStrings['Foot-Pounds/Minute'] = 'قدم-رطل/الدقيقة';
localizedStrings['Watts'] = 'واط';
localizedStrings['Foot-Pounds/Second'] = 'قدم-رطل/الثانية';
localizedStrings['Kilowatts'] = 'كيلوواط';

localizedStrings['Volume'] = 'الحجم';
localizedStrings['Pint (US)'] = '‫باينت (الولايات المتحدة)‬';
localizedStrings['Cup'] = 'كوب';
localizedStrings['Tablespoon'] = 'ملعقة طعام';
localizedStrings['Teaspoon'] = 'ملعقة شاي';
localizedStrings['Gallon (US)'] = '‫غالون (الولايات المتحدة)‬';
localizedStrings['Cubic Feet'] = 'قدم مكعب';
localizedStrings['Cubic Meter'] = 'متر مكعب';
localizedStrings['Quart (US)'] = '‫كوارت (الولايات المتحدة)‬';
localizedStrings['Liter'] = 'ليتر';
localizedStrings['Gallon (Imperial)'] = '‫غالون (إنجليزي)‌‬';
localizedStrings['Dram (US)'] = '‫درام (الولايات المتحدة)‬';
localizedStrings['Fluid Ounce (US)'] = '‫أونصة سائلة (الولايات المتحدة)‬';

localizedStrings['Time'] = 'الوقت';
localizedStrings['Hours'] = 'ساعات';
localizedStrings['Minutes'] = 'الدقائق';
localizedStrings['Seconds'] = 'الثواني';
localizedStrings['Milliseconds'] = 'مللي ثانية';
localizedStrings['Microseconds'] = 'ميكروثانية';
localizedStrings['Nanoseconds'] = 'نانوثانية';
localizedStrings['Weeks'] = 'الأسابيع';
localizedStrings['Days'] = 'أيام';
localizedStrings['Years'] = 'الأعوام';

localizedStrings['Convert'] = 'تحويل';
localizedStrings['Currency'] = 'العملة';
localizedStrings['CurrencyLastUpdated'] = 'آخر تحديث';
localizedStrings['CurrencyNotAvailable'] = 'أسعار صرف العملات غير متوفرة حاليًا.';
localizedStrings['Attribution'] = 'أسعار صرف العملات مقدمة من قِبل';
localizedStrings['Done'] = 'تم';
localizedStrings['Network unavailable.'] = 'الشبكة غير متوفرة.';
localizedStrings['Invalid Date'] = 'التاريخ غير صالح.';
localizedStrings['Data unavailable.'] = 'البيانات غير متوفرة.';
localizedStrings['Retrieving data.'] = 'استرداد البيانات.';
localizedStrings['Terms of Service'] = 'بنود الخدمة';
localizedStrings['Yahoo Finance'] = '‏Yahoo المالي';

var localizedStrings = new Array();

localizedStrings['Area'] = '面積';
localizedStrings['Square Inch'] = '平方英吋';
localizedStrings['Square Kilometer'] = '平方公里';
localizedStrings['Square Foot'] = '平方英尺';
localizedStrings['Square Centimeter'] = '平方公分';
localizedStrings['Square Yard'] = '平方碼';
localizedStrings['Square Millimeter'] = '平方公釐';
localizedStrings['Square Meter'] = '平方公尺';
localizedStrings['Square Mile'] = '平方英里';
localizedStrings['Acre'] = '英畝';
localizedStrings['Hectare'] = '公頃';

localizedStrings['Energy'] = '能量';
localizedStrings['Kilogram-Meters'] = '公斤-公尺';
localizedStrings['Foot-Pounds'] = '英尺-英磅';
localizedStrings['Kilogram-Calories'] = '公斤-卡路里';
localizedStrings['Ergs'] = '爾格';
localizedStrings['Kilowatt-Hours'] = '千瓦-小時';
localizedStrings['Btus'] = '英熱單位';
localizedStrings['Newton-Meters'] = '牛頓-公尺';
localizedStrings['Joules'] = '焦耳';
localizedStrings['Calories'] = '卡路里';
localizedStrings['Watt-Hours'] = '瓦特-小時';

localizedStrings['Temperature'] = '溫度';
localizedStrings['Fahrenheit'] = '華氏';
localizedStrings['Kelvin'] = '凱氏';
localizedStrings['Celsius'] = '攝氏';

localizedStrings['Length'] = '長度';
localizedStrings['Inch'] = '英吋';
localizedStrings['Yard'] = '碼';
localizedStrings['Mile (nautical)'] = '海里';
localizedStrings['Centimeter'] = '公分';
localizedStrings['Meter'] = '公尺';
localizedStrings['Mile'] = '英里';
localizedStrings['Foot'] = '英尺';
localizedStrings['Kilometer'] = '公里';
localizedStrings['Millimeter'] = '公釐';

localizedStrings['Weight'] = '重量';
localizedStrings['Pound (US)'] = '磅（美制）';
localizedStrings['Stone'] = '英石';
localizedStrings['Short Ton (US)'] = '短噸（美制）';
localizedStrings['Metric Ton'] = '公噸';
localizedStrings['Ounce (US)'] = '盎斯（美制）';
localizedStrings['Gram'] = '公克';
localizedStrings['Long Ton (UK)'] = '長噸（英制）';
localizedStrings['Kilogram'] = '公斤';

localizedStrings['Speed'] = '速度';
localizedStrings['Feet/Minute'] = '英尺∕分鐘';
localizedStrings['Kilometers/Hour'] = '公里∕小時';
localizedStrings['Miles/Minute'] = '英里∕分鐘';
localizedStrings['Kilometers/Minute'] = '公里∕分鐘';
localizedStrings['Feet/Second'] = '英尺∕秒';
localizedStrings['Meters/Second'] = '公尺∕秒';
localizedStrings['Knots'] = '節';
localizedStrings['Miles/Hour'] = '英里∕小時';

localizedStrings['Pressure'] = '壓力';
localizedStrings['Bars'] = '巴';
localizedStrings['Kilograms/Square Meter'] = '公斤∕平方公尺';
localizedStrings['Atmospheres'] = '氣壓';
localizedStrings['Pounds/Square Foot'] = '磅∕平方英尺';
localizedStrings['Inches of Mercury'] = '英吋汞柱';
localizedStrings['Centimeters of Mercury'] = '公分汞柱';
localizedStrings['Pascals'] = '帕';
localizedStrings['Pounds/Square Inch'] = '磅∕平方英吋';

localizedStrings['Power'] = '功率';
localizedStrings['Horsepower'] = '馬力';
localizedStrings['Btus/Minute'] = '英熱單位∕分鐘';
localizedStrings['Foot-Pounds/Minute'] = '英尺-英磅∕分鐘';
localizedStrings['Watts'] = '瓦特';
localizedStrings['Foot-Pounds/Second'] = '英尺-英磅∕秒';
localizedStrings['Kilowatts'] = '千瓦';

localizedStrings['Volume'] = '容積';
localizedStrings['Pint (US)'] = '品脫（美制）';
localizedStrings['Cup'] = '杯';
localizedStrings['Tablespoon'] = '湯匙';
localizedStrings['Teaspoon'] = '茶匙';
localizedStrings['Gallon (US)'] = '加侖（美制）';
localizedStrings['Cubic Feet'] = '立方英尺';
localizedStrings['Cubic Meter'] = '立方公尺';
localizedStrings['Quart (US)'] = '夸特（美制）';
localizedStrings['Liter'] = '公升';
localizedStrings['Gallon (Imperial)'] = '加侖（英制）';
localizedStrings['Dram (US)'] = '打蘭（美制）';
localizedStrings['Fluid Ounce (US)'] = '液量盎斯（美制）';

localizedStrings['Time'] = '時間';
localizedStrings['Hours'] = '小時';
localizedStrings['Minutes'] = '分鐘';
localizedStrings['Seconds'] = '秒';
localizedStrings['Milliseconds'] = '毫秒';
localizedStrings['Microseconds'] = '微秒';
localizedStrings['Nanoseconds'] = '奈秒';
localizedStrings['Weeks'] = '週';
localizedStrings['Days'] = '天';
localizedStrings['Years'] = '年';

localizedStrings['Convert'] = '轉換';
localizedStrings['Currency'] = '貨幣';
localizedStrings['CurrencyLastUpdated'] = '上次更新：';
localizedStrings['CurrencyNotAvailable'] = '目前無法使用匯率。';
localizedStrings['Attribution'] = '貨幣轉換提供者為';
localizedStrings['Done'] = '完成';
localizedStrings['Network unavailable.'] = '網路無法使用。';
localizedStrings['Invalid Date'] = '無效的日期。';
localizedStrings['Data unavailable.'] = '資料無法使用。';
localizedStrings['Retrieving data.'] = '正在取得資料';
localizedStrings['Terms of Service'] = '服務條款';
localizedStrings['Yahoo Finance'] = 'Yahoo 股市';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Plocha';
localizedStrings['Square Inch'] = 'Palec čtvereční';
localizedStrings['Square Kilometer'] = 'Kilometr čtvereční';
localizedStrings['Square Foot'] = 'Stopa čtvereční';
localizedStrings['Square Centimeter'] = 'Centimetr čtvereční';
localizedStrings['Square Yard'] = 'Yard čtvereční';
localizedStrings['Square Millimeter'] = 'Milimetr čtvereční';
localizedStrings['Square Meter'] = 'Metr čtvereční';
localizedStrings['Square Mile'] = 'Míle čtvereční';
localizedStrings['Acre'] = 'Akr';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energie';
localizedStrings['Kilogram-Meters'] = 'Kilogrammetr';
localizedStrings['Foot-Pounds'] = 'Librostopa';
localizedStrings['Kilogram-Calories'] = 'Kilokalorie';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowatthodina';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtonmetr';
localizedStrings['Joules'] = 'Joul';
localizedStrings['Calories'] = 'Kalorie';
localizedStrings['Watt-Hours'] = 'Watthodiny';

localizedStrings['Temperature'] = 'Teplota';
localizedStrings['Fahrenheit'] = 'Stupně Fahrenheita';
localizedStrings['Kelvin'] = 'Stupně Kelvina';
localizedStrings['Celsius'] = 'Stupně Celsia';

localizedStrings['Length'] = 'Délka';
localizedStrings['Inch'] = 'Palec';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Míle (námořní)';
localizedStrings['Centimeter'] = 'Centimetr';
localizedStrings['Meter'] = 'Metr';
localizedStrings['Mile'] = 'Míle';
localizedStrings['Foot'] = 'Stopa';
localizedStrings['Kilometer'] = 'Kilometr';
localizedStrings['Millimeter'] = 'Milimetr';

localizedStrings['Weight'] = 'Hmotnost';
localizedStrings['Pound (US)'] = 'Libra (USA)';
localizedStrings['Stone'] = 'Kámen';
localizedStrings['Short Ton (US)'] = 'Americká tuna';
localizedStrings['Metric Ton'] = 'Metrická tuna';
localizedStrings['Ounce (US)'] = 'Unce (USA)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Britská tuna';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Rychlost';
localizedStrings['Feet/Minute'] = 'Stopy za minutu';
localizedStrings['Kilometers/Hour'] = 'Kilometry za hodinu';
localizedStrings['Miles/Minute'] = 'Míle za minutu';
localizedStrings['Kilometers/Minute'] = 'Kilometry za minutu';
localizedStrings['Feet/Second'] = 'Stopy za sekundu';
localizedStrings['Meters/Second'] = 'Metry za sekundu';
localizedStrings['Knots'] = 'Uzly';
localizedStrings['Miles/Hour'] = 'Míle za hodinu';

localizedStrings['Pressure'] = 'Tlak';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogramy na metr čtvereční';
localizedStrings['Atmospheres'] = 'Atmosféra';
localizedStrings['Pounds/Square Foot'] = 'Libry na čtvereční stopu';
localizedStrings['Inches of Mercury'] = 'Palce rtuťového sloupce';
localizedStrings['Centimeters of Mercury'] = 'Centimetry rtuti';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Libry na čtvereční palec';

localizedStrings['Power'] = 'Síla';
localizedStrings['Horsepower'] = 'Koňská síla';
localizedStrings['Btus/Minute'] = 'BTU za minutu';
localizedStrings['Foot-Pounds/Minute'] = 'Librostopy za minutu';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Librostopy za sekundu';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Objem';
localizedStrings['Pint (US)'] = 'Pinta (USA)';
localizedStrings['Cup'] = 'Šálek';
localizedStrings['Tablespoon'] = 'Polévková lžíce';
localizedStrings['Teaspoon'] = 'Čajová lžička';
localizedStrings['Gallon (US)'] = 'Galon (USA)';
localizedStrings['Cubic Feet'] = 'Krychlová stopa';
localizedStrings['Cubic Meter'] = 'Kubický metr';
localizedStrings['Quart (US)'] = 'Kvart (US)';
localizedStrings['Liter'] = 'Litr';
localizedStrings['Gallon (Imperial)'] = 'Galon (britský)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Kapalinová unce (USA)';

localizedStrings['Time'] = 'Čas';
localizedStrings['Hours'] = 'Hodiny';
localizedStrings['Minutes'] = 'Minuty';
localizedStrings['Seconds'] = 'Sekundy';
localizedStrings['Milliseconds'] = 'Milisekundy';
localizedStrings['Microseconds'] = 'Mikrosekundy';
localizedStrings['Nanoseconds'] = 'Nanosekundy';
localizedStrings['Weeks'] = 'Týdny';
localizedStrings['Days'] = 'Dny';
localizedStrings['Years'] = 'Roky';

localizedStrings['Convert'] = 'Typ převodu:';
localizedStrings['Currency'] = 'Měna';
localizedStrings['CurrencyLastUpdated'] = 'Poslední aktualizace';
localizedStrings['CurrencyNotAvailable'] = 'Směnné kurzy nejsou k dispozici.';
localizedStrings['Attribution'] = 'Převodník měn poskytuje';
localizedStrings['Done'] = 'Hotovo';
localizedStrings['Network unavailable.'] = 'Síť není k dispozici.';
localizedStrings['Invalid Date'] = 'Neplatné datum.';
localizedStrings['Data unavailable.'] = 'Data nejsou k dispozici.';
localizedStrings['Retrieving data.'] = 'Načítání dat.';
localizedStrings['Terms of Service'] = 'Podmínky služby';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

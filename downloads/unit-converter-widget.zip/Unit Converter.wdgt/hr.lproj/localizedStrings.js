var localizedStrings = new Array();

localizedStrings['Area'] = 'Područje';
localizedStrings['Square Inch'] = 'Kvadratni inč';
localizedStrings['Square Kilometer'] = 'Kvadratni kilometar';
localizedStrings['Square Foot'] = 'Kvadratna stopa';
localizedStrings['Square Centimeter'] = 'Kvadratni centimetar';
localizedStrings['Square Yard'] = 'Kvadratni jard';
localizedStrings['Square Millimeter'] = 'Kvadratni milimetar';
localizedStrings['Square Meter'] = 'Kvadratni metar';
localizedStrings['Square Mile'] = 'Kvadratna milja';
localizedStrings['Acre'] = 'Jutro';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energija';
localizedStrings['Kilogram-Meters'] = 'Kilogram-metri';
localizedStrings['Foot-Pounds'] = 'Stope-funte';
localizedStrings['Kilogram-Calories'] = 'Kilogram-kalorije';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilovat sati';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton-metri';
localizedStrings['Joules'] = 'Džuli';
localizedStrings['Calories'] = 'Kalorije';
localizedStrings['Watt-Hours'] = 'Vatsati';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celzijus';

localizedStrings['Length'] = 'Duljina';
localizedStrings['Inch'] = 'Inč';
localizedStrings['Yard'] = 'Jard';
localizedStrings['Mile (nautical)'] = 'Milja (nautička)';
localizedStrings['Centimeter'] = 'Centimetar';
localizedStrings['Meter'] = 'Metar';
localizedStrings['Mile'] = 'Milja';
localizedStrings['Foot'] = 'Stopa';
localizedStrings['Kilometer'] = 'Kilometar';
localizedStrings['Millimeter'] = 'Milimetar';

localizedStrings['Weight'] = 'Masa';
localizedStrings['Pound (US)'] = 'Funta (SAD)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Kratka tona (SAD)';
localizedStrings['Metric Ton'] = 'Metrička tona';
localizedStrings['Ounce (US)'] = 'Unca (SAD)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Duga tona (UK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Brzina';
localizedStrings['Feet/Minute'] = 'Stope/minuta';
localizedStrings['Kilometers/Hour'] = 'Kilometri/sat';
localizedStrings['Miles/Minute'] = 'Milje/minuta';
localizedStrings['Kilometers/Minute'] = 'Kilometri/minuta';
localizedStrings['Feet/Second'] = 'Stope/sekunda';
localizedStrings['Meters/Second'] = 'Metri/sekunda';
localizedStrings['Knots'] = 'Čvorovi';
localizedStrings['Miles/Hour'] = 'Milje/sat';

localizedStrings['Pressure'] = 'Tlak';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogrami/kvadratni metar';
localizedStrings['Atmospheres'] = 'Atmosfere';
localizedStrings['Pounds/Square Foot'] = 'Funte/kvadratna stopa';
localizedStrings['Inches of Mercury'] = 'Inči živinog stupca';
localizedStrings['Centimeters of Mercury'] = 'Centimetri živinog stupca';
localizedStrings['Pascals'] = 'Paskali';
localizedStrings['Pounds/Square Inch'] = 'Funte/inč na kvadrat';

localizedStrings['Power'] = 'Snaga';
localizedStrings['Horsepower'] = 'Konjska snaga';
localizedStrings['Btus/Minute'] = 'Btu/minuta';
localizedStrings['Foot-Pounds/Minute'] = 'Stopa-funte/minuta';
localizedStrings['Watts'] = 'Vati';
localizedStrings['Foot-Pounds/Second'] = 'Stopa-funte/sekunda';
localizedStrings['Kilowatts'] = 'Kilovati';

localizedStrings['Volume'] = 'Volumen';
localizedStrings['Pint (US)'] = 'Pinta (SAD)';
localizedStrings['Cup'] = 'Šalica';
localizedStrings['Tablespoon'] = 'Žlica';
localizedStrings['Teaspoon'] = 'Čajna žličica';
localizedStrings['Gallon (US)'] = 'Galon (SAD)';
localizedStrings['Cubic Feet'] = 'Kubična stopa';
localizedStrings['Cubic Meter'] = 'Kubični metar';
localizedStrings['Quart (US)'] = 'Kvart (SAD)';
localizedStrings['Liter'] = 'Litra';
localizedStrings['Gallon (Imperial)'] = 'Galon (imperijalni)';
localizedStrings['Dram (US)'] = 'Dram (SAD)';
localizedStrings['Fluid Ounce (US)'] = 'Tekuća unca (SAD)';

localizedStrings['Time'] = 'Vrijeme';
localizedStrings['Hours'] = 'Sati';
localizedStrings['Minutes'] = 'Minute';
localizedStrings['Seconds'] = 'Sekunde';
localizedStrings['Milliseconds'] = 'Milisekunde';
localizedStrings['Microseconds'] = 'Mikrosekunde';
localizedStrings['Nanoseconds'] = 'Nanosekunde';
localizedStrings['Weeks'] = 'Tjedni';
localizedStrings['Days'] = 'Dani';
localizedStrings['Years'] = 'Godine';

localizedStrings['Convert'] = 'Promijeni';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Posljednji put ažurirano';
localizedStrings['CurrencyNotAvailable'] = 'Tečajne liste trenutno nisu dostupne.';
localizedStrings['Attribution'] = 'Pretvaranje valuta omogućio';
localizedStrings['Done'] = 'Gotovo';
localizedStrings['Network unavailable.'] = 'Mreža nije dostupna.';
localizedStrings['Invalid Date'] = 'Nevažeći datum.';
localizedStrings['Data unavailable.'] = 'Podaci nisu dostupni.';
localizedStrings['Retrieving data.'] = 'Dohvat podataka.';
localizedStrings['Terms of Service'] = 'Uvjeti usluge';
localizedStrings['Yahoo Finance'] = 'Yahoo Financije';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Terület';
localizedStrings['Square Inch'] = 'Négyzethüvelyk';
localizedStrings['Square Kilometer'] = 'Négyzetkilométer';
localizedStrings['Square Foot'] = 'Négyzetláb';
localizedStrings['Square Centimeter'] = 'Négyzetcentiméter';
localizedStrings['Square Yard'] = 'Négyzetyard';
localizedStrings['Square Millimeter'] = 'Négyzetmilliméter';
localizedStrings['Square Meter'] = 'Négyzetméter';
localizedStrings['Square Mile'] = 'Négyzetmérföld';
localizedStrings['Acre'] = 'Hold';
localizedStrings['Hectare'] = 'Hektár';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Kilogramm-méter';
localizedStrings['Foot-Pounds'] = 'Lábfont';
localizedStrings['Kilogram-Calories'] = 'Kilogrammkalória';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Kilowattóra';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtonméter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalória';
localizedStrings['Watt-Hours'] = 'Wattóra';

localizedStrings['Temperature'] = 'Hőmérséklet';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Hosszúság';
localizedStrings['Inch'] = 'Hüvelyk';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Mérföld (tengeri)';
localizedStrings['Centimeter'] = 'Centiméter';
localizedStrings['Meter'] = 'Méter';
localizedStrings['Mile'] = 'Mérföld';
localizedStrings['Foot'] = 'Láb';
localizedStrings['Kilometer'] = 'Kilométer';
localizedStrings['Millimeter'] = 'Milliméter';

localizedStrings['Weight'] = 'Súly';
localizedStrings['Pound (US)'] = 'Font (USA)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Rövid tonna (USA)';
localizedStrings['Metric Ton'] = 'Metrikus tonna';
localizedStrings['Ounce (US)'] = 'Uncia (USA)';
localizedStrings['Gram'] = 'Gramm';
localizedStrings['Long Ton (UK)'] = 'Hosszútonna (UK)';
localizedStrings['Kilogram'] = 'Kilogramm';

localizedStrings['Speed'] = 'Sebesség';
localizedStrings['Feet/Minute'] = 'Láb/perc';
localizedStrings['Kilometers/Hour'] = 'Kilométer/óra';
localizedStrings['Miles/Minute'] = 'Mérföld/perc';
localizedStrings['Kilometers/Minute'] = 'Kilométer/perc';
localizedStrings['Feet/Second'] = 'Láb/másodperc';
localizedStrings['Meters/Second'] = 'Méter/másodperc';
localizedStrings['Knots'] = 'Csomó';
localizedStrings['Miles/Hour'] = 'Mérföld/óra';

localizedStrings['Pressure'] = 'Nyomás';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogramm/négyzetméter';
localizedStrings['Atmospheres'] = 'Atmoszféra';
localizedStrings['Pounds/Square Foot'] = 'Font/négyzetláb';
localizedStrings['Inches of Mercury'] = 'Higanyhüvelyk';
localizedStrings['Centimeters of Mercury'] = 'Higanycentiméter';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Font/négyzethüvelyk';

localizedStrings['Power'] = 'Teljesítmény';
localizedStrings['Horsepower'] = 'Lóerő';
localizedStrings['Btus/Minute'] = 'BTU/perc';
localizedStrings['Foot-Pounds/Minute'] = 'Lábfont/perc';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Lábfont/másodperc';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Térfogat';
localizedStrings['Pint (US)'] = 'Pint (USA)';
localizedStrings['Cup'] = 'Csésze';
localizedStrings['Tablespoon'] = 'Evőkanál';
localizedStrings['Teaspoon'] = 'Teáskanál';
localizedStrings['Gallon (US)'] = 'Gallon (USA)';
localizedStrings['Cubic Feet'] = 'Köbláb';
localizedStrings['Cubic Meter'] = 'Köbméter';
localizedStrings['Quart (US)'] = 'Kvart (USA)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallon (birodalmi)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Folyadék uncia (USA)';

localizedStrings['Time'] = 'Idő';
localizedStrings['Hours'] = 'Óra';
localizedStrings['Minutes'] = 'Perc';
localizedStrings['Seconds'] = 'Másodperc';
localizedStrings['Milliseconds'] = 'ezredmásodperc';
localizedStrings['Microseconds'] = 'Mikromásodperc';
localizedStrings['Nanoseconds'] = 'Nanomásodperc';
localizedStrings['Weeks'] = 'Hét';
localizedStrings['Days'] = 'Nap';
localizedStrings['Years'] = 'Év';

localizedStrings['Convert'] = 'Átváltás';
localizedStrings['Currency'] = 'Pénznem';
localizedStrings['CurrencyLastUpdated'] = 'Utoljára frissítve';
localizedStrings['CurrencyNotAvailable'] = 'Az átváltási árfolyamok jelenleg nem elérhetők.';
localizedStrings['Attribution'] = 'A pénznemátváltást biztosítja:';
localizedStrings['Done'] = 'Kész';
localizedStrings['Network unavailable.'] = 'Hálózat nem elérhető.';
localizedStrings['Invalid Date'] = 'Érvénytelen dátum.';
localizedStrings['Data unavailable.'] = 'Nincs adat.';
localizedStrings['Retrieving data.'] = 'Adatok begyűjtése.';
localizedStrings['Terms of Service'] = 'Szolgáltatási feltételek';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

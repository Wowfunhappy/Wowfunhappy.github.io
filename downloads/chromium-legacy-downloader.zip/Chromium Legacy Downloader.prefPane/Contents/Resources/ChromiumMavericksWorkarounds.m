#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import "ZKSwizzle.h"

@interface myNSView : NSView
@end

@implementation myNSView
- (void) viewWillStartLiveResize {
	[self setWantsLayer:true];
	ZKOrig(void);
}
@end


@interface myNSWindow : NSWindow
@end

@implementation myNSWindow
- (void)setTitle:(id)arg1 {
	return ZKOrig(void, [arg1 stringByReplacingOccurrencesOfString:@"🔊" withString:@""]);
}
@end


@implementation NSObject (main)
+ (void)load {
	ZKSwizzle(myNSView, NSView);
	ZKSwizzle(myNSWindow, NSWindow);
}
@end
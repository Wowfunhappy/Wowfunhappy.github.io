var localizedStrings = new Array();

localizedStrings['Area'] = 'Fläche';
localizedStrings['Square Inch'] = 'Quadratzoll';
localizedStrings['Square Kilometer'] = 'Quadratkilometer';
localizedStrings['Square Foot'] = 'Quadratfuß';
localizedStrings['Square Centimeter'] = 'Quadratzentimeter';
localizedStrings['Square Yard'] = 'Quadrat-Yard';
localizedStrings['Square Millimeter'] = 'Quadratmillimeter';
localizedStrings['Square Meter'] = 'Quadratmeter';
localizedStrings['Square Mile'] = 'Quadratmeile';
localizedStrings['Acre'] = 'Morgen';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energie';
localizedStrings['Kilogram-Meters'] = 'Kilogramm-Meter';
localizedStrings['Foot-Pounds'] = 'Foot-Pounds';
localizedStrings['Kilogram-Calories'] = 'Kilogramm-Kalorien';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowattstunden';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtonmeter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalorien';
localizedStrings['Watt-Hours'] = 'Wattstunden';

localizedStrings['Temperature'] = 'Temperatur';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Länge';
localizedStrings['Inch'] = 'Zoll';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Seemeilen';
localizedStrings['Centimeter'] = 'Zentimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Meilen';
localizedStrings['Foot'] = 'Fuß';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Gewicht';
localizedStrings['Pound (US)'] = 'Pfund (USA)';
localizedStrings['Stone'] = 'Stein';
localizedStrings['Short Ton (US)'] = 'Short Ton (USA)';
localizedStrings['Metric Ton'] = 'Tonne (metrisch)';
localizedStrings['Ounce (US)'] = 'Unze (USA)';
localizedStrings['Gram'] = 'Gramm';
localizedStrings['Long Ton (UK)'] = 'Long Ton (GB)';
localizedStrings['Kilogram'] = 'Kilogramm';

localizedStrings['Speed'] = 'Geschwindigkeit';
localizedStrings['Feet/Minute'] = 'Fuß/Minute';
localizedStrings['Kilometers/Hour'] = 'Kilometer/Stunde';
localizedStrings['Miles/Minute'] = 'Meilen/Minute';
localizedStrings['Kilometers/Minute'] = 'Kilometer/Minute';
localizedStrings['Feet/Second'] = 'Fuß/Sekunde';
localizedStrings['Meters/Second'] = 'Meter/Sekunde';
localizedStrings['Knots'] = 'Knoten';
localizedStrings['Miles/Hour'] = 'Meilen/Stunde';

localizedStrings['Pressure'] = 'Druck';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogramm/Quadratmeter';
localizedStrings['Atmospheres'] = 'Atmosphären';
localizedStrings['Pounds/Square Foot'] = 'Pfund/Quadratfuß';
localizedStrings['Inches of Mercury'] = 'Zoll Quecksilbersäule';
localizedStrings['Centimeters of Mercury'] = 'Zentimeter Quecksilbersäule';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pfund/Quadratzoll';

localizedStrings['Power'] = 'Leistung';
localizedStrings['Horsepower'] = 'Pferdestärken';
localizedStrings['Btus/Minute'] = 'BTU/Minute';
localizedStrings['Foot-Pounds/Minute'] = 'Foot-Pounds/Minute';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Foot-Pounds/Sekunde';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Volumen';
localizedStrings['Pint (US)'] = 'Pint (USA)';
localizedStrings['Cup'] = 'Tasse';
localizedStrings['Tablespoon'] = 'Esslöffel';
localizedStrings['Teaspoon'] = 'Teelöffel';
localizedStrings['Gallon (US)'] = 'Gallone (US)';
localizedStrings['Cubic Feet'] = 'Kubikfuß';
localizedStrings['Cubic Meter'] = 'Kubikmeter';
localizedStrings['Quart (US)'] = 'Quart (USA)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallone (Britisch)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Flüssig-Unze (USA)';

localizedStrings['Time'] = 'Zeit';
localizedStrings['Hours'] = 'Stunden';
localizedStrings['Minutes'] = 'Minuten';
localizedStrings['Seconds'] = 'Sekunden';
localizedStrings['Milliseconds'] = 'Millisekunden';
localizedStrings['Microseconds'] = 'Mikrosekunden';
localizedStrings['Nanoseconds'] = 'Nanosekunden';
localizedStrings['Weeks'] = 'Wochen';
localizedStrings['Days'] = 'Tage';
localizedStrings['Years'] = 'Jahre';

localizedStrings['Convert'] = 'Umrechnen';
localizedStrings['Currency'] = 'Währungen';
localizedStrings['CurrencyLastUpdated'] = 'Zuletzt aktualisiert';
localizedStrings['CurrencyNotAvailable'] = 'Die Währungskurse sind zurzeit nicht verfügbar.';
localizedStrings['Attribution'] = 'Währungskurse zur Verfügung gestellt von';
localizedStrings['Done'] = 'Fertig';
localizedStrings['Network unavailable.'] = 'Netzwerk nicht verfügbar';
localizedStrings['Invalid Date'] = 'Ungültiges Datum.';
localizedStrings['Data unavailable.'] = 'Währungskurse nicht verfügbar';
localizedStrings['Retrieving data.'] = 'Währungskurse abfragen';
localizedStrings['Terms of Service'] = 'Geschäftsbedingungen';
localizedStrings['Yahoo Finance'] = 'Yahoo Finanzen';

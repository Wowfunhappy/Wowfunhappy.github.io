var localizedStrings = new Array();

localizedStrings['Area'] = 'Diện tích';
localizedStrings['Square Inch'] = 'Inch Vuông';
localizedStrings['Square Kilometer'] = 'Kilomét Vuông';
localizedStrings['Square Foot'] = 'Foot Vuông';
localizedStrings['Square Centimeter'] = 'Centimét Vuông';
localizedStrings['Square Yard'] = 'Yard Vuông';
localizedStrings['Square Millimeter'] = 'Milimét Vuông';
localizedStrings['Square Meter'] = 'Mét Vuông';
localizedStrings['Square Mile'] = 'Dặm Vuông';
localizedStrings['Acre'] = 'Mẫu Anh';
localizedStrings['Hectare'] = 'Hecta';

localizedStrings['Energy'] = 'Năng lượng';
localizedStrings['Kilogram-Meters'] = 'Kilôgam-Mét';
localizedStrings['Foot-Pounds'] = 'Foot-Pound';
localizedStrings['Kilogram-Calories'] = 'Kilôgam-Calo';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilôwatt-Giờ';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton-Mét';
localizedStrings['Joules'] = 'Jun';
localizedStrings['Calories'] = 'Calo';
localizedStrings['Watt-Hours'] = 'Watt-Giờ';

localizedStrings['Temperature'] = 'Nhiệt độ';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Độ dài';
localizedStrings['Inch'] = 'Inch';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Hải lý';
localizedStrings['Centimeter'] = 'Centimét';
localizedStrings['Meter'] = 'Mét';
localizedStrings['Mile'] = 'Dặm';
localizedStrings['Foot'] = 'Foot';
localizedStrings['Kilometer'] = 'Kilômét';
localizedStrings['Millimeter'] = 'Milimét';

localizedStrings['Weight'] = 'Trọng lượng';
localizedStrings['Pound (US)'] = 'Pound (Mỹ)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tấn Mỹ';
localizedStrings['Metric Ton'] = 'Tấn';
localizedStrings['Ounce (US)'] = 'Ounce (Mỹ)';
localizedStrings['Gram'] = 'Gam';
localizedStrings['Long Ton (UK)'] = 'Tấn Anh';
localizedStrings['Kilogram'] = 'Kilôgam';

localizedStrings['Speed'] = 'Tốc độ';
localizedStrings['Feet/Minute'] = 'Foot/Phút';
localizedStrings['Kilometers/Hour'] = 'Kilômét/Giờ';
localizedStrings['Miles/Minute'] = 'Dặm/Phút';
localizedStrings['Kilometers/Minute'] = 'Kilômét/Phút';
localizedStrings['Feet/Second'] = 'Foot/Giây';
localizedStrings['Meters/Second'] = 'Mét/Giây';
localizedStrings['Knots'] = 'Hải lý/Giờ';
localizedStrings['Miles/Hour'] = 'Dặm/Giờ';

localizedStrings['Pressure'] = 'Áp suất';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilôgam/Mét Vuông';
localizedStrings['Atmospheres'] = 'Atmosphere';
localizedStrings['Pounds/Square Foot'] = 'Pound/Foot Vuông';
localizedStrings['Inches of Mercury'] = 'Inch Thủy ngân';
localizedStrings['Centimeters of Mercury'] = 'Centimét Thủy ngân';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pound/Inch Vuông';

localizedStrings['Power'] = 'Công suất';
localizedStrings['Horsepower'] = 'Mã lực';
localizedStrings['Btus/Minute'] = 'Btu/Phút';
localizedStrings['Foot-Pounds/Minute'] = 'Foot-Pound/Phút';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Foot-Pound/Giây';
localizedStrings['Kilowatts'] = 'Kilôwatt';

localizedStrings['Volume'] = 'Thể tích';
localizedStrings['Pint (US)'] = 'Pint (Mỹ)';
localizedStrings['Cup'] = 'Cốc';
localizedStrings['Tablespoon'] = 'Muỗng canh';
localizedStrings['Teaspoon'] = 'Muỗng cà phê';
localizedStrings['Gallon (US)'] = 'Gallon (Mỹ)';
localizedStrings['Cubic Feet'] = 'Foot Khối';
localizedStrings['Cubic Meter'] = 'Mét Khối';
localizedStrings['Quart (US)'] = 'Quart (Mỹ)';
localizedStrings['Liter'] = 'Lít';
localizedStrings['Gallon (Imperial)'] = 'Gallon (Anh)';
localizedStrings['Dram (US)'] = 'Dram (Mỹ)';
localizedStrings['Fluid Ounce (US)'] = 'Ounce Lỏng (Mỹ)';

localizedStrings['Time'] = 'Thời gian';
localizedStrings['Hours'] = 'Giờ';
localizedStrings['Minutes'] = 'Phút';
localizedStrings['Seconds'] = 'Giây';
localizedStrings['Milliseconds'] = 'Mili giây';
localizedStrings['Microseconds'] = 'Micro giây';
localizedStrings['Nanoseconds'] = 'Nano giây';
localizedStrings['Weeks'] = 'Tuần';
localizedStrings['Days'] = 'Ngày';
localizedStrings['Years'] = 'Năm';

localizedStrings['Convert'] = 'Chuyển đổi';
localizedStrings['Currency'] = 'Loại tiền';
localizedStrings['CurrencyLastUpdated'] = 'Cập nhật Lần cuối';
localizedStrings['CurrencyNotAvailable'] = 'Tỷ giá hiện không khả dụng.';
localizedStrings['Attribution'] = 'Tỷ giá hối đoái được cung cấp bởi';
localizedStrings['Done'] = 'Xong';
localizedStrings['Network unavailable.'] = 'Mạng không khả dụng.';
localizedStrings['Invalid Date'] = 'Ngày Không hợp lệ.';
localizedStrings['Data unavailable.'] = 'Dữ liệu không khả dụng.';
localizedStrings['Retrieving data.'] = 'Truy xuất dữ liệu.';
localizedStrings['Terms of Service'] = 'Điều khoản Dịch vụ';
localizedStrings['Yahoo Finance'] = 'Tài chính Yahoo';

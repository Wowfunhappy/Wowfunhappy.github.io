var localizedStrings = new Array();

localizedStrings['Area'] = 'Areal';
localizedStrings['Square Inch'] = 'Kvadrattommer';
localizedStrings['Square Kilometer'] = 'Kvadratkilometer';
localizedStrings['Square Foot'] = 'Kvadratfot';
localizedStrings['Square Centimeter'] = 'Kvadratcentimeter';
localizedStrings['Square Yard'] = 'Kvadratyard';
localizedStrings['Square Millimeter'] = 'Kvadratmillimeter';
localizedStrings['Square Meter'] = 'Kvadratmeter';
localizedStrings['Square Mile'] = 'Kvadratmile';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energi';
localizedStrings['Kilogram-Meters'] = 'Kilogrammeter';
localizedStrings['Foot-Pounds'] = 'Fotpund';
localizedStrings['Kilogram-Calories'] = 'Kilokalorier';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowattimer';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newtonmeter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalorier';
localizedStrings['Watt-Hours'] = 'Watt-timer';

localizedStrings['Temperature'] = 'Temperatur';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Lengde';
localizedStrings['Inch'] = 'Tommer';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Nautisk mil';
localizedStrings['Centimeter'] = 'Centimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mile';
localizedStrings['Foot'] = 'Fot';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Vekt';
localizedStrings['Pound (US)'] = 'Pund (USA)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Amerikansk tonn';
localizedStrings['Metric Ton'] = 'Tonn (metrisk)';
localizedStrings['Ounce (US)'] = 'Unse (USA)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Britisk tonn';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Hastighet';
localizedStrings['Feet/Minute'] = 'Fot/minutt';
localizedStrings['Kilometers/Hour'] = 'Kilometer/time';
localizedStrings['Miles/Minute'] = 'Mile/minutt';
localizedStrings['Kilometers/Minute'] = 'Kilometer/minutt';
localizedStrings['Feet/Second'] = 'Fot/sekund';
localizedStrings['Meters/Second'] = 'Meter/sekund';
localizedStrings['Knots'] = 'Knop';
localizedStrings['Miles/Hour'] = 'Mile/time';

localizedStrings['Pressure'] = 'Trykk';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/kvadratmeter';
localizedStrings['Atmospheres'] = 'Atmosfærer';
localizedStrings['Pounds/Square Foot'] = 'Pund/kvadratfot';
localizedStrings['Inches of Mercury'] = 'Kvikksølvtommer';
localizedStrings['Centimeters of Mercury'] = 'Kvikksølvcentimeter';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pund/kvadrattomme';

localizedStrings['Power'] = 'Energi';
localizedStrings['Horsepower'] = 'Hestekrefter';
localizedStrings['Btus/Minute'] = 'Btu/minutt';
localizedStrings['Foot-Pounds/Minute'] = 'Fotpund/minutt';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Fotpund/sekund';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Volum';
localizedStrings['Pint (US)'] = 'Pint (USA)';
localizedStrings['Cup'] = 'Kopp';
localizedStrings['Tablespoon'] = 'Spiseskje';
localizedStrings['Teaspoon'] = 'Teskje';
localizedStrings['Gallon (US)'] = 'Gallon (USA)';
localizedStrings['Cubic Feet'] = 'Kubikkfot';
localizedStrings['Cubic Meter'] = 'Kubikkmeter';
localizedStrings['Quart (US)'] = 'Quart (USA)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gallon (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (USA)';
localizedStrings['Fluid Ounce (US)'] = 'Flytende unse (USA)';

localizedStrings['Time'] = 'Tid';
localizedStrings['Hours'] = 'Timer';
localizedStrings['Minutes'] = 'Minutter';
localizedStrings['Seconds'] = 'Sekunder';
localizedStrings['Milliseconds'] = 'Millisekunder';
localizedStrings['Microseconds'] = 'Mikrosekunder';
localizedStrings['Nanoseconds'] = 'Nanosekunder';
localizedStrings['Weeks'] = 'Uker';
localizedStrings['Days'] = 'Dager';
localizedStrings['Years'] = 'År';

localizedStrings['Convert'] = 'Konverter';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Sist oppdatert';
localizedStrings['CurrencyNotAvailable'] = 'Valutakurser er ikke tilgjengelig.';
localizedStrings['Attribution'] = 'Valutakurser leveres av';
localizedStrings['Done'] = 'Ferdig';
localizedStrings['Network unavailable.'] = 'Nettverk ikke tilgjengelig.';
localizedStrings['Invalid Date'] = 'Ugyldig dato.';
localizedStrings['Data unavailable.'] = 'Data ikke tilgjengelig.';
localizedStrings['Retrieving data.'] = 'Henter data.';
localizedStrings['Terms of Service'] = 'Tjenestevilkår';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

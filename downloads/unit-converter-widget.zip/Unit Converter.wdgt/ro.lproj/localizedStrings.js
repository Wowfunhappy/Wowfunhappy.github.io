var localizedStrings = new Array();

localizedStrings['Area'] = 'Arie';
localizedStrings['Square Inch'] = 'Inch pătrat';
localizedStrings['Square Kilometer'] = 'Kilometru pătrat';
localizedStrings['Square Foot'] = 'Picior pătrat';
localizedStrings['Square Centimeter'] = 'Centimetru pătrat';
localizedStrings['Square Yard'] = 'Iard pătrat';
localizedStrings['Square Millimeter'] = 'Milimetru pătrat';
localizedStrings['Square Meter'] = 'Metru pătrat';
localizedStrings['Square Mile'] = 'Milă pătrată';
localizedStrings['Acre'] = 'Acru';
localizedStrings['Hectare'] = 'Hectar';

localizedStrings['Energy'] = 'Energie';
localizedStrings['Kilogram-Meters'] = 'Kilogram-metri';
localizedStrings['Foot-Pounds'] = 'Picioare-livre';
localizedStrings['Kilogram-Calories'] = 'Kilogram-calorii';
localizedStrings['Ergs'] = 'Ergi';
localizedStrings['Kilowatt-Hours'] = 'Kilowați-oră';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton-metri';
localizedStrings['Joules'] = 'Jouli';
localizedStrings['Calories'] = 'Calorii';
localizedStrings['Watt-Hours'] = 'Watt-oră';

localizedStrings['Temperature'] = 'Temperatură';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Lungime';
localizedStrings['Inch'] = 'Inch';
localizedStrings['Yard'] = 'Iard';
localizedStrings['Mile (nautical)'] = 'Milă (nautică)';
localizedStrings['Centimeter'] = 'Centimetru';
localizedStrings['Meter'] = 'Metru';
localizedStrings['Mile'] = 'Milă';
localizedStrings['Foot'] = 'Picior';
localizedStrings['Kilometer'] = 'Kilometru';
localizedStrings['Millimeter'] = 'Milimetru';

localizedStrings['Weight'] = 'Greutate';
localizedStrings['Pound (US)'] = 'Livră (S.U.A)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tonă americană (S.U.A)';
localizedStrings['Metric Ton'] = 'Tonă metrică';
localizedStrings['Ounce (US)'] = 'Uncie (SUA)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Tonă engleză (britanică)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Viteză';
localizedStrings['Feet/Minute'] = 'Picioare/minut';
localizedStrings['Kilometers/Hour'] = 'Kilometri/oră';
localizedStrings['Miles/Minute'] = 'Mile/minut';
localizedStrings['Kilometers/Minute'] = 'Kilometri/minut';
localizedStrings['Feet/Second'] = 'Picioare/secundă';
localizedStrings['Meters/Second'] = 'Metri/secundă';
localizedStrings['Knots'] = 'Noduri';
localizedStrings['Miles/Hour'] = 'Mile/oră';

localizedStrings['Pressure'] = 'Presiune';
localizedStrings['Bars'] = 'Bari';
localizedStrings['Kilograms/Square Meter'] = 'Kilograme/metru pătrat';
localizedStrings['Atmospheres'] = 'Atmosfere';
localizedStrings['Pounds/Square Foot'] = 'Livre/picior pătrat';
localizedStrings['Inches of Mercury'] = 'Inch de mercur';
localizedStrings['Centimeters of Mercury'] = 'Centimetri de mercur';
localizedStrings['Pascals'] = 'Pascali';
localizedStrings['Pounds/Square Inch'] = 'Livre/inch pătrat';

localizedStrings['Power'] = 'Putere';
localizedStrings['Horsepower'] = 'Cal-putere';
localizedStrings['Btus/Minute'] = 'Btu/minut';
localizedStrings['Foot-Pounds/Minute'] = 'Picioare-livre/minut';
localizedStrings['Watts'] = 'Wați';
localizedStrings['Foot-Pounds/Second'] = 'Picioare-livre/secundă';
localizedStrings['Kilowatts'] = 'Kilowați';

localizedStrings['Volume'] = 'Volum';
localizedStrings['Pint (US)'] = 'Pintă (S.U.A)';
localizedStrings['Cup'] = 'Cupă';
localizedStrings['Tablespoon'] = 'Lingură';
localizedStrings['Teaspoon'] = 'Linguriță';
localizedStrings['Gallon (US)'] = 'Galon (S.U.A)';
localizedStrings['Cubic Feet'] = 'Picior cub';
localizedStrings['Cubic Meter'] = 'Metru cub';
localizedStrings['Quart (US)'] = 'Sfert de galon (S.U.A)';
localizedStrings['Liter'] = 'Litru';
localizedStrings['Gallon (Imperial)'] = 'Galon (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (S.U.A)';
localizedStrings['Fluid Ounce (US)'] = 'Uncie lichidă (S.U.A)';

localizedStrings['Time'] = 'Timp';
localizedStrings['Hours'] = 'Ore';
localizedStrings['Minutes'] = 'Minute';
localizedStrings['Seconds'] = 'Secunde';
localizedStrings['Milliseconds'] = 'Milisecunde';
localizedStrings['Microseconds'] = 'Microsecunde';
localizedStrings['Nanoseconds'] = 'Nanosecunde';
localizedStrings['Weeks'] = 'Săptămâni';
localizedStrings['Days'] = 'Zile';
localizedStrings['Years'] = 'Ani';

localizedStrings['Convert'] = 'Convertește';
localizedStrings['Currency'] = 'Monedă';
localizedStrings['CurrencyLastUpdated'] = 'Ultima actualizare';
localizedStrings['CurrencyNotAvailable'] = 'Cursurile de schimb sunt momentan indisponibile.';
localizedStrings['Attribution'] = 'Schimb valutar furnizat de';
localizedStrings['Done'] = 'OK';
localizedStrings['Network unavailable.'] = 'Rețea indisponibilă.';
localizedStrings['Invalid Date'] = 'Dată nevalidă.';
localizedStrings['Data unavailable.'] = 'Date indisponibile.';
localizedStrings['Retrieving data.'] = 'Recuperare date.';
localizedStrings['Terms of Service'] = 'Termene de serviciu';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

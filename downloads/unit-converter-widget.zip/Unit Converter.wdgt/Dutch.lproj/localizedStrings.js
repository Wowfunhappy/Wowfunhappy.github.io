var localizedStrings = new Array();

localizedStrings['Area'] = 'Oppervlakte';
localizedStrings['Square Inch'] = 'Vierkante inch';
localizedStrings['Square Kilometer'] = 'Vierkante kilometer';
localizedStrings['Square Foot'] = 'Vierkante voet';
localizedStrings['Square Centimeter'] = 'Vierkante centimeter';
localizedStrings['Square Yard'] = 'Vierkante yard';
localizedStrings['Square Millimeter'] = 'Vierkante millimeter';
localizedStrings['Square Meter'] = 'Vierkante meter';
localizedStrings['Square Mile'] = 'Vierkante mijl';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectare';

localizedStrings['Energy'] = 'Energie';
localizedStrings['Kilogram-Meters'] = 'Kilogrammeter';
localizedStrings['Foot-Pounds'] = 'Foot-Pound';
localizedStrings['Kilogram-Calories'] = 'Kilogramcalorie';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowattuur';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtonmeter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Calorie';
localizedStrings['Watt-Hours'] = 'Wattuur';

localizedStrings['Temperature'] = 'Temperatuur';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Lengte';
localizedStrings['Inch'] = 'Inch';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Mijl (nautisch)';
localizedStrings['Centimeter'] = 'Centimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mijl';
localizedStrings['Foot'] = 'Voet';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Gewicht';
localizedStrings['Pound (US)'] = 'Pound (VS)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Short Ton (VS)';
localizedStrings['Metric Ton'] = 'Metrische ton';
localizedStrings['Ounce (US)'] = 'Ounce (VS)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Long Ton (VK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Snelheid';
localizedStrings['Feet/Minute'] = 'Voet/minuut';
localizedStrings['Kilometers/Hour'] = 'Kilometer/uur';
localizedStrings['Miles/Minute'] = 'Mijl/minuut';
localizedStrings['Kilometers/Minute'] = 'Kilometer/minuut';
localizedStrings['Feet/Second'] = 'Voet/seconde';
localizedStrings['Meters/Second'] = 'Meter/seconde';
localizedStrings['Knots'] = 'Knopen';
localizedStrings['Miles/Hour'] = 'Mijl/uur';

localizedStrings['Pressure'] = 'Druk';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/vierkante meter';
localizedStrings['Atmospheres'] = 'Atmosfeer';
localizedStrings['Pounds/Square Foot'] = 'Pound/vierkante voet';
localizedStrings['Inches of Mercury'] = 'Inch (kwik)';
localizedStrings['Centimeters of Mercury'] = 'Centimeter (kwik)';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pound/vierkante inch';

localizedStrings['Power'] = 'Vermogen';
localizedStrings['Horsepower'] = 'Paardenkracht';
localizedStrings['Btus/Minute'] = 'BTU/minuut';
localizedStrings['Foot-Pounds/Minute'] = 'Foot-Pound/minuut';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Foot-Pound/seconde';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Pint (VS)';
localizedStrings['Cup'] = 'Kop';
localizedStrings['Tablespoon'] = 'Eetlepel';
localizedStrings['Teaspoon'] = 'Theelepel';
localizedStrings['Gallon (US)'] = 'US gallon';
localizedStrings['Cubic Feet'] = 'Kubieke voet';
localizedStrings['Cubic Meter'] = 'Kubieke meter';
localizedStrings['Quart (US)'] = 'Quart (VS)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Imperial gallon';
localizedStrings['Dram (US)'] = 'Dram (VS)';
localizedStrings['Fluid Ounce (US)'] = 'Fluid Ounce (VS)';

localizedStrings['Time'] = 'Tijd';
localizedStrings['Hours'] = 'Uur';
localizedStrings['Minutes'] = 'Minuut';
localizedStrings['Seconds'] = 'Seconde';
localizedStrings['Milliseconds'] = 'Milliseconde';
localizedStrings['Microseconds'] = 'Microseconde';
localizedStrings['Nanoseconds'] = 'Nanoseconde';
localizedStrings['Weeks'] = 'Week';
localizedStrings['Days'] = 'Dag';
localizedStrings['Years'] = 'Jaar';

localizedStrings['Convert'] = 'Converteer';
localizedStrings['Currency'] = 'Valuta';
localizedStrings['CurrencyLastUpdated'] = 'Laatst bijgewerkt';
localizedStrings['CurrencyNotAvailable'] = 'Wisselkoersen zijn momenteel niet beschikbaar.';
localizedStrings['Attribution'] = 'Wisselkoersen afkomstig van';
localizedStrings['Done'] = 'Gereed';
localizedStrings['Network unavailable.'] = 'Netwerk niet beschikbaar.';
localizedStrings['Invalid Date'] = 'Ongeldige datum.';
localizedStrings['Data unavailable.'] = 'Gegevens niet beschikbaar.';
localizedStrings['Retrieving data.'] = 'Gegevens ophalen.';
localizedStrings['Terms of Service'] = 'Servicevoorwaarden';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

var localizedStrings = new Array();

localizedStrings['Area'] = 'Kawasan';
localizedStrings['Square Inch'] = 'Inci Persegi';
localizedStrings['Square Kilometer'] = 'Kilometer Persegi';
localizedStrings['Square Foot'] = 'Kaki Persegi';
localizedStrings['Square Centimeter'] = 'Sentimeter Persegi';
localizedStrings['Square Yard'] = 'Ela Persegi';
localizedStrings['Square Millimeter'] = 'Milimeter Persegi';
localizedStrings['Square Meter'] = 'Meter Persegi';
localizedStrings['Square Mile'] = 'Batu Persegi';
localizedStrings['Acre'] = 'Ekar';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Tenaga';
localizedStrings['Kilogram-Meters'] = 'Kilogram-Meter';
localizedStrings['Foot-Pounds'] = 'Kaki-Paun';
localizedStrings['Kilogram-Calories'] = 'Kilogram-Kalori';
localizedStrings['Ergs'] = 'Erg';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-Jam';
localizedStrings['Btus'] = 'Btu';
localizedStrings['Newton-Meters'] = 'Newton-Meter';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Kalori';
localizedStrings['Watt-Hours'] = 'Watt-Jam';

localizedStrings['Temperature'] = 'Suhu';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Panjang';
localizedStrings['Inch'] = 'Inci';
localizedStrings['Yard'] = 'Ela';
localizedStrings['Mile (nautical)'] = 'Mile (nautika)';
localizedStrings['Centimeter'] = 'Sentimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Batu';
localizedStrings['Foot'] = 'Kaki';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Berat';
localizedStrings['Pound (US)'] = 'Paun (US)';
localizedStrings['Stone'] = 'Batu';
localizedStrings['Short Ton (US)'] = 'Ton Amerika (US)';
localizedStrings['Metric Ton'] = 'Ton Metrik';
localizedStrings['Ounce (US)'] = 'Auns (US)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Ton Inggeris (UK)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Kelajuan';
localizedStrings['Feet/Minute'] = 'Kaki/Minit';
localizedStrings['Kilometers/Hour'] = 'Kilometer/Jam';
localizedStrings['Miles/Minute'] = 'Batu/Minit';
localizedStrings['Kilometers/Minute'] = 'Kilometer/Minit';
localizedStrings['Feet/Second'] = 'Kaki/Saat';
localizedStrings['Meters/Second'] = 'Meter/Saat';
localizedStrings['Knots'] = 'Knot';
localizedStrings['Miles/Hour'] = 'Batu/Jam';

localizedStrings['Pressure'] = 'Tekanan';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/Meter Persegi';
localizedStrings['Atmospheres'] = 'Atmosfera';
localizedStrings['Pounds/Square Foot'] = 'Paun/Kaki Persegi';
localizedStrings['Inches of Mercury'] = 'Inci Merkuri';
localizedStrings['Centimeters of Mercury'] = 'Sentimeter Merkuri';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Paun/Inci Persegi';

localizedStrings['Power'] = 'Kuasa';
localizedStrings['Horsepower'] = 'Kuasa kuda';
localizedStrings['Btus/Minute'] = 'Btu/Minit';
localizedStrings['Foot-Pounds/Minute'] = 'Kaki-Paun/Minit';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Kaki-Paun/Saat';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Isipadu';
localizedStrings['Pint (US)'] = 'Pain (US)';
localizedStrings['Cup'] = 'Cawan';
localizedStrings['Tablespoon'] = 'Sudu meja';
localizedStrings['Teaspoon'] = 'Sudu teh';
localizedStrings['Gallon (US)'] = 'Gelen (US)';
localizedStrings['Cubic Feet'] = 'Kaki Padu';
localizedStrings['Cubic Meter'] = 'Meter Padu';
localizedStrings['Quart (US)'] = 'Kuart (US)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Gelen (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (US)';
localizedStrings['Fluid Ounce (US)'] = 'Auns Bendalir (US)';

localizedStrings['Time'] = 'Masa';
localizedStrings['Hours'] = 'Jam';
localizedStrings['Minutes'] = 'Minit';
localizedStrings['Seconds'] = 'Saat';
localizedStrings['Milliseconds'] = 'Milisaat';
localizedStrings['Microseconds'] = 'Mikrosaat';
localizedStrings['Nanoseconds'] = 'Nanosaat';
localizedStrings['Weeks'] = 'Minggu';
localizedStrings['Days'] = 'Hari';
localizedStrings['Years'] = 'Tahun';

localizedStrings['Convert'] = 'Tukar';
localizedStrings['Currency'] = 'Mata Wang';
localizedStrings['CurrencyLastUpdated'] = 'Terakhir Dikemaskini';
localizedStrings['CurrencyNotAvailable'] = 'Kadar pertukaran tidak tersedia sekarang.';
localizedStrings['Attribution'] = 'Pertukaran mata wang dibekalkan oleh';
localizedStrings['Done'] = 'Selesai';
localizedStrings['Network unavailable.'] = 'Rangkaian tidak tersedia.';
localizedStrings['Invalid Date'] = 'Tarikh Tidah Sah.';
localizedStrings['Data unavailable.'] = 'Data tidak tersedia.';
localizedStrings['Retrieving data.'] = 'Sedang mendapatkan data.';
localizedStrings['Terms of Service'] = 'Terma Perkhidmatan';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

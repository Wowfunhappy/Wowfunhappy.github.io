var localizedStrings = new Array();

localizedStrings['Area'] = 'Площадь';
localizedStrings['Square Inch'] = 'Кв. дюйм';
localizedStrings['Square Kilometer'] = 'Кв. километр';
localizedStrings['Square Foot'] = 'Кв. футы';
localizedStrings['Square Centimeter'] = 'Кв. сантиметр';
localizedStrings['Square Yard'] = 'Кв. ярд';
localizedStrings['Square Millimeter'] = 'Кв. миллиметр';
localizedStrings['Square Meter'] = 'Кв. метр';
localizedStrings['Square Mile'] = 'Кв. миля';
localizedStrings['Acre'] = 'Акр';
localizedStrings['Hectare'] = 'Гектар';

localizedStrings['Energy'] = 'Энергия';
localizedStrings['Kilogram-Meters'] = 'Килограмм-метры';
localizedStrings['Foot-Pounds'] = 'Фут-фунты';
localizedStrings['Kilogram-Calories'] = 'Килокалории';
localizedStrings['Ergs'] = 'Эрги';
localizedStrings['Kilowatt-Hours'] = 'Киловатт-часы';
localizedStrings['Btus'] = 'БТЕ';
localizedStrings['Newton-Meters'] = 'Ньютон-метры';
localizedStrings['Joules'] = 'Джоули';
localizedStrings['Calories'] = 'Калории';
localizedStrings['Watt-Hours'] = 'Ватт-часы';

localizedStrings['Temperature'] = 'Температура';
localizedStrings['Fahrenheit'] = 'Фаренгейт';
localizedStrings['Kelvin'] = 'Кельвин';
localizedStrings['Celsius'] = 'Цельсий';

localizedStrings['Length'] = 'Длина';
localizedStrings['Inch'] = 'Дюйм';
localizedStrings['Yard'] = 'Ярд';
localizedStrings['Mile (nautical)'] = 'Миля (морская)';
localizedStrings['Centimeter'] = 'Сантиметр';
localizedStrings['Meter'] = 'Метр';
localizedStrings['Mile'] = 'Миля';
localizedStrings['Foot'] = 'Футы';
localizedStrings['Kilometer'] = 'Километр';
localizedStrings['Millimeter'] = 'Миллиметр';

localizedStrings['Weight'] = 'Масса';
localizedStrings['Pound (US)'] = 'Фунт (США)';
localizedStrings['Stone'] = 'Камень';
localizedStrings['Short Ton (US)'] = 'Кор. тонна (США)';
localizedStrings['Metric Ton'] = 'Метрич. тонна';
localizedStrings['Ounce (US)'] = 'Унция (США)';
localizedStrings['Gram'] = 'Грамм';
localizedStrings['Long Ton (UK)'] = 'Дл. тонна (Великобритания)';
localizedStrings['Kilogram'] = 'Килограммы';

localizedStrings['Speed'] = 'Скорость';
localizedStrings['Feet/Minute'] = 'Футы/мин';
localizedStrings['Kilometers/Hour'] = 'Километры/ч';
localizedStrings['Miles/Minute'] = 'Мили/мин';
localizedStrings['Kilometers/Minute'] = 'Километры/мин';
localizedStrings['Feet/Second'] = 'Футы/с';
localizedStrings['Meters/Second'] = 'Метры/с';
localizedStrings['Knots'] = 'Узлы';
localizedStrings['Miles/Hour'] = 'Мили/ч';

localizedStrings['Pressure'] = 'Давление';
localizedStrings['Bars'] = 'Бары';
localizedStrings['Kilograms/Square Meter'] = 'Килогр./кв. метр';
localizedStrings['Atmospheres'] = 'Атмосферы';
localizedStrings['Pounds/Square Foot'] = 'Фунты/кв. футы';
localizedStrings['Inches of Mercury'] = 'Дюймы рт. столба';
localizedStrings['Centimeters of Mercury'] = 'См. рт. столба';
localizedStrings['Pascals'] = 'Паскали';
localizedStrings['Pounds/Square Inch'] = 'Фунты/кв. дюйм';

localizedStrings['Power'] = 'Мощность';
localizedStrings['Horsepower'] = 'Лошадиные силы';
localizedStrings['Btus/Minute'] = 'БТЕ/мин';
localizedStrings['Foot-Pounds/Minute'] = 'Фут-фунты/мин';
localizedStrings['Watts'] = 'Ватты';
localizedStrings['Foot-Pounds/Second'] = 'Фут-фунты/с';
localizedStrings['Kilowatts'] = 'Киловатты';

localizedStrings['Volume'] = 'Объем';
localizedStrings['Pint (US)'] = 'Пинта (США)';
localizedStrings['Cup'] = 'Чашка';
localizedStrings['Tablespoon'] = 'Столовая ложка';
localizedStrings['Teaspoon'] = 'Чайная ложка';
localizedStrings['Gallon (US)'] = 'Галлон (США)';
localizedStrings['Cubic Feet'] = 'Кубические футы';
localizedStrings['Cubic Meter'] = 'Кубический метр';
localizedStrings['Quart (US)'] = 'Кварта (США)';
localizedStrings['Liter'] = 'Литр';
localizedStrings['Gallon (Imperial)'] = 'Галлон (англ.)';
localizedStrings['Dram (US)'] = 'Драхма (США)';
localizedStrings['Fluid Ounce (US)'] = 'Жидк. унция (США)';

localizedStrings['Time'] = 'Время';
localizedStrings['Hours'] = 'Час';
localizedStrings['Minutes'] = 'Минута';
localizedStrings['Seconds'] = 'Секунда';
localizedStrings['Milliseconds'] = 'Миллисекунда';
localizedStrings['Microseconds'] = 'Микросекунда';
localizedStrings['Nanoseconds'] = 'Наносекунда';
localizedStrings['Weeks'] = 'Неделя';
localizedStrings['Days'] = 'День';
localizedStrings['Years'] = 'Год';

localizedStrings['Convert'] = 'Категория';
localizedStrings['Currency'] = 'Валюта';
localizedStrings['CurrencyLastUpdated'] = 'Последнее обновление';
localizedStrings['CurrencyNotAvailable'] = 'Курсы обмена на данный момент недоступны.';
localizedStrings['Attribution'] = 'Обмен валют обеспечивается';
localizedStrings['Done'] = 'Готово';
localizedStrings['Network unavailable.'] = 'Сеть недоступна.';
localizedStrings['Invalid Date'] = 'Недействительная дата.';
localizedStrings['Data unavailable.'] = 'Данные недоступны.';
localizedStrings['Retrieving data.'] = 'Получаю данные';
localizedStrings['Terms of Service'] = 'Условия обслуживания';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

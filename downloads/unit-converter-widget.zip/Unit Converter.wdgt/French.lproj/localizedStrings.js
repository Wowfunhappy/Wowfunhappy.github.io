var localizedStrings = new Array();

localizedStrings['Area'] = 'Aire';
localizedStrings['Square Inch'] = 'Pouce carré';
localizedStrings['Square Kilometer'] = 'Kilomètre carré';
localizedStrings['Square Foot'] = 'Pied carré';
localizedStrings['Square Centimeter'] = 'Centimètre carré';
localizedStrings['Square Yard'] = 'Yard carré';
localizedStrings['Square Millimeter'] = 'Millimètre carré';
localizedStrings['Square Meter'] = 'Mètre carré';
localizedStrings['Square Mile'] = 'Mile carré';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectare';

localizedStrings['Energy'] = 'Énergie';
localizedStrings['Kilogram-Meters'] = 'Kilogramme-mètres';
localizedStrings['Foot-Pounds'] = 'Pied-livre';
localizedStrings['Kilogram-Calories'] = 'Kg-calories';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-heures';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newton-mètres';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Calories';
localizedStrings['Watt-Hours'] = 'Watt-heures';

localizedStrings['Temperature'] = 'Température';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Longueur';
localizedStrings['Inch'] = 'Pouce';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Mille nautique';
localizedStrings['Centimeter'] = 'Centimètre';
localizedStrings['Meter'] = 'Mètre';
localizedStrings['Mile'] = 'Mile';
localizedStrings['Foot'] = 'Pied';
localizedStrings['Kilometer'] = 'Kilomètre';
localizedStrings['Millimeter'] = 'Millimètre';

localizedStrings['Weight'] = 'Masse';
localizedStrings['Pound (US)'] = 'Livre américaine';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tonne américaine';
localizedStrings['Metric Ton'] = 'Tonne';
localizedStrings['Ounce (US)'] = 'Once américaine';
localizedStrings['Gram'] = 'Gramme';
localizedStrings['Long Ton (UK)'] = 'Tonne anglaise';
localizedStrings['Kilogram'] = 'Kilogramme';

localizedStrings['Speed'] = 'Vitesse';
localizedStrings['Feet/Minute'] = 'Pieds/min';
localizedStrings['Kilometers/Hour'] = 'Kilomètre/heure';
localizedStrings['Miles/Minute'] = 'Miles/minute';
localizedStrings['Kilometers/Minute'] = 'Kilomètres/minute';
localizedStrings['Feet/Second'] = 'Pieds/s';
localizedStrings['Meters/Second'] = 'Mètres/s';
localizedStrings['Knots'] = 'Nœuds';
localizedStrings['Miles/Hour'] = 'Miles/heure';

localizedStrings['Pressure'] = 'Pression';
localizedStrings['Bars'] = 'Bars';
localizedStrings['Kilograms/Square Meter'] = 'Kg/mètre carré';
localizedStrings['Atmospheres'] = 'Atmosphères';
localizedStrings['Pounds/Square Foot'] = 'Livres/pied carré';
localizedStrings['Inches of Mercury'] = 'Pouces de mercure';
localizedStrings['Centimeters of Mercury'] = 'Cm de mercure';
localizedStrings['Pascals'] = 'Pascals';
localizedStrings['Pounds/Square Inch'] = 'Livres/pouce carré';

localizedStrings['Power'] = 'Puissance';
localizedStrings['Horsepower'] = 'CV';
localizedStrings['Btus/Minute'] = 'BTU/min';
localizedStrings['Foot-Pounds/Minute'] = 'Pied-livres/min';
localizedStrings['Watts'] = 'Watts';
localizedStrings['Foot-Pounds/Second'] = 'Pied-livre/s';
localizedStrings['Kilowatts'] = 'Kilowatts';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Pinte américaine';
localizedStrings['Cup'] = 'Tasse';
localizedStrings['Tablespoon'] = 'Cuillère à soupe';
localizedStrings['Teaspoon'] = 'Cuillère à café';
localizedStrings['Gallon (US)'] = 'Gallon (américain)';
localizedStrings['Cubic Feet'] = 'Pieds cubiques';
localizedStrings['Cubic Meter'] = 'Mètre cube';
localizedStrings['Quart (US)'] = 'Litre américain';
localizedStrings['Liter'] = 'Litre';
localizedStrings['Gallon (Imperial)'] = 'Gallon (anglais)';
localizedStrings['Dram (US)'] = 'Dram américain';
localizedStrings['Fluid Ounce (US)'] = 'Once liquide américaine';

localizedStrings['Time'] = 'Durée';
localizedStrings['Hours'] = 'Heures';
localizedStrings['Minutes'] = 'Minutes';
localizedStrings['Seconds'] = 'Secondes';
localizedStrings['Milliseconds'] = 'Millisecondes';
localizedStrings['Microseconds'] = 'Microsecondes';
localizedStrings['Nanoseconds'] = 'Nanosecondes';
localizedStrings['Weeks'] = 'Semaines';
localizedStrings['Days'] = 'Jours';
localizedStrings['Years'] = 'Années';

localizedStrings['Convert'] = 'Convertir';
localizedStrings['Currency'] = 'Devise';
localizedStrings['CurrencyLastUpdated'] = 'Mis à jour le';
localizedStrings['CurrencyNotAvailable'] = 'Les taux de change ne sont pas disponibles actuellement.';
localizedStrings['Attribution'] = 'Conversion de devise fournie par';
localizedStrings['Done'] = 'Terminé';
localizedStrings['Network unavailable.'] = 'Réseau non disponible.';
localizedStrings['Invalid Date'] = 'Date invalide.';
localizedStrings['Data unavailable.'] = 'Données non disponibles.';
localizedStrings['Retrieving data.'] = 'Récupération de données en cours.';
localizedStrings['Terms of Service'] = 'Conditions de service';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

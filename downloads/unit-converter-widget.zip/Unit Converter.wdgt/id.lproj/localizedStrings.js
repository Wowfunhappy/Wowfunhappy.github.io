var localizedStrings = new Array();

localizedStrings['Area'] = 'Area';
localizedStrings['Square Inch'] = 'Inci Persegi';
localizedStrings['Square Kilometer'] = 'Kilometer Persegi';
localizedStrings['Square Foot'] = 'Kaki Persegi';
localizedStrings['Square Centimeter'] = 'Sentimeter Persegi';
localizedStrings['Square Yard'] = 'Yard Persegi';
localizedStrings['Square Millimeter'] = 'Milimeter Persegi';
localizedStrings['Square Meter'] = 'Meter Persegi';
localizedStrings['Square Mile'] = 'Mil Persegi';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hektar';

localizedStrings['Energy'] = 'Energi';
localizedStrings['Kilogram-Meters'] = 'Kilogram-Meter';
localizedStrings['Foot-Pounds'] = 'Kaki-Pon';
localizedStrings['Kilogram-Calories'] = 'Kilogram-Kalori';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Kilowatt-Jam';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newton-Meter';
localizedStrings['Joules'] = 'Joule';
localizedStrings['Calories'] = 'Kalori';
localizedStrings['Watt-Hours'] = 'Watt-Jam';

localizedStrings['Temperature'] = 'Suhu';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Panjang';
localizedStrings['Inch'] = 'Inci';
localizedStrings['Yard'] = 'Yard';
localizedStrings['Mile (nautical)'] = 'Mile (nautik)';
localizedStrings['Centimeter'] = 'Sentimeter';
localizedStrings['Meter'] = 'Meter';
localizedStrings['Mile'] = 'Mil';
localizedStrings['Foot'] = 'Kaki';
localizedStrings['Kilometer'] = 'Kilometer';
localizedStrings['Millimeter'] = 'Millimeter';

localizedStrings['Weight'] = 'Berat Badan';
localizedStrings['Pound (US)'] = 'Pon (AS)';
localizedStrings['Stone'] = 'Batu';
localizedStrings['Short Ton (US)'] = 'Ton Pendek (AS)';
localizedStrings['Metric Ton'] = 'Ton Metrik';
localizedStrings['Ounce (US)'] = 'Ons (AS)';
localizedStrings['Gram'] = 'Gram';
localizedStrings['Long Ton (UK)'] = 'Ton Panjang (Inggris)';
localizedStrings['Kilogram'] = 'Kilogram';

localizedStrings['Speed'] = 'Kecepatan';
localizedStrings['Feet/Minute'] = 'Kaki/Menit';
localizedStrings['Kilometers/Hour'] = 'Kilometer/Jam';
localizedStrings['Miles/Minute'] = 'Mil/Menit';
localizedStrings['Kilometers/Minute'] = 'Kilometer/Menit';
localizedStrings['Feet/Second'] = 'Kaki/Detik';
localizedStrings['Meters/Second'] = 'Meter/Detik';
localizedStrings['Knots'] = 'Knot';
localizedStrings['Miles/Hour'] = 'Mil/Jam';

localizedStrings['Pressure'] = 'Tekanan';
localizedStrings['Bars'] = 'Bar';
localizedStrings['Kilograms/Square Meter'] = 'Kilogram/Meter Persegi';
localizedStrings['Atmospheres'] = 'Atmosfer';
localizedStrings['Pounds/Square Foot'] = 'Pon/Kaki Persegi';
localizedStrings['Inches of Mercury'] = 'Inci Merkuri';
localizedStrings['Centimeters of Mercury'] = 'Sentimeter Merkuri';
localizedStrings['Pascals'] = 'Pascal';
localizedStrings['Pounds/Square Inch'] = 'Pon/Inci Persegi';

localizedStrings['Power'] = 'Daya';
localizedStrings['Horsepower'] = 'Tenaga Kuda';
localizedStrings['Btus/Minute'] = 'BTU/Menit';
localizedStrings['Foot-Pounds/Minute'] = 'Kaki-Pon/Menit';
localizedStrings['Watts'] = 'Watt';
localizedStrings['Foot-Pounds/Second'] = 'Kaki-Pon/Detik';
localizedStrings['Kilowatts'] = 'Kilowatt';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Pint (AS)';
localizedStrings['Cup'] = 'Cup';
localizedStrings['Tablespoon'] = 'Sendok Makan';
localizedStrings['Teaspoon'] = 'Sendok Teh';
localizedStrings['Gallon (US)'] = 'Galon (AS)';
localizedStrings['Cubic Feet'] = 'Kaki Kubik';
localizedStrings['Cubic Meter'] = 'Meter Kubik';
localizedStrings['Quart (US)'] = 'Kuart (AS)';
localizedStrings['Liter'] = 'Liter';
localizedStrings['Gallon (Imperial)'] = 'Galon (Imperial)';
localizedStrings['Dram (US)'] = 'Dram (AS)';
localizedStrings['Fluid Ounce (US)'] = 'Ons Cairan (AS)';

localizedStrings['Time'] = 'Waktu';
localizedStrings['Hours'] = 'Jam';
localizedStrings['Minutes'] = 'Menit';
localizedStrings['Seconds'] = 'Detik';
localizedStrings['Milliseconds'] = 'Milidetik';
localizedStrings['Microseconds'] = 'Mikro Detik';
localizedStrings['Nanoseconds'] = 'Nano Detik';
localizedStrings['Weeks'] = 'Minggu';
localizedStrings['Days'] = 'Hari';
localizedStrings['Years'] = 'Tahun';

localizedStrings['Convert'] = 'Ubah';
localizedStrings['Currency'] = 'Mata Uang';
localizedStrings['CurrencyLastUpdated'] = 'Terakhir Diperbarui';
localizedStrings['CurrencyNotAvailable'] = 'Tidak tersedia nilai tukar saat ini.';
localizedStrings['Attribution'] = 'Penukaran mata uang disediakan oleh';
localizedStrings['Done'] = 'Selesai';
localizedStrings['Network unavailable.'] = 'Jaringan tidak tersedia.';
localizedStrings['Invalid Date'] = 'Tanggal Tidak Sah.';
localizedStrings['Data unavailable.'] = 'Data tidak tersedia.';
localizedStrings['Retrieving data.'] = 'Mengambil data.';
localizedStrings['Terms of Service'] = 'Persyaratan Layanan';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

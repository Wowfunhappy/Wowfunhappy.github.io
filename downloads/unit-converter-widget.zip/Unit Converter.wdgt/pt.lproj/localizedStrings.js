var localizedStrings = new Array();

localizedStrings['Area'] = 'Área';
localizedStrings['Square Inch'] = 'Polegada Quadrada';
localizedStrings['Square Kilometer'] = 'Quilômetro Quadrado';
localizedStrings['Square Foot'] = 'Pé Quadrado';
localizedStrings['Square Centimeter'] = 'Centímetro Quadrado';
localizedStrings['Square Yard'] = 'Jarda Quadrada';
localizedStrings['Square Millimeter'] = 'Milímetro Quadrado';
localizedStrings['Square Meter'] = 'Metro Quadrado';
localizedStrings['Square Mile'] = 'Milha Quadrada';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectare';

localizedStrings['Energy'] = 'Energia';
localizedStrings['Kilogram-Meters'] = 'Quilograma-Metros';
localizedStrings['Foot-Pounds'] = 'Pé-Libras';
localizedStrings['Kilogram-Calories'] = 'Quilograma-Calorias';
localizedStrings['Ergs'] = 'Ergs';
localizedStrings['Kilowatt-Hours'] = 'Quilowatt-Horas';
localizedStrings['Btus'] = 'Btus';
localizedStrings['Newton-Meters'] = 'Newton-Metros';
localizedStrings['Joules'] = 'Joules';
localizedStrings['Calories'] = 'Calorias';
localizedStrings['Watt-Hours'] = 'Watt-Horas';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Célsius';

localizedStrings['Length'] = 'Comprimento';
localizedStrings['Inch'] = 'Polegada';
localizedStrings['Yard'] = 'Jarda';
localizedStrings['Mile (nautical)'] = 'Milha (náutica)';
localizedStrings['Centimeter'] = 'Centímetro';
localizedStrings['Meter'] = 'Metro';
localizedStrings['Mile'] = 'Milha';
localizedStrings['Foot'] = 'Pé';
localizedStrings['Kilometer'] = 'Quilômetro';
localizedStrings['Millimeter'] = 'Milímetro';

localizedStrings['Weight'] = 'Peso';
localizedStrings['Pound (US)'] = 'Libra (EUA)';
localizedStrings['Stone'] = 'Pedra';
localizedStrings['Short Ton (US)'] = 'Tonelada Curta (EUA)';
localizedStrings['Metric Ton'] = 'Tonelada Métrica';
localizedStrings['Ounce (US)'] = 'Onça (EUA)';
localizedStrings['Gram'] = 'Grama';
localizedStrings['Long Ton (UK)'] = 'Tonelada Longa (Reino Unido)';
localizedStrings['Kilogram'] = 'Quilograma';

localizedStrings['Speed'] = 'Velocidade';
localizedStrings['Feet/Minute'] = 'Pés/Minuto';
localizedStrings['Kilometers/Hour'] = 'Quilômetros/Hora';
localizedStrings['Miles/Minute'] = 'Milhas/Minuto';
localizedStrings['Kilometers/Minute'] = 'Quilômetros/Minuto';
localizedStrings['Feet/Second'] = 'Pés/Segundo';
localizedStrings['Meters/Second'] = 'Metros/Segundo';
localizedStrings['Knots'] = 'Nós';
localizedStrings['Miles/Hour'] = 'Milhas/Hora';

localizedStrings['Pressure'] = 'Pressão';
localizedStrings['Bars'] = 'Bars';
localizedStrings['Kilograms/Square Meter'] = 'Quilogramas/Metro Quadrado';
localizedStrings['Atmospheres'] = 'Atmosferas';
localizedStrings['Pounds/Square Foot'] = 'Libras/Pé Quadrado';
localizedStrings['Inches of Mercury'] = 'Polegadas de Mercúrio';
localizedStrings['Centimeters of Mercury'] = 'Centímetros de Mercúrio';
localizedStrings['Pascals'] = 'Pascals';
localizedStrings['Pounds/Square Inch'] = 'Libras/Polegada Quadrada';

localizedStrings['Power'] = 'Potência';
localizedStrings['Horsepower'] = 'Horsepower';
localizedStrings['Btus/Minute'] = 'Btus/Minuto';
localizedStrings['Foot-Pounds/Minute'] = 'Pé-Libras/Minuto';
localizedStrings['Watts'] = 'Watts';
localizedStrings['Foot-Pounds/Second'] = 'Pé-Libras/Segundo';
localizedStrings['Kilowatts'] = 'Quilowatts';

localizedStrings['Volume'] = 'Volume';
localizedStrings['Pint (US)'] = 'Quartilho (EUA)';
localizedStrings['Cup'] = 'Xícara';
localizedStrings['Tablespoon'] = 'Colher de sopa';
localizedStrings['Teaspoon'] = 'Colher de chá';
localizedStrings['Gallon (US)'] = 'Galão (EUA)';
localizedStrings['Cubic Feet'] = 'Pés Cúbicos';
localizedStrings['Cubic Meter'] = 'Metros Cúbicos';
localizedStrings['Quart (US)'] = 'Quarto de Galão (EUA)';
localizedStrings['Liter'] = 'Litro';
localizedStrings['Gallon (Imperial)'] = 'Galão (Imperial)';
localizedStrings['Dram (US)'] = 'Dracma (EUA)';
localizedStrings['Fluid Ounce (US)'] = 'Onça Fluida (EUA)';

localizedStrings['Time'] = 'Hora';
localizedStrings['Hours'] = 'Horas';
localizedStrings['Minutes'] = 'Minutos';
localizedStrings['Seconds'] = 'Segundos';
localizedStrings['Milliseconds'] = 'Milissegundos';
localizedStrings['Microseconds'] = 'Microssegundos';
localizedStrings['Nanoseconds'] = 'Nanossegundos';
localizedStrings['Weeks'] = 'Semanas';
localizedStrings['Days'] = 'Dias';
localizedStrings['Years'] = 'Anos';

localizedStrings['Convert'] = 'Converter';
localizedStrings['Currency'] = 'Moeda';
localizedStrings['CurrencyLastUpdated'] = 'Última Atualização';
localizedStrings['CurrencyNotAvailable'] = 'As taxas de câmbio não estão disponíveis atualmente';
localizedStrings['Attribution'] = 'Taxas de câmbio fornecidas por';
localizedStrings['Done'] = 'OK';
localizedStrings['Network unavailable.'] = 'Rede não disponível.';
localizedStrings['Invalid Date'] = 'Data Inválida.';
localizedStrings['Data unavailable.'] = 'Dados não disponíveis.';
localizedStrings['Retrieving data.'] = 'Recuperando dados.';
localizedStrings['Terms of Service'] = 'Termos de Serviço';
localizedStrings['Yahoo Finance'] = 'Yahoo Finanças';

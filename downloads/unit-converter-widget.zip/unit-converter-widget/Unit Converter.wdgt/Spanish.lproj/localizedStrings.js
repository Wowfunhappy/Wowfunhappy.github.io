var localizedStrings = new Array();

localizedStrings['Area'] = 'Área';
localizedStrings['Square Inch'] = 'Pulgadas cuadradas';
localizedStrings['Square Kilometer'] = 'Kilómetros cuadrados';
localizedStrings['Square Foot'] = 'Pies cuadrados';
localizedStrings['Square Centimeter'] = 'Centímetros cuadrados';
localizedStrings['Square Yard'] = 'Yardas cuadradas';
localizedStrings['Square Millimeter'] = 'Milímetros cuadrados';
localizedStrings['Square Meter'] = 'Metros cuadrados';
localizedStrings['Square Mile'] = 'Millas cuadradas';
localizedStrings['Acre'] = 'Acre';
localizedStrings['Hectare'] = 'Hectáreas';

localizedStrings['Energy'] = 'Energía';
localizedStrings['Kilogram-Meters'] = 'Kilogramos-metros';
localizedStrings['Foot-Pounds'] = 'Pies-libras';
localizedStrings['Kilogram-Calories'] = 'Kilogramos-calorías';
localizedStrings['Ergs'] = 'Ergios';
localizedStrings['Kilowatt-Hours'] = 'Kilovatios-horas';
localizedStrings['Btus'] = 'BTU';
localizedStrings['Newton-Meters'] = 'Newtons-metros';
localizedStrings['Joules'] = 'Julios';
localizedStrings['Calories'] = 'Calorías';
localizedStrings['Watt-Hours'] = 'Vatios-hora';

localizedStrings['Temperature'] = 'Temperatura';
localizedStrings['Fahrenheit'] = 'Fahrenheit';
localizedStrings['Kelvin'] = 'Kelvin';
localizedStrings['Celsius'] = 'Celsius';

localizedStrings['Length'] = 'Longitud';
localizedStrings['Inch'] = 'Pulgadas';
localizedStrings['Yard'] = 'Yardas';
localizedStrings['Mile (nautical)'] = 'Millas (náuticas)';
localizedStrings['Centimeter'] = 'Centímetros';
localizedStrings['Meter'] = 'Metros';
localizedStrings['Mile'] = 'Millas';
localizedStrings['Foot'] = 'Pies';
localizedStrings['Kilometer'] = 'Kilómetros';
localizedStrings['Millimeter'] = 'Milímetros';

localizedStrings['Weight'] = 'Peso';
localizedStrings['Pound (US)'] = 'Libra (EE. UU.)';
localizedStrings['Stone'] = 'Stone';
localizedStrings['Short Ton (US)'] = 'Tonelada corta (EE. UU.)';
localizedStrings['Metric Ton'] = 'Toneladas métricas';
localizedStrings['Ounce (US)'] = 'Onza (EE. UU.)';
localizedStrings['Gram'] = 'Gramos';
localizedStrings['Long Ton (UK)'] = 'Tonelada larga (Reino Unido)';
localizedStrings['Kilogram'] = 'Kilogramos';

localizedStrings['Speed'] = 'Velocidad';
localizedStrings['Feet/Minute'] = 'Pies/minuto';
localizedStrings['Kilometers/Hour'] = 'Kilómetros/hora';
localizedStrings['Miles/Minute'] = 'Millas/minuto';
localizedStrings['Kilometers/Minute'] = 'Kilómetros/minuto';
localizedStrings['Feet/Second'] = 'Pies/segundo';
localizedStrings['Meters/Second'] = 'Metros/segundo';
localizedStrings['Knots'] = 'Nudos';
localizedStrings['Miles/Hour'] = 'Millas/hora';

localizedStrings['Pressure'] = 'Presión';
localizedStrings['Bars'] = 'Bares';
localizedStrings['Kilograms/Square Meter'] = 'Kilogramos/metro cuadrado';
localizedStrings['Atmospheres'] = 'Atmósferas';
localizedStrings['Pounds/Square Foot'] = 'Libras/pie cuadrado';
localizedStrings['Inches of Mercury'] = 'Pulgadas de mercurio';
localizedStrings['Centimeters of Mercury'] = 'Centímetros de mercurio';
localizedStrings['Pascals'] = 'Pascales';
localizedStrings['Pounds/Square Inch'] = 'Libras/pulgada cuadrada';

localizedStrings['Power'] = 'Potencia';
localizedStrings['Horsepower'] = 'Caballos de vapor';
localizedStrings['Btus/Minute'] = 'BTU/minuto';
localizedStrings['Foot-Pounds/Minute'] = 'Pies-libras/minuto';
localizedStrings['Watts'] = 'Vatios';
localizedStrings['Foot-Pounds/Second'] = 'Pies-libras/segundo';
localizedStrings['Kilowatts'] = 'Kilovatios';

localizedStrings['Volume'] = 'Volumen';
localizedStrings['Pint (US)'] = 'Pinta (EE. UU.)';
localizedStrings['Cup'] = 'Taza';
localizedStrings['Tablespoon'] = 'Cuchara sopera';
localizedStrings['Teaspoon'] = 'Cucharilla';
localizedStrings['Gallon (US)'] = 'Galones (EE. UU.)';
localizedStrings['Cubic Feet'] = 'Pies cúbicos';
localizedStrings['Cubic Meter'] = 'Metros cúbicos';
localizedStrings['Quart (US)'] = 'Cuartos de galón (EE. UU.)';
localizedStrings['Liter'] = 'Litros';
localizedStrings['Gallon (Imperial)'] = 'Galones (imperiales)';
localizedStrings['Dram (US)'] = 'Dracma (EE. UU.)';
localizedStrings['Fluid Ounce (US)'] = 'Onzas líquida (EE. UU.)';

localizedStrings['Time'] = 'Tiempo';
localizedStrings['Hours'] = 'Horas';
localizedStrings['Minutes'] = 'Minutos';
localizedStrings['Seconds'] = 'Segundos';
localizedStrings['Milliseconds'] = 'Milisegundos';
localizedStrings['Microseconds'] = 'Microsegundos';
localizedStrings['Nanoseconds'] = 'Nanosegundos';
localizedStrings['Weeks'] = 'Semanas';
localizedStrings['Days'] = 'Días';
localizedStrings['Years'] = 'Años';

localizedStrings['Convert'] = 'Convertir';
localizedStrings['Currency'] = 'Moneda';
localizedStrings['CurrencyLastUpdated'] = 'Última actualización';
localizedStrings['CurrencyNotAvailable'] = 'Los tipos de cambio no están disponibles.';
localizedStrings['Attribution'] = 'Cambio de divisas facilitado por';
localizedStrings['Done'] = 'Aceptar';
localizedStrings['Network unavailable.'] = 'Red no disponible.';
localizedStrings['Invalid Date'] = 'Fecha no válida.';
localizedStrings['Data unavailable.'] = 'Datos no disponibles.';
localizedStrings['Retrieving data.'] = 'Obteniendo datos.';
localizedStrings['Terms of Service'] = 'Condiciones del servicio';
localizedStrings['Yahoo Finance'] = 'Yahoo Finanzas';

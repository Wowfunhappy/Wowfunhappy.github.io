var localizedStrings = new Array();

localizedStrings['Area'] = '‏שטח';
localizedStrings['Square Inch'] = '‏אינץ\' מרובע';
localizedStrings['Square Kilometer'] = '‏קילומטר מרובע';
localizedStrings['Square Foot'] = '‏רגל מרובעת';
localizedStrings['Square Centimeter'] = '‏סנטימטר מרובע';
localizedStrings['Square Yard'] = '‏יארד מרובע';
localizedStrings['Square Millimeter'] = '‏מילימטר מרובע';
localizedStrings['Square Meter'] = '‏מטר מרובע';
localizedStrings['Square Mile'] = '‏מייל מרובע';
localizedStrings['Acre'] = '‏אקר';
localizedStrings['Hectare'] = '‏הקטאר';

localizedStrings['Energy'] = '‏אנרגיה';
localizedStrings['Kilogram-Meters'] = '‏קילוגרם-מטרים';
localizedStrings['Foot-Pounds'] = '‏רגל-ליברות';
localizedStrings['Kilogram-Calories'] = '‏קילוגרם-קלוריות';
localizedStrings['Ergs'] = 'ארג';
localizedStrings['Kilowatt-Hours'] = '‏קילוואט-שעות';
localizedStrings['Btus'] = '‏BTU';
localizedStrings['Newton-Meters'] = '‏ניוטון-מטרים';
localizedStrings['Joules'] = '‏ג\'ול';
localizedStrings['Calories'] = 'קלוריות';
localizedStrings['Watt-Hours'] = '‏ואט-שעות';

localizedStrings['Temperature'] = 'טמפרטורה';
localizedStrings['Fahrenheit'] = '‏פרנהייט';
localizedStrings['Kelvin'] = '‏קלווין';
localizedStrings['Celsius'] = '‏צלזיוס';

localizedStrings['Length'] = '‏אורך';
localizedStrings['Inch'] = '‏אינץ\'';
localizedStrings['Yard'] = 'יארד';
localizedStrings['Mile (nautical)'] = '‏מייל (ימי)‏';
localizedStrings['Centimeter'] = '‏סנטימטר';
localizedStrings['Meter'] = '‏מטר';
localizedStrings['Mile'] = '‏מייל';
localizedStrings['Foot'] = '‏רגל';
localizedStrings['Kilometer'] = '‏קילומטר';
localizedStrings['Millimeter'] = '‏מילימטר';

localizedStrings['Weight'] = 'משקל';
localizedStrings['Pound (US)'] = '‏ליברה (ארה\"ב)‏';
localizedStrings['Stone'] = '‏סטון';
localizedStrings['Short Ton (US)'] = '‏טון אמריקאי';
localizedStrings['Metric Ton'] = '‏טון';
localizedStrings['Ounce (US)'] = '‏אונקיה (ארה\"ב)‏';
localizedStrings['Gram'] = '‏גרם';
localizedStrings['Long Ton (UK)'] = '‏טון בריטי';
localizedStrings['Kilogram'] = '‏קילוגרם';

localizedStrings['Speed'] = 'מהירות';
localizedStrings['Feet/Minute'] = '‏רגל/דקה';
localizedStrings['Kilometers/Hour'] = '‏קילומטרים/שעה';
localizedStrings['Miles/Minute'] = '‏מייל/דקה';
localizedStrings['Kilometers/Minute'] = '‏קילומטרים/דקה';
localizedStrings['Feet/Second'] = '‏רגל/שניה';
localizedStrings['Meters/Second'] = '‏מטרים/שניה';
localizedStrings['Knots'] = '‏קשרים';
localizedStrings['Miles/Hour'] = '‏מיילים/שעה';

localizedStrings['Pressure'] = '‏לחץ';
localizedStrings['Bars'] = 'בר';
localizedStrings['Kilograms/Square Meter'] = '‏קילוגרמים/מטר מרובע';
localizedStrings['Atmospheres'] = '‏אטמוספירות';
localizedStrings['Pounds/Square Foot'] = '‏ליברות/רגל מרובעת';
localizedStrings['Inches of Mercury'] = '‏אינץ\' כספית';
localizedStrings['Centimeters of Mercury'] = '‏סנטימטר כספית';
localizedStrings['Pascals'] = '‏פסקל';
localizedStrings['Pounds/Square Inch'] = '‏ליברות/אינץ\' מרובע';

localizedStrings['Power'] = '‏הספק';
localizedStrings['Horsepower'] = '‏כוח סוס';
localizedStrings['Btus/Minute'] = '‏BTU/דקה';
localizedStrings['Foot-Pounds/Minute'] = '‏רגל-ליברות/דקה';
localizedStrings['Watts'] = '‏ואטים';
localizedStrings['Foot-Pounds/Second'] = '‏רגל-ליברות/שניה';
localizedStrings['Kilowatts'] = '‏קילוואטים';

localizedStrings['Volume'] = '‏נפח';
localizedStrings['Pint (US)'] = '‏פיינט (ארה\"ב)‏';
localizedStrings['Cup'] = '‏כוס';
localizedStrings['Tablespoon'] = '‏כף';
localizedStrings['Teaspoon'] = '‏כפית';
localizedStrings['Gallon (US)'] = '‏גלון (ארה\"ב)‏';
localizedStrings['Cubic Feet'] = '‏רגל מעוקבת';
localizedStrings['Cubic Meter'] = '‏מטר מעוקב';
localizedStrings['Quart (US)'] = '‏קווארט (ארה\"ב)‏';
localizedStrings['Liter'] = '‏ליטר';
localizedStrings['Gallon (Imperial)'] = '‏גלון (אימפריאלי)‏';
localizedStrings['Dram (US)'] = '‏דראם (ארה\"ב)‏';
localizedStrings['Fluid Ounce (US)'] = '‏אונקיית נוזלים (ארה\"ב)‏';

localizedStrings['Time'] = '‏זמן';
localizedStrings['Hours'] = 'שעות';
localizedStrings['Minutes'] = 'דקות';
localizedStrings['Seconds'] = 'שניות';
localizedStrings['Milliseconds'] = '‏אלפיות השניה';
localizedStrings['Microseconds'] = '‏מיקרושניות';
localizedStrings['Nanoseconds'] = '‏ננושניות';
localizedStrings['Weeks'] = '‏שבועות';
localizedStrings['Days'] = '‏ימים';
localizedStrings['Years'] = '‏שנים';

localizedStrings['Convert'] = 'המר';
localizedStrings['Currency'] = '‏מטבע';
localizedStrings['CurrencyLastUpdated'] = '‏עודכן לאחרונה';
localizedStrings['CurrencyNotAvailable'] = '‏השערים היציגים אינם זמינים כעת.‏';
localizedStrings['Attribution'] = '‏השערים היציגים באדיבות';
localizedStrings['Done'] = 'סיום';
localizedStrings['Network unavailable.'] = '‏הרשת אינה זמינה.‏';
localizedStrings['Invalid Date'] = '‏התאריך אינו תקין.‏';
localizedStrings['Data unavailable.'] = '‏הנתונים אינם זמינים.‏';
localizedStrings['Retrieving data.'] = '‏טוען נתונים.‏';
localizedStrings['Terms of Service'] = '‏תנאי שימוש';
localizedStrings['Yahoo Finance'] = 'Yahoo Finance';

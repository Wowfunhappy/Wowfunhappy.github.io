#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import "ZKSwizzle.h"

#define DYLD_INTERPOSE(_replacement,_replacee) \
__attribute__((used)) static struct{ const void* replacement; const void* replacee; } _interpose_##_replacee \
__attribute__ ((section ("__DATA,__interpose"))) = { (const void*)(unsigned long)&_replacement, (const void*)(unsigned long)&_replacee };


//Left to its own devices, Mavericks CoreFoundation will release a CTFontRef which Chromium later
//attempts to access. The exact cause is unknown, and fixing it via code injection is likely infeasible.

//This messy hack attempts to detect when CoreFoundation _might_ be about to release a reference which
//will lead to a crash, and prevent any release under that circumstance. This _will_ cause a memory
//leak, but real-world memory usage appears to be unchanged.

//(For that matter, even fully blocking CFRelease does not appear to have a noticable impact. How that
//is possible, I cannot say.)

unsigned int CTTracker = 0;

CTFontDescriptorRef myCTFontManagerCreateFontDescriptorFromData(CFDataRef data) {
    CTTracker = 150;
    return CTFontManagerCreateFontDescriptorFromData(data);
}
DYLD_INTERPOSE(myCTFontManagerCreateFontDescriptorFromData, CTFontManagerCreateFontDescriptorFromData);


void myCFRelease (CFTypeRef cf) {
    if (CTTracker > 0) {
        CTTracker--;
    } else {
        CFRelease(cf);
    }
}
DYLD_INTERPOSE(myCFRelease, CFRelease);


// Even after nuetralizing CFRelease, Chromium will still crash on certain pages. Crash logs blame CTFontCreatePathForGlyph.
// Apple Documentation says NULL is a valid return value for CTFontCreatePathForGlyph, and returning it
// seems to fix the problem, presumably because it activates an alternate code path in Chromium.

CGPathRef myCTFontCreatePathForGlyph(CTFontRef font, CGGlyph glyph, const CGAffineTransform *matrix) {
    return NULL;
}
DYLD_INTERPOSE(myCTFontCreatePathForGlyph, CTFontCreatePathForGlyph);



// Fix window resize garbage
@interface myNSView : NSView
@end

@implementation myNSView
- (void) viewWillStartLiveResize {
    [self setWantsLayer:true];
    ZKOrig(void);
}
@end

@implementation NSObject (main)
+ (void)load {
    ZKSwizzle(myNSView, NSView);
}
@end
